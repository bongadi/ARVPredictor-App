import { Component } from '@angular/core';
import { AlertController,  IonicPage, NavController, NavParams, LoadingController } from 'ionic-angular';
import {GlobalVarsProvider} from "../../providers/global-vars/global-vars";
import { FileChooser } from '@ionic-native/file-chooser';
import {RemoteServiceProvider} from "../../providers/remote-service/remote-service";

import { File } from '@ionic-native/file';
import { FilePath } from '@ionic-native/file-path';
import { AndroidPermissions } from '@ionic-native/android-permissions';


/**
 * Generated class for the AccountServicesPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */
@IonicPage()
@Component({
  selector: 'page-account-services',
  templateUrl: 'account-services.html',
})
export class AccountServicesPage {
    
    formData: any = {};
    objectblock : any = {};
    sampleSequences :any = [];
    data: any;

  error: number = 0;

  sampleMutations : any[];
  private possibleMutations: any[];
  inputSequence : any = '';
  inputHeader : any = '';

  constructor(public navCtrl: NavController, public globalVars: GlobalVarsProvider, public loadingCtrl: LoadingController,
              public remoteService: RemoteServiceProvider, public alertCtrl: AlertController, private fileChooser: FileChooser, private file: File, private filePath: FilePath, private androidPermissions: AndroidPermissions) {

    this.sampleSequences = 
    [
      {
      header: "AY030412",
      sequence: "CCTCAAATCACTCTTTGGCAACGACCCATCGTCACAATAAAGATAGGGGGGCAGCTAARGGAAGCTCTATTAGATACAGGAGCAGATGATACAGTATTAGAAGATATAAATTTGCCAGGAAGATGGACACCAAAAATKATAGTGGGAATTGGAGGTTTTACCAAAGTAAGACAGTATGATCAGATACCTGTAGAAATTTGTGGACATAAAGCTATAGGTACAGTRTTAGTAGGACCTACACCTGCCAACATAATTGGAAGAAATCTGTTGACYCAGATTGGTTGCACTTTAAATTTTCCCATTAGTCCTATTGACACTGTACCAGTAAAATTAAAGCCAGGAATGGATGGCCCAAAAGTTAAACAATGGCCATTGACAGAAGAAAAAATAAAAGCATTAGTAGAAATTTGTGCAGAATTGGAASAGGACGGGAAAATTTCAAAAATTGGGCCTGAAAATCCATACAATACTCCAGTATTTGCCATAAAGAAAAAGAACAGYGATAAATGGAGAAAATTAGTAGATTTCAGAGAACTTAATAAGAGAACTCAAGACTTCTGGGAAGTTCAATTAGGAATACCACATCCCGGAGGGTTAAAAAAGAACAAATCAGTAACAGTACTGGATGTGGGTGATGCATATTTTTCARTTCCCTTAGATGAAGACTTCAGGAAGTATACTGCATTTACCATACCTAGTATAAACAATGAGACACCAGGGACTAGATATCAGTACAATGTGCTTCCACAGGGATGGAAAGGATCACCAGCAATATTCCAAAGTAGCATGACAAGAATCTTAGAACCTTTTAGAAAACAGAATCCAGACATAGTTATCTGTCAATAYGTGGATGATTTGTATGTAGGATCTGACTTAGAAATAGAGMAGCATAGAACAAAAGTAGAGGAACTGAGACAACATTTGTGGAAGTGGGGNTTTTACACACCAGACAAMAAACATCAGAAAGAACCTCCATTCCTTTGGATGGGTTATGAACTCCATCCTGATAAATGGACA"
      },
     {
       header: "AY030413",
       sequence: "CCTCAAATCACTCTTTGGCAACGACCCATCGTCACAATAAGGATAGGAGGGCAACTAAAGGAAGCTCTATTAGATACAGGAGCAGATGATACAGTATTAGAAGAAATGAATTTGCCAGGAAAATGGAAACCAAAAATGATAGGGGGAATTGGAGGTTTTGTCAAAGTAAGACAGTATGAGCAGATACCCGTAGAAATCTGCGGACATAAAGTTATAGGTACAGTATTAGTAGGACCTACACCTGCCAACATAATTGGAAGAAATCTGATGACTCAGCTTGGTTGTACTTTAAATTTTCCCATTAGTCCTATTGAAACTGTACCAGTAAAATTAAAGCCAGGAATGGATGGCCCAAAAGTTAAACAATGGCCATTGACAGAGGAAAAAATAAATGCATTAGTAGAAATTTGTGCAGAAATGGAAAAGGAAGGGAAAATTTCWAAAATTGGGCCTGAAAATCCATACAATACTCCAGTATTTGCYATAAAGAAAAAGAACAGTACTAGATGGAGAAAATTAGTAGATTTCAGAGAACTTAATAAGAGAACTCAAGACTTCTGGGAAGTTCAATTAGGAATACCACATCCCKCAGGGTTAAAAAAGAAAAAATCAGTAACAGTACTGGATGTGGGTGATGCATACTTTTCAGTTCCCTTATATGAAGACTTTAGAAAGTATACTGCATTTACCATACCTAGTAAAAACAATGAGACACCAGGGATTAGATACCAGTATAATGTGCTTCCACAGGGATGGAAAGGATCACCAGCAATATTCCAAAGTAGCATGACAAAAATCTTAGAGCCTTTTAGACAACAAAATCCAGACCTAGTTATCTATCAATACATGGATGATTTGTATGTAGGATCTGACTTAGAAATAGGGCAGCATAGAACAAAAATAGAGGAACTGAGACAACATCTGTTGAGGTGGGGATTTTTCACACCAGATCAAAAACATCAGAARGAACCYCCATTCCTTTGGATGGGTTATGAACTCCATCCTGATAAATGGACAGTACAGCCTATACAGCTGCCAGAA"
     }
    ];

  }

  ionViewDidLoad() {
  }

  backToMainPage(page){
    this.navCtrl.setRoot(page);
  }

   openPage(page){
    this.navCtrl.push(page);
  }

  onClickSelectFile () {

    this.fileChooser.open()
      .then(uri => {
      
      let name = uri.split("/");
      let fileName = name[name.length - 1];
      let pathUri = uri.replace(fileName,"");

      this.androidPermissions.checkPermission(this.androidPermissions.PERMISSION.READ_EXTERNAL_STORAGE).then(
        result => console.log('Has permission?',result.hasPermission),
        err => this.androidPermissions.requestPermission(this.androidPermissions.PERMISSION.READ_EXTERNAL_STORAGE)
      );

      this.androidPermissions.requestPermission(this.androidPermissions.PERMISSION.READ_EXTERNAL_STORAGE)
      .then(granted => {
            
            this.filePath.resolveNativePath(pathUri).then(path => {

              this.file.readAsText(path, fileName)
                .then(text => {
                    console.log(text);

                })
                .catch(err =>{
                    console.log(err);
                });
            })


        })
        .catch(e => console.log(e));

      })
      .catch(failed => {
        console.log("failed");
        console.log(failed);
      });

  }    

  analyze(isSample, isSequence) {

    if(!isSample) {
      console.log(this.formData);
      this.objectblock.sequences = [];

      for(let selectedMutation of this.possibleMutations) {
        this.objectblock.sequences.push(selectedMutation.mutationShortLabel + ':' + selectedMutation.mutationName + selectedMutation.position + selectedMutation.name);
      }
      this.objectblock.sequences = JSON.stringify(this.objectblock.sequences);

    }
    else {
      console.log(this.formData);
      this.objectblock.sequences = JSON.stringify(this.sampleSequences );
    }

    let loading = this.loadingCtrl.create({
      spinner: 'crescent',
      content: 'Analyzing your input...'
    });

    loading.present().then(() => {

    console.log( this.objectblock );
    //send loan application request
      this.remoteService.predict(this.objectblock, true) 
        .then(
        data => {
          loading.dismiss();
          this.data = data;

          console.log(this.data);

          let currentVersion = this.data.currentVersion;

          this.data.message = String.raw`Results found for version ${currentVersion.text} as published on ${currentVersion.publishDate}!`;

          this.globalVars.stanfordResults = this.data;
          this.globalVars.presentAlert("Success", this.data.message);
          console.log(this.globalVars.stanfordResults );

          this.globalVars.openPage('LoanRepaymentPage');
        })
      .catch(
        error => {
          loading.dismiss();
          console.log(error);

          // identify the error
          if (error) {
            // show a nice error message
            this.globalVars.presentAlert(error.error,  error.reason);
          } else {
            this.globalVars.presentAlert("Error", "Request was not successful");
          }
          
        });
    });

  }

}
