import { Component, ViewChild } from '@angular/core';
import {Nav, Platform} from 'ionic-angular';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';

import { InAppBrowser } from '@ionic-native/in-app-browser';
import {DomSanitizer} from "@angular/platform-browser";


@Component({
  templateUrl: 'app.html'
})

export class MyApp {
  @ViewChild(Nav) nav: Nav;

  rootPage: any = "LoginPage";
  browser:any;
  pages: Array<{title: string, component: string, icon:any}>;
  private _htmlProperty: string = '<progress></progress>';

  constructor(public platform: Platform, public statusBar: StatusBar, public splashScreen: SplashScreen,
              private iab: InAppBrowser, private _sanitizer: DomSanitizer) {

    this.initializeApp();

    // used for an example of ngFor and navigation
    this.pages = [
      { title: 'Main Services', component: 'MainPage', icon:'grid' },
      { title: 'Stanford DRD News', component: 'MainPage', icon:'wifi' },
      { title: 'About Stanford DRD', component: 'MainPage', icon:'information-circle' },
      { title: 'Contact Us', component: 'ContactPage', icon:'call' },
      { title: 'Log Out', component: 'LoginPage', icon:'log-out' }
    ];

  }

  initializeApp() {
    this.platform.ready().then(() => {
      // Okay, so the platform is ready and our plugins are available.
      // Here you can do any higher level native things you might need.
      this.statusBar.styleDefault();

      setTimeout(() => {
        this.splashScreen.hide();
      }, 500);

    });
  }

  openPage(page) {
    if(page.title=="About Stanford DRD"){
      this.openBrowser("http://www.aarcredit.co.ke/index.php/about-us");
    }
    else if(page.title=="Stanford DRD News"){
      this.openBrowser("http://www.aarcredit.co.ke/index.php/news");
    }
    else{
      this.nav.setRoot(page.component);
    }
  }
  openBrowser(url) {
    this.browser= this.iab.create(url);
    this.browser.show();
  }

   htmlProperty() {
    return this._sanitizer.bypassSecurityTrustHtml(this._htmlProperty);
  }


}
