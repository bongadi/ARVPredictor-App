import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { LoanRepaymentPage } from './loan-repayment';

import { SequenceQaComponent } from '../../components/sequence-qa/sequence-qa'; // this is needed!
import { SequenceQaComponentModule } from '../../components/sequence-qa/sequence-qa.module'; // this is needed!

@NgModule({
  declarations: [
    LoanRepaymentPage
  ],
  imports: [
  	SequenceQaComponentModule,
    IonicPageModule.forChild(LoanRepaymentPage)
  ],
  exports: [
    LoanRepaymentPage, SequenceQaComponent
  ]
})
export class LoanRepaymentPageModule {}
