import { NgModule } from '@angular/core';
import { IonicModule } from 'ionic-angular';
import { SequenceQaComponent } from './sequence-qa';
import { BarChartComponent } from 'angular-d3-charts'; // this is needed!

@NgModule({
  declarations: [
    SequenceQaComponent, BarChartComponent
  ],
  imports: [
    IonicModule,
  ],
  exports: [
    SequenceQaComponent, BarChartComponent
  ]
})
export class SequenceQaComponentModule {}
