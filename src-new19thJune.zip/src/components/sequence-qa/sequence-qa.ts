import { Component, OnInit, OnChanges, ViewChild, ElementRef, Input, ViewEncapsulation } from '@angular/core';	
import * as d3 from 'd3';

//import * as d3 from 'd3-selection';
import * as d3Scale from "d3-scale";
import * as d3Array from "d3-array";
import * as d3Axis from "d3-axis";

/**
 * Generated class for the LoanRepaymentPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */


@Component({
  selector: 'sequence-qa',
  templateUrl: 'sequence-qa.html'
})
export class SequenceQaComponent {

    @Input('data')
	alignedGeneSequences?: any;

	@Input('title')
	title = 'D3.js with Ionic 2!';

	@ViewChild('chart') private chartContainer: ElementRef;	
	@ViewChild('timeline1') private timelineContainer: ElementRef;	

  	@Input() private data: Array<any>;	  
  	private margin: any = { 
  		top: 20, bottom: 20, left: 20, right: 20
  	};	  
  	private chart: any;	  
  	private width: number;	  
  	private height: number;	  
  	private xScale: any;	  
  	private yScale: any;	  
  	private colors: any;	  
  	private xAxis: any;	  
  	private yAxis: any;

  	constructor() {
    	console.log('Hello SequenceQaComponent Component');
	
  	}

  	ngOnInit() {
        //this.createChart();	
          if (this.data) {	
              	console.log(this.data);
      
          	//this.updateChart();	    
          }
  	}

  	ngOnChanges() {	    
  		if (this.chart) {	      
  			//this.updateChart();	    
  		}
  	}


}
