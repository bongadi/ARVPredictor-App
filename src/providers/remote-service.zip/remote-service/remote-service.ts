import {Injectable} from '@angular/core';
import {Http, Response, Headers, RequestOptions} from '@angular/http';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/timeout';
import 'rxjs/add/operator/catch';
import {GlobalVarsProvider} from "../global-vars/global-vars";

/*
 Generated class for the RemoteServiceProvider provider.

 See https://angular.io/docs/ts/latest/guide/dependency-injection.html
 for more info on providers and Angular DI.
 */
@Injectable()
export class RemoteServiceProvider {

  globalVars : any = GlobalVarsProvider;

  constructor(public http: Http) {
    this.token = this.globalVars.authToken;
  }

  getAPIVersion: string = "2";

  /**
   *  Pointing to on localhost
   *  getOnestepApiUrl: string = "http://10.20.32.22/aarcredit_api/public/index.php/api/v" + this.getAPIVersion + "/";
   */

  /**
   *  Pointing to on localhost
   */

   getOnestepApiUrl: string = "https://10.20.2.6:8085/aarcredit_api/public/index.php/api/v" + this.getAPIVersion + "/";
   //getOnestepApiUrl: string = "http://10.20.32.22:80/aarcredit_api/public/index.php/api/v" + this.getAPIVersion + "/";

  //getOnestepApiUrl: string = "http://10.20.32.48:80/aarcredit_api/public/index.php/api/v" + this.getAPIVersion + "/";
  //getOnestepApiUrl: string = "http://localhost/aarcredit_api/public/index.php/api/v" + this.getAPIVersion + "/";
  //getOnestepApiUrl: string = "https://testgateway.ekenya.co.ke:8443/aarcredit_api/public/index.php/api/v" + this.getAPIVersion + "/";

  getAARApiUrl: string = "https://10.20.2.6:8085/aar_api/";

  token : any;
  headers: any = new Headers(
    {
      'Content-Type': 'application/x-www-form-urlencoded',
      'Authorization': 'Bearer ' + this.token
    });

  timeout: any = 50000;

  options: any = new RequestOptions({headers: this.headers});

  public postRequest(body: any, url: string, isAAR?: boolean) {
    let fullURL = this.getOnestepApiUrl;
    if (isAAR) {

      fullURL = this.getAARApiUrl;
    }

    body.country = 'kenya';
    body.uuid = '254702818290';
    body.usertype = 'agent';


    let bodyFormatted = Object.keys(body).map(function (key) {
      return encodeURIComponent(key) + '=' + encodeURIComponent(body[key]);
    }).join('&');

    //let body2="user=0708730788&pin=6667&country=kenya&uuid=254702818290&usertype=agent";
    return new Promise(resolve => {
      this.http.post(fullURL + url + "?" + bodyFormatted, "", this.options)
        .timeout(this.timeout)
        .map(res => res.json())
        .subscribe(
          data => {
            resolve(data);
          },
          error => {
            resolve(RemoteServiceProvider.handleError(error));
          });
    });

  }

  private static handleError(error: Response | any) {
    let errMsg: string;
    if (error instanceof Response) {
      const body = error.json() || '';
      const err = body.error || JSON.stringify(body);
      errMsg = `${error.status} - ${error.statusText || ''} ${err}`;
      console.error(errMsg);

    } else {

      errMsg = error.message ? error.message : error.toString();
      console.error(errMsg);

    }
    return Promise.reject(errMsg);
  }

}

