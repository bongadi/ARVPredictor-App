import {Component} from '@angular/core';
import {AlertController, IonicPage, LoadingController, NavController} from 'ionic-angular';
import {GlobalVarsProvider} from "../../providers/global-vars/global-vars";
import {RemoteServiceProvider} from "../../providers/remote-service/remote-service";

/**
 * Generated class for the ApplyLoansPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */
@IonicPage()
@Component({
  selector: 'page-apply-loans',
  templateUrl: 'apply-loans.html',
})
export class ApplyLoansPage {
  preScoredAmount: number;
  minimumLoanAmount: number;
  overallCashLimit: number;
  error: number = 0;

  objectblock: any = {};
  data: any;
  tills: any;
  ltypes: any = [];
  periods: any = [];
  private loanCategories: any;
  private loanCategory: any;

  constructor(public navCtrl: NavController, public globalVars: GlobalVarsProvider, public loadingCtrl: LoadingController,
              public remoteService: RemoteServiceProvider, public alertCtrl: AlertController) {

    this.ltypes = this.globalVars.lTypes;
    this.tills = this.globalVars.tills;

    this.objectblock.username = this.globalVars.mwalletAccount;
    //this.objectblock.ltypeObject = this.ltypes[0];
    this.minimumLoanAmount = 1000;
    this.overallCashLimit = this.globalVars.overallcashlimit;
    this.preScoredAmount = 5000;
    this.objectblock.preScoredAmount = this.preScoredAmount;
    this.objectblock.customerName = '';
    //this.objectblock.amount = 0;
    //this.objectblock.periodObject = this.globalVars.lPeriods[this.objectblock.ltypeObject];

    this.loanCategories = GlobalVarsProvider.LOANCATEGORIES;

  }

  ionViewDidLoad() {
  }

  backToMainPage(page) {
    this.navCtrl.setRoot(page);
  }

  onselectLoanType(event) {

    let loanName: string = event.name;
    this.getLoanPeriods(loanName);

    if (loanName.toLowerCase().includes('fixed')) {
      this.loanCategory = this.loanCategories.TILLLOAN;
    }

    else if (loanName.toLowerCase().includes('pensioner')) {
      this.loanCategory = this.loanCategories.PENSIONERLOAN;

    }

    else if (loanName.toLowerCase().includes('staff')) {
      this.loanCategory = this.loanCategories.STAFFLOAN;

    }

    else if (loanName.toLowerCase().includes('advance')) {
      this.loanCategory = this.loanCategories.ADVANCELOAN;

    }
  }

  getLoanPeriods(event) {
    let loan = event;

    this.periods = this.globalVars.lPeriods[loan];

  }

  score() {

    if (this.objectblock.ltypeObject === undefined) {
      this.error = 1;
      return;
    }

    //if loan scoring is not processed by FIN, then process scoring internally and set Min and Max
    let responseArr: any = {};

    //Case 1 : Salary Advance
    if (this.loanCategory === this.loanCategories.ADVANCELOAN) {

      responseArr.loanType = "N";
      responseArr.FINProcessed = "MM";
      responseArr.term = 1;
      responseArr.loanName = this.objectblock.ltypeObject.name;

      responseArr.interest = 0;
      responseArr.loanQualified = 100000;
      responseArr.loanBalance = 0;
      responseArr.netDisbursement = 500;

      responseArr.loanProductCode = this.objectblock.ltypeObject.productcode;
      responseArr.tillno = this.objectblock.ltypeObject.name;

      responseArr.minimumAmount = this.minimumLoanAmount;
      responseArr.maximumAmount = this.overallCashLimit;

      this.globalVars.loanScore = responseArr;


      this.navCtrl.push("LoanCommitPage");

    }

    //Case 2 : Agent Loan - has a till
    else if (this.loanCategory === this.loanCategories.TILLLOAN) {

      if (this.objectblock.tillObject === undefined) {
        this.error = 2;
        return;
      }

      //If there is a Till to score


      responseArr.loanType = "N";
      responseArr.FINProcessed = "MM";
      responseArr.term = 1;
      responseArr.loanName = this.objectblock.ltypeObject.name;

      responseArr.interest = 0;
      responseArr.loanQualified = 100000;
      responseArr.loanBalance = 0;
      responseArr.netDisbursement = 500;

      responseArr.loanProductCode = this.objectblock.ltypeObject.productcode;
      responseArr.minimumAmount = this.minimumLoanAmount;
      responseArr.tillno = this.objectblock.tillObject.tillname;
      responseArr.maximumAmount = this.objectblock.tillObject.tillLimit;

      this.globalVars.loanScore = responseArr;

      this.navCtrl.push("LoanCommitPage");

    }

    //Case 3 : Consumer Loan, AAR Staff Loan or Pensioner Loan
    //If loan scoring is processed by FIN, then scoring paramenters to get and set Min and Max
    else {

      this.objectblock.loanPeriod = this.objectblock.periodObject.val0;
      this.objectblock.interest = this.objectblock.periodObject.interest;
      this.objectblock.loanProductCode = this.objectblock.ltypeObject.productcode;

      let loading = this.loadingCtrl.create({
        spinner: 'crescent',
        content: 'Sending Loan details for scoring...'
      });

      loading.present();

      //send loan application request
      this.remoteService.postRequest(this.objectblock, "loans/score")
        .then(
          data => {
            loading.dismiss();
            this.data = data;

            if (this.data.error === false) {

              this.globalVars.loanScore = this.data.loanScore;
              this.globalVars.loanScore.term = this.objectblock.loanPeriod;
              this.globalVars.loanScore.tillno = this.objectblock.ltypeObject.name;

              this.globalVars.loanScore.loanName = this.objectblock.ltypeObject.name;
              this.globalVars.loanScore.FINProcessed = "CC";

              this.navCtrl.push("LoanCommitPage");

              this.globalVars.presentAlert("Success", this.data.message);
            }
            else {
              this.globalVars.presentAlert("Error", this.data.message);

            }

          }
        )
        .catch(
          error => {
            loading.dismiss();
            this.globalVars.presentAlert("Error", "Loan Scoring not successful");
          }
        );
    }
  }

}
