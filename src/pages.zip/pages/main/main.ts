import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import {GlobalVarsProvider} from "../../providers/global-vars/global-vars";

/**
 * Generated class for the MainPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */
@IonicPage()
@Component({
  selector: 'page-main',
  templateUrl: 'main.html',
})
export class MainPage {
  customername: string;
  global: any;
  accounts: any;

  constructor(public navCtrl: NavController, public navParams: NavParams, public globalVars: GlobalVarsProvider) {
    this.accounts= globalVars.accounts;
    this.customername= globalVars.customername;

    this.global = navParams.get('global');
  }

  ionViewDidLoad() {
  }

  payLoanPage () {
    //check if there's a loan to be repayed
    this.openPage('LoanRepaymentPage');
  }

  openPage(page){

    this.navCtrl.push(page, {global: this.global});
  }

  viewAccounts() {

  }

}
