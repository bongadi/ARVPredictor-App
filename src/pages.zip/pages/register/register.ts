import {Component} from '@angular/core';
import {IonicPage, LoadingController, NavController, NavParams, AlertController} from 'ionic-angular';

import {RemoteServiceProvider} from '../../providers/remote-service/remote-service';

/**
 * Generated class for the RegisterPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */
@IonicPage()
@Component({
  selector: 'page-register',
  templateUrl: 'register.html',
})
export class RegisterPage {
  objectblock: any = {};
  error: number = 0;
  data: any;
  firstform: boolean = true;
  selectedPage: string = 'pagerGrey';
  selectedPage2: string = 'pagerGreen';

  constructor(public navCtrl: NavController, public navParams: NavParams, public loadingCtrl: LoadingController,
              public remoteService: RemoteServiceProvider, public alertCtrl : AlertController) {

    this.objectblock.mobile = navParams.get('username');

  }

  ionViewDidLoad() {
  }

  submit() {
    this.error = 0;
    if (this.objectblock.mobile == "" || this.objectblock.mobile == undefined) {
      this.error = 1;
      this.openPage("1");
    }
    else if (!(/^\d{10}$/.test(this.objectblock.mobile))) {
      this.error = 1;
      this.openPage("1");
    }
    else if (this.objectblock.first == "" || this.objectblock.first == undefined) {
      this.error = 2;
      this.openPage("1");
    }
    else if (this.objectblock.second == "" || this.objectblock.second == undefined) {
      this.error = 3;
      this.openPage("1");
    }
    else if (this.objectblock.last == "" || this.objectblock.last == undefined) {
      this.error = 4;
      this.openPage("1");
    }
    else if (this.objectblock.id == "" || this.objectblock.id == undefined) {
      this.error = 5;
      this.openPage("2");
    }
    else {

      this.objectblock.imsi = '';

      let loading = this.loadingCtrl.create({
        spinner: 'crescent',
        content: 'Sending registration request...'
      });

      loading.present();

      //send self registration request
      this.remoteService.postRequest(this.objectblock, "selfreg/show")
        .then(
          data => {

            loading.dismiss();


            this.presentAlert("Success", data['message']);


          }
        )
        .catch(
        error => {
          this.presentAlert("Error", "Self Registration not successful");
        }
      );


    }

  }


  public presentAlert(title: string, message: string) {
    let alert = this.alertCtrl.create({
      title: title,
      subTitle: message,
      buttons: [
        {
          text: 'Proceed',
          role: 'cancel',
          handler: () => {
            this.navCtrl.push('LoginPage');
          }
        }
        ]
    });
    alert.present();
  }

  openPage(page){
  	if(page=="1"){
  		this.firstform=true;
      this.selectedPage='pagerGrey';
      this.selectedPage2='pagerGreen';

  	}
  	else{
  		this.firstform=false;
      this.selectedPage='pagerGreen';
      this.selectedPage2='pagerGrey';
  	}
  }



}
