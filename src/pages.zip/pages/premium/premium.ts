import { Component } from '@angular/core';
import {AlertController, IonicPage, LoadingController, NavController, NavParams} from 'ionic-angular';
import {GlobalVarsProvider} from "../../providers/global-vars/global-vars";
import {RemoteServiceProvider} from "../../providers/remote-service/remote-service";

/**
 * Generated class for the PremiumPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */
@IonicPage()
@Component({
  selector: 'page-premium',
  templateUrl: 'premium.html',
})
export class PremiumPage {
  data: any;
  private error: number;
  private objectblock: any;

  constructor(public navCtrl: NavController, public globalVars: GlobalVarsProvider, public loadingCtrl: LoadingController,
              public remoteService: RemoteServiceProvider, public alertCtrl: AlertController) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad PremiumPage');
  }

  submit() {

    this.error = 0;

    if (this.objectblock.amount == "" || this.objectblock.amount == undefined) {
      this.error = 1;
    }
    else if (this.objectblock.billerName == "" || this.objectblock.billerName == undefined) {
      this.error = 2;
    }
    else if (this.objectblock.isOtherNumber == "" || this.objectblock.isOtherNumber == undefined) {
      this.error = 3;
    }
    else if (this.objectblock.accountFrom == "" || this.objectblock.accountFrom == undefined) {
      this.error = 4;
    }
    else {

      let alert = this.alertCtrl.create({
        title: 'AAR Just Cash',
        message: 'Are you sure you want to process this request?',
        buttons: [
          {
            text: 'No',
            role: 'cancel',
            handler: () => {
              this.globalVars.backToMainPage();
            }
          },
          {
            text: 'Yes',
            handler: () => {

              //PROCESS THE TRANSACTION
              this.postRequest();
            }
          }
        ]
      });
      alert.present();
    }
  }

  postRequest() {

    let loading = this.loadingCtrl.create({
      spinner: 'crescent',
      content: 'Processing Premium Request...'
    });

    loading.present();

    //send airtime purchase request
    this.remoteService.postRequest(this.objectblock, "premium/show")
      .then(
        data => {

          loading.dismiss();

          this.data = data;

          if (this.data.error === false) {
            this.globalVars.backToMainPage();
            this.globalVars.presentAlert("Premium", this.data.message.status);
          }
          else {
            this.globalVars.presentAlert("Premium Request Failed", this.data.message);

          }
        }
      )
      .catch(
        error => {
          loading.dismiss();

          this.globalVars.presentAlert("Error", "Premium failed. Kindly check your details and try again.");
        }
      );
  }

}
