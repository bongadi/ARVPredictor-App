import {Component} from '@angular/core';
import {IonicPage, NavController, NavParams, MenuController, LoadingController, AlertController} from 'ionic-angular';
import {Keyboard} from '@ionic-native/keyboard';
import {GlobalVarsProvider} from '../../providers/global-vars/global-vars';
import {RemoteServiceProvider} from "../../providers/remote-service/remote-service";
/*
import {SweetAlertService} from 'ng2-sweetalert2';
*/

/**
 * Generated class for the LoginPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */
@IonicPage()
@Component({
  selector: 'page-login',
  templateUrl: 'login.html',
})
export class LoginPage {
  objectblock: any = {};
  valueforngif: boolean = true;
  body: any;
  data: any;
  stage = "phone";
  encryptIsPresent = false;
  error: number = 0;

  constructor(public navCtrl: NavController, public navParams: NavParams, public menu: MenuController,
              public loadingCtrl: LoadingController,
              public remoteService: RemoteServiceProvider, public alertCtrl: AlertController,
              public globalVars: GlobalVarsProvider,
              public keyboard: Keyboard) {


    this.menu.swipeEnable(false);

  }
/*
  static get parameters() {
    return [[SweetAlertService]];
  }*/

  ionViewDidLoad() {

    this.keyboard.onKeyboardShow().subscribe(() => {
      this.valueforngif = false
    });

    this.keyboard.onKeyboardHide().subscribe(() => {
      this.valueforngif = true
    });
  }

  openPage(page, extras? : any) {
    this.navCtrl.push(page, extras);
  }

  openPinForm(objectblock) {
    this.getDetails();
  }

  getDetails() {
    this.error = 0;
    if (this.objectblock.username == "" || this.objectblock.username == undefined) {
      this.error = 1;
    }
    else if (!(/^\d{10}$/.test(this.objectblock.username))) {
      this.error = 2;
    }
    else {

      let loading = this.loadingCtrl.create({
        spinner: 'crescent',
        content: 'Checking Account Details...'
      });

      loading.present();

      //send login request
      this.remoteService.postRequest(this.objectblock, "signin/details")
        .then(
          data => {

            loading.dismiss();

            this.data = data;

            if(this.data.error === false) {

              //if is premium
              if(this.data.isPremium) {
                switch (this.data.userType) {
                  case 1:
                    this.globalVars.presentAlert('AAR Premium', this.data.message);
                    break;
                  case 2:
                    this.openPage('PremiumPage');
                    break;
                  default:
                    this.globalVars.presentAlert('AAR Premium', 'Dear Customer your category was not found. Please contact AAR support for assistance.');
                    break;

                }
                  return;
              }

              this.globalVars.authToken = this.data.token;

              if(this.data.message.firstlogin == 0) {
                //if you have  valid PIN
                this.stage = "pin";
              }

              /**
               * @ToDo - add check for firstlogin if AAR Staff / Pensioner
              */
              else if (this.data.message.isadvance != 3  ){
                this.stage = "changepin";

              }

              else {
                //if you don't have valid PIN
                this.stage = "id";

              }

            }
            else {
              if(this.data.selfReg == true) {
                this.openPage('RegisterPage', {username : this.objectblock.username});

                this.globalVars.presentAlert("Self Registration", this.data.message);

              }
              else {
                this.globalVars.presentAlert("Failed", this.data.message);

              }

            }
          }
        )
        .catch(error => {
          loading.dismiss();
          this.globalVars.presentAlert("Failed", "Could not connect to AAR system. Check your internet connection.");

        });

    }

  }

  submit() {
    this.error = 0;
    if (this.objectblock.username == "" || this.objectblock.username == undefined) {
      this.error = 1;
    }
    else if (!(/^\d{10}$/.test(this.objectblock.username))) {
      this.error = 2;
    }
    else if (this.objectblock.password == "" || this.objectblock.password == undefined) {
      this.error = 3;
    } else if (!(/^\d{4}$/.test(this.objectblock.password))) {
      this.error = 4;
    }
    else {

      let loading = this.loadingCtrl.create({
        spinner: 'crescent',
        content: 'Logging In...'
      });

      loading.present();

      //send login request
      this.remoteService.postRequest(this.objectblock, "signin/show")
        .then(
          data => {

            loading.dismiss();

            this.data = data;

            if(this.data.error === false) {
              this.navCtrl.setRoot('MainPage', {global: this.globalVars});
              this.globalVars.setCustomerDetails(this.data.message);
            }
            else {

              if(this.data.beginFirstRegistration == true) {
                this.stage = "id";
                this.globalVars.presentAlert("Failed", this.data.message);

              }

              else{
                this.globalVars.presentAlert("Failed", this.data.message);

              }

            }
          }
        )
        .catch(error => {
          loading.dismiss();
          this.globalVars.presentAlert("Failed", "Could not connect to AAR system. Check your internet connection.");

        });

    }

  }


  activatepin() {
    this.error = 0;

    if (this.objectblock.IDNumber == "" || this.objectblock.IDNumber == undefined) {
      this.error = 5;
    }
    else {

      let loading = this.loadingCtrl.create({
        spinner: 'crescent',
        content: 'Logging In...'
      });

      loading.present();

      //send login request
      this.remoteService.postRequest(this.objectblock, "signin/activatepin")
        .then(
          data => {

            loading.dismiss();

            this.data = data;

            if(this.data.error === false) {
              this.stage = 'pin';
              this.globalVars.presentAlert("Success", this.data.message);
            }
            else {
              this.globalVars.presentAlert("Failed", this.data.message);

            }
          }
        )
        .catch(error => {
          loading.dismiss();
          this.globalVars.presentAlert("Failed", "Could not connect to AAR system. Check your internet connection.");

        });

    }

  }


  firstchangepin() {

    this.error = 0;

    if (this.objectblock.oldpass === "" || this.objectblock.oldpass == undefined) {
      this.error = 1;
    }
    else if (this.objectblock.newpass === "" || this.objectblock.newpass == undefined) {
      this.error = 2;
    }
    else if (this.objectblock.newpassconfirm === "" || this.objectblock.newpassconfirm == undefined) {
      this.error = 3;
    }
    else if (this.objectblock.newpassconfirm !== this.objectblock.newpass) {
      this.error = 4;
    }
    else {

      let loading = this.loadingCtrl.create({
        spinner: 'crescent',
        content: 'Sending Change Pin request...'
      });

      loading.present();

      //send airtime purchase request
      this.remoteService.postRequest(this.objectblock, "pin/show")
        .then(
          data => {

            loading.dismiss();

            this.data = data;

            if(this.data.error === false) {

              this.globalVars.presentAlert("Change Pin Successful", this.data.message.status);

              //if you have  valid PIN
              this.stage = 'phone';

            }
            else {
              this.globalVars.presentAlert(" Change Pin Failed", this.data.message.status);

            }
          }
        )
        .catch(
          error => {
            loading.dismiss();

            this.globalVars.presentAlert("Error", " Change Pin not successful");
          }
        );
    }

  }

  singlesignin () {

    let loading = this.loadingCtrl.create({
      spinner: 'crescent',
      content: 'Sending Change Pin request...'
    });

    loading.present();

    //send airtime purchase request
    this.remoteService.postRequest(this.objectblock, "singlesignin/show")
      .then(
        data => {

          loading.dismiss();

          this.data = data;

          if(this.data.error === false) {

            this.globalVars.presentAlert("Change Pin Successful", this.data.message.status);

            //if you have  valid PIN
            this.stage = 'phone';

          }
          else {
            this.globalVars.presentAlert(" Change Pin Failed", this.data.message.status);

          }
        }
      )
      .catch(
        error => {
          loading.dismiss();

          this.globalVars.presentAlert("Error", " Change Pin not successful");
        }
      );

  }

}
