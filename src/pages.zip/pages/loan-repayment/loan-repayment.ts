import { Component } from '@angular/core';
import {AlertController, IonicPage, LoadingController, NavController} from 'ionic-angular';
import {GlobalVarsProvider} from "../../providers/global-vars/global-vars";
import {RemoteServiceProvider} from "../../providers/remote-service/remote-service";

/**
 * Generated class for the LoanRepaymentPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */
@IonicPage()
@Component({
  selector: 'page-loan-repayment',
  templateUrl: 'loan-repayment.html',
})
export class LoanRepaymentPage {

  accounts:any;

  objectblock: any = {};
  data:any;
  periods: any = [];
  ltypes: any = [];
  tills: any;

  error: number = 0;

  private loanCategory: any;
  private loanCategories: any;

  private loanaccounts: any;
  isNumeric : any = GlobalVarsProvider.isNumeric;

  constructor(public navCtrl: NavController, public globalVars: GlobalVarsProvider, public loadingCtrl: LoadingController,
              public remoteService: RemoteServiceProvider, public alertCtrl: AlertController) {

    this.accounts = this.globalVars.accounts;
    this.loanaccounts = this.globalVars.loanaccounts;
    this.loanCategories = GlobalVarsProvider.LOANCATEGORIES;

    this.objectblock.accountnumber = this.accounts[0];
    this.objectblock.username = this.globalVars.mwalletAccount;

    this.objectblock.accountFrom = this.accounts[0];
    this.objectblock.username = this.globalVars.mwalletAccount;

  }

  ionViewDidLoad() {
    if(!this.globalVars.loanaccounts || (this.globalVars.loanaccounts.length < 1) ) {

      this.globalVars.backToMainPage();

      this.globalVars.presentAlert("AAR Just Cash",
        "Dear, " + this.globalVars.customername + ", you do not have an outstanding loan.");
    }
  }

  backToMainPage(page){
    this.navCtrl.setRoot(page);
  }

  onselectLoanAccount(event) {

    let loanName: string = event.loan_product_name;


    if (loanName.toLowerCase().includes('fixed')) {
      this.loanCategory = this.loanCategories.TILLLOAN;
      this.objectblock.FINProcessed = "MM";
    }

    else if (loanName.toLowerCase().includes('pensioner')) {
      this.loanCategory = this.loanCategories.PENSIONERLOAN;
      this.objectblock.FINProcessed = "CC";

    }

    else if (loanName.toLowerCase().includes('staff')) {
      this.loanCategory = this.loanCategories.STAFFLOAN;
      this.objectblock.FINProcessed = "CC";

    }

    else if (loanName.toLowerCase().includes('advance')) {
      this.loanCategory = this.loanCategories.ADVANCELOAN;
      this.objectblock.FINProcessed = "MM";

    }

  }

  submit() {

    this.error = 0;

    if (this.objectblock.amount == "" || this.objectblock.amount == undefined) {
      this.error = 1;
    }
    else if (this.objectblock.accountFrom == "" || this.objectblock.accountFrom == undefined) {
      this.error = 2;
    }
    else if (this.objectblock.loanaccount == "" || this.objectblock.loanaccount == undefined) {
      this.error = 3;
    }
    else {

      this.objectblock.loanAccount = this.objectblock.loanaccount.loan_account_name;


      let alert = this.alertCtrl.create({
        title: 'AAR Just Cash',
        message: "Please confirm loan repayment KES " + this.objectblock.amount +
        " for loan " + this.objectblock.loanaccount.loan_product_name,
        buttons: [
          {
            text: 'Cancel',
            role: 'cancel',
            handler: () => {
              this.globalVars.backToMainPage();

            }
          },
          {
            text: 'Accept',
            handler: () => {

              //PROCESS THE TRANSACTION
              this.postRequest();
            }
          }
        ]
      });
      alert.present();
    }

  }

  postRequest() {

    let loading = this.loadingCtrl.create({
      spinner: 'crescent',
      content: 'Sending Loan repayment request...'
    });

    loading.present();

    //send loan application request
    this.remoteService.postRequest(this.objectblock, "loans/repay/show")
      .then(
        data => {
          loading.dismiss();
          this.data = data;

          if (this.data.error === false) {
            this.globalVars.backToMainPage();

            this.globalVars.presentAlert("AAR Just Cash",
              "Dear, " + this.globalVars.customername + "," +
              " your payment of KShs " + this.objectblock.amount +
              " has been credited to your loan account.");

          }
          else {
            this.globalVars.presentAlert("AAR Just Cash", this.data.message);

          }

        }
      )
      .catch(
        error => {
          loading.dismiss();
          this.globalVars.presentAlert("AAR Just Cash", "Loan Application not successful. \n Kindly check your details and try again");
        }
      );

  }

}
