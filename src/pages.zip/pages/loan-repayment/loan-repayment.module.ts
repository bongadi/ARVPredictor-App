import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { LoanRepaymentPage } from './loan-repayment';

@NgModule({
  declarations: [
    LoanRepaymentPage,
  ],
  imports: [
    IonicPageModule.forChild(LoanRepaymentPage),
  ],
  exports: [
    LoanRepaymentPage
  ]
})
export class LoanRepaymentPageModule {}
