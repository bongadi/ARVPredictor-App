import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ApplyPage } from './apply';

@NgModule({
  declarations: [
    ApplyPage,
  ],
  imports: [
    IonicPageModule.forChild(ApplyPage),
  ],
  exports: [
    ApplyPage
  ]
})
export class ApplyPageModule {}
