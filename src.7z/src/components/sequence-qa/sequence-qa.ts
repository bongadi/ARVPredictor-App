import { Component, OnInit, OnChanges, ViewChild, ElementRef, Input, ViewEncapsulation } from '@angular/core';	
import * as d3 from 'd3';
import timelines from '../timelines';

//import * as d3 from 'd3-selection';
import * as d3Scale from "d3-scale";
import * as d3Array from "d3-array";
import * as d3Axis from "d3-axis";

/**
 * Generated class for the LoanRepaymentPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */


@Component({
  selector: 'sequence-qa',
  templateUrl: 'sequence-qa.html'
})
export class SequenceQaComponent {

    @Input('data')
	alignedGeneSequences?: any;

	@Input('title')
	title = 'D3.js with Ionic 2!';

	@ViewChild('chart') private chartContainer: ElementRef;	
	@ViewChild('timeline1') private timelineContainer: ElementRef;	

  	@Input() private data: Array<any>;	  
  	private margin: any = { 
  		top: 20, bottom: 20, left: 20, right: 20
  	};	  
  	private chart: any;	  
  	private width: number;	  
  	private height: number;	  
  	private xScale: any;	  
  	private yScale: any;	  
  	private colors: any;	  
  	private xAxis: any;	  
  	private yAxis: any;

  	constructor() {
    	console.log('Hello SequenceQaComponent Component');
	
  	}

  	ngOnInit() {
        this.createChart();	
          if (this.data) {	
              	console.log(this.data);
      
          	//this.updateChart();	    
          }
  	}

  	ngOnChanges() {	    
  		if (this.chart) {	      
  			//this.updateChart();	    
  		}
  	}

	createChart () {

		var chart = timelines()
          .stack()
          .margin({left:70, right:30, top:0, bottom:0})
          .hover(function (d, i, datum) {
          // d is the current rendering object
          // i is the index during d3 rendering
          // datum is the id object
            var div = $('#hoverRes');
            var colors = chart.colors();
            div.find('.coloredDiv').css('background-color', colors(i))
            div.find('#name').text(datum.label);
          })
          .click(function (d, i, datum) {
            alert(datum.label);
          })
          .scroll(function (x, scale) {
            $("#scrolled_date").text(scale.invert(x) + " to " + scale.invert(x+this.width));
          }); // toggle between rectangles and circles
           
            var testDataRelative = [
		        {times: [
		        	{"starting_time": 1355752700000, "ending_time": 1355752900000}, 
		        	{"starting_time": 1355767890000, "ending_time": 1355767910000},
		        	{"starting_time": 1355759900000, "ending_time": 1355759920000},
		        	{"starting_time": 1355761900000, "ending_time": 1355761920000}
		        	]}
		      	];

  	 	const element = this.timelineContainer.nativeElement;	    

		var svg = d3.select(element).append("svg").attr("width", 500)
			.datum(testDataRelative).call(chart);
	}

}
