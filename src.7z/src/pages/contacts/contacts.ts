import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { Contacts, ContactField, Contact } from '@ionic-native/contacts';


/**
 * Generated class for the ContactsPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */
@IonicPage()
@Component({
  selector: 'page-contacts',
  templateUrl: 'contacts.html',
})
export class ContactsPage {

  constructor(public navCtrl: NavController, public navParams: NavParams, private contacts: Contacts) {
  }

  ionViewDidLoad() {
  }

  addContact(newContact:any) {
    let contact: Contact = this.contacts.create();
    contact.displayName = newContact.displayName;
    contact.nickname = newContact.nickName;

    var field = new ContactField();
    field.type = newContact.phoneType;
    field.value = newContact.phoneNumber;
    field.pref = true;

    var numberSection = [];
    numberSection.push( field );
    contact.phoneNumbers = numberSection;

    contact.save().then((value) => {
      this.navCtrl.pop();
    }, (error) => {
    })
  }

}
