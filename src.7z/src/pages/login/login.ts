import {Component, ViewChild} from '@angular/core';
import {AlertController, IonicPage, LoadingController, MenuController, NavController, NavParams} from 'ionic-angular';
import {Keyboard} from '@ionic-native/keyboard';
import {GlobalVarsProvider} from '../../providers/global-vars/global-vars';
import {RemoteServiceProvider} from "../../providers/remote-service/remote-service";
import {PhoneService} from '../../providers/phone-service/phone-service';

/*
import {SweetAlertService} from 'ng2-sweetalert2';
*/
import {GooglePlus} from '@ionic-native/google-plus';


/**
 * Generated class for the LoginPage page.
 *
 * See http://ionicframework.com/docs/components/#navigation for more info
 * on Ionic pages and navigation.
 */
@IonicPage()
@Component({
  selector: 'page-login',
  templateUrl: 'login.html',
  providers: [GooglePlus]
})
export class LoginPage {
  @ViewChild('sequenceChart') sequenceChart;

  objectblock: any = {};
  valueforngif: boolean = false;
  demo: boolean = false;
  body: any;
  data: any;
  stage = "phone";
  encryptIsPresent = false;
  error: number = 0;
  errorMessage: string = '';

  geneSequenceResponse: any;
  displayName: any;
  email: any;
  familyName: any;
  givenName: any;
  userId: any;
  imageUrl: any;
  isLoggedIn: boolean = false;

  /*
  static get parameters() {
    return [[SweetAlertService]];
  }*/
  private sequenceChartData: any = {};

  constructor(public navCtrl: NavController, public navParams: NavParams, public menu: MenuController,
              public loadingCtrl: LoadingController,
              public remoteService: RemoteServiceProvider, public alertCtrl: AlertController,
              public globalVars: GlobalVarsProvider,
              public keyboard: Keyboard, private googlePlus: GooglePlus, private phoneService: PhoneService) {
  
    var currentUser = Meteor.user();

    if (currentUser) {
      this.openPage('MainPage');
      return;
    }

    this.menu.swipeEnable(false);

    this.geneSequenceResponse = {
      "data": {
        "viewer": {
          "currentVersion": {"text": "8.5", "publishDate": "2018-04-16"},
          "sequenceAnalysis": [{
            "inputSequence": {
              "header": "AY030412",
              "sequence": "CCTCAAATCACTCTTTGGCAACGACCCATCGTCACAATAAAGATAGGGGGGCAGCTAARGGAAGCTCTATTAGATACAGGAGCAGATGATACAGTATTAGAAGATATAAATTTGCCAGGAAGATGGACACCAAAAATKATAGTGGGAATTGGAGGTTTTACCAAAGTAAGACAGTATGATCAGATACCTGTAGAAATTTGTGGACATAAAGCTATAGGTACAGTRTTAGTAGGACCTACACCTGCCAACATAATTGGAAGAAATCTGTTGACYCAGATTGGTTGCACTTTAAATTTTCCCATTAGTCCTATTGACACTGTACCAGTAAAATTAAAGCCAGGAATGGATGGCCCAAAAGTTAAACAATGGCCATTGACAGAAGAAAAAATAAAAGCATTAGTAGAAATTTGTGCAGAATTGGAASAGGACGGGAAAATTTCAAAAATTGGGCCTGAAAATCCATACAATACTCCAGTATTTGCCATAAAGAAAAAGAACAGYGATAAATGGAGAAAATTAGTAGATTTCAGAGAACTTAATAAGAGAACTCAAGACTTCTGGGAAGTTCAATTAGGAATACCACATCCCGGAGGGTTAAAAAAGAACAAATCAGTAACAGTACTGGATGTGGGTGATGCATATTTTTCARTTCCCTTAGATGAAGACTTCAGGAAGTATACTGCATTTACCATACCTAGTATAAACAATGAGACACCAGGGACTAGATATCAGTACAATGTGCTTCCACAGGGATGGAAAGGATCACCAGCAATATTCCAAAGTAGCATGACAAGAATCTTAGAACCTTTTAGAAAACAGAATCCAGACATAGTTATCTGTCAATAYGTGGATGATTTGTATGTAGGATCTGACTTAGAAATAGAGMAGCATAGAACAAAAGTAGAGGAACTGAGACAACATTTGTGGAAGTGGGGNTTTTACACACCAGACAAMAAACATCAGAAAGAACCTCCATTCCTTTGGATGGGTTATGAACTCCATCCTGATAAATGGACA",
              "MD5": "dfa466f3b9faddd50457b2168f063517",
              "SHA512": "ba70661d52be5085f2af385601eba95b5016eac4be76e5a7376249fcd3dc36a7371f24b28ec2e131e6c56fb888b0bbe551d43fce20afba1314dfa17ce9a2c3c6"
            },
            "validationResults": [],
            "absoluteFirstNA": 2253,
            "alignedGeneSequences": [{
              "gene": {
                "name": "PR",
                "consensus": "PQITLWQRPLVTIKIGGQLKEALLDTGADDTVLEEMNLPGRWKPKMIGGIGGFIKVRQYDQILIEICGHKAIGTVLVGPTPVNIIGRNLLTQIGCTLNF",
                "length": 99,
                "drugClasses": [{
                  "name": "PI",
                  "fullName": "Protease Inhibitor",
                  "drugs": [{"name": "ATV", "displayAbbr": "ATV/r", "fullName": "atazanavir/r"}, {
                    "name": "DRV",
                    "displayAbbr": "DRV/r",
                    "fullName": "darunavir/r"
                  }, {"name": "FPV", "displayAbbr": "FPV/r", "fullName": "fosamprenavir/r"}, {
                    "name": "IDV",
                    "displayAbbr": "IDV/r",
                    "fullName": "indinavir/r"
                  }, {"name": "LPV", "displayAbbr": "LPV/r", "fullName": "lopinavir/r"}, {
                    "name": "NFV",
                    "displayAbbr": "NFV",
                    "fullName": "nelfinavir"
                  }, {"name": "SQV", "displayAbbr": "SQV/r", "fullName": "saquinavir/r"}, {
                    "name": "TPV",
                    "displayAbbr": "TPV/r",
                    "fullName": "tipranavir/r"
                  }]
                }],
                "mutationTypes": ["Major", "Accessory", "Other"]
              },
              "firstAA": 1,
              "lastAA": 99,
              "firstNA": 1,
              "lastNA": 297,
              "matchPcnt": 88.88888549804688,
              "prettyPairwise": {
                "positionLine": [" 1 ", " 2 ", " 3 ", " 4 ", " 5 ", " 6 ", " 7 ", " 8 ", " 9 ", "10 ", "11 ", "12 ", "13 ", "14 ", "15 ", "16 ", "17 ", "18 ", "19 ", "20 ", "21 ", "22 ", "23 ", "24 ", "25 ", "26 ", "27 ", "28 ", "29 ", "30 ", "31 ", "32 ", "33 ", "34 ", "35 ", "36 ", "37 ", "38 ", "39 ", "40 ", "41 ", "42 ", "43 ", "44 ", "45 ", "46 ", "47 ", "48 ", "49 ", "50 ", "51 ", "52 ", "53 ", "54 ", "55 ", "56 ", "57 ", "58 ", "59 ", "60 ", "61 ", "62 ", "63 ", "64 ", "65 ", "66 ", "67 ", "68 ", "69 ", "70 ", "71 ", "72 ", "73 ", "74 ", "75 ", "76 ", "77 ", "78 ", "79 ", "80 ", "81 ", "82 ", "83 ", "84 ", "85 ", "86 ", "87 ", "88 ", "89 ", "90 ", "91 ", "92 ", "93 ", "94 ", "95 ", "96 ", "97 ", "98 ", "99 "],
                "refAALine": [" P ", " Q ", " I ", " T ", " L ", " W ", " Q ", " R ", " P ", " L ", " V ", " T ", " I ", " K ", " I ", " G ", " G ", " Q ", " L ", " K ", " E ", " A ", " L ", " L ", " D ", " T ", " G ", " A ", " D ", " D ", " T ", " V ", " L ", " E ", " E ", " M ", " N ", " L ", " P ", " G ", " R ", " W ", " K ", " P ", " K ", " M ", " I ", " G ", " G ", " I ", " G ", " G ", " F ", " I ", " K ", " V ", " R ", " Q ", " Y ", " D ", " Q ", " I ", " L ", " I ", " E ", " I ", " C ", " G ", " H ", " K ", " A ", " I ", " G ", " T ", " V ", " L ", " V ", " G ", " P ", " T ", " P ", " V ", " N ", " I ", " I ", " G ", " R ", " N ", " L ", " L ", " T ", " Q ", " I ", " G ", " C ", " T ", " L ", " N ", " F "],
                "alignedNAsLine": ["CCT", "CAA", "ATC", "ACT", "CTT", "TGG", "CAA", "CGA", "CCC", "ATC", "GTC", "ACA", "ATA", "AAG", "ATA", "GGG", "GGG", "CAG", "CTA", "ARG", "GAA", "GCT", "CTA", "TTA", "GAT", "ACA", "GGA", "GCA", "GAT", "GAT", "ACA", "GTA", "TTA", "GAA", "GAT", "ATA", "AAT", "TTG", "CCA", "GGA", "AGA", "TGG", "ACA", "CCA", "AAA", "ATK", "ATA", "GTG", "GGA", "ATT", "GGA", "GGT", "TTT", "ACC", "AAA", "GTA", "AGA", "CAG", "TAT", "GAT", "CAG", "ATA", "CCT", "GTA", "GAA", "ATT", "TGT", "GGA", "CAT", "AAA", "GCT", "ATA", "GGT", "ACA", "GTR", "TTA", "GTA", "GGA", "CCT", "ACA", "CCT", "GCC", "AAC", "ATA", "ATT", "GGA", "AGA", "AAT", "CTG", "TTG", "ACY", "CAG", "ATT", "GGT", "TGC", "ACT", "TTA", "AAT", "TTT"],
                "mutationLine": [" - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " I ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", "KR ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " D ", " I ", " - ", " - ", " - ", " - ", " - ", " - ", " T ", " - ", " - ", "MI ", " - ", " V ", " - ", " - ", " - ", " - ", " - ", " T ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " P ", " V ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " A ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - "]
              },
              "mutations": [{
                "consensus": "L",
                "position": 10,
                "AAs": "I",
                "triplet": "ATC",
                "insertedNAs": "",
                "isInsertion": false,
                "isDeletion": false,
                "isIndel": false,
                "isAmbiguous": false,
                "isApobecMutation": false,
                "isApobecDRM": false,
                "hasStop": false,
                "isUnusual": false,
                "types": ["Other"],
                "primaryType": "Other",
                "comments": [{
                  "triggeredAAs": "I",
                  "type": "Other",
                  "text": "L10I/V are polymorphic, PI-selected accessory mutations that increase the replication of viruses with other PI-resistance mutations."
                }],
                "text": "L10I",
                "shortText": "L10I"
              }, {
                "consensus": "K",
                "position": 20,
                "AAs": "KR",
                "triplet": "ARG",
                "insertedNAs": "",
                "isInsertion": false,
                "isDeletion": false,
                "isIndel": false,
                "isAmbiguous": false,
                "isApobecMutation": false,
                "isApobecDRM": false,
                "hasStop": false,
                "isUnusual": false,
                "types": ["Other"],
                "primaryType": "Other",
                "comments": [{
                  "triggeredAAs": "R",
                  "type": "Other",
                  "text": "K20R is a highly polymorphic PI-selected accessory mutation."
                }],
                "text": "K20KR",
                "shortText": "K20KR"
              }, {
                "consensus": "E",
                "position": 35,
                "AAs": "D",
                "triplet": "GAT",
                "insertedNAs": "",
                "isInsertion": false,
                "isDeletion": false,
                "isIndel": false,
                "isAmbiguous": false,
                "isApobecMutation": false,
                "isApobecDRM": false,
                "hasStop": false,
                "isUnusual": false,
                "types": ["Other"],
                "primaryType": "Other",
                "comments": [],
                "text": "E35D",
                "shortText": "E35D"
              }, {
                "consensus": "M",
                "position": 36,
                "AAs": "I",
                "triplet": "ATA",
                "insertedNAs": "",
                "isInsertion": false,
                "isDeletion": false,
                "isIndel": false,
                "isAmbiguous": false,
                "isApobecMutation": false,
                "isApobecDRM": false,
                "hasStop": false,
                "isUnusual": false,
                "types": ["Other"],
                "primaryType": "Other",
                "comments": [],
                "text": "M36I",
                "shortText": "M36I"
              }, {
                "consensus": "K",
                "position": 43,
                "AAs": "T",
                "triplet": "ACA",
                "insertedNAs": "",
                "isInsertion": false,
                "isDeletion": false,
                "isIndel": false,
                "isAmbiguous": false,
                "isApobecMutation": false,
                "isApobecDRM": false,
                "hasStop": false,
                "isUnusual": false,
                "types": ["Accessory"],
                "primaryType": "Accessory",
                "comments": [{
                  "triggeredAAs": "T",
                  "type": "Accessory",
                  "text": "K43T is a non-polymorphic PI-selected accessory mutation. K43T is included in the Boehringer-Ingelheim TPV genotypic susceptibility score."
                }],
                "text": "K43T",
                "shortText": "K43T"
              }, {
                "consensus": "M",
                "position": 46,
                "AAs": "IM",
                "triplet": "ATK",
                "insertedNAs": "",
                "isInsertion": false,
                "isDeletion": false,
                "isIndel": false,
                "isAmbiguous": false,
                "isApobecMutation": false,
                "isApobecDRM": true,
                "hasStop": false,
                "isUnusual": false,
                "types": ["Major"],
                "primaryType": "Major",
                "comments": [{
                  "triggeredAAs": "I",
                  "type": "Major",
                  "text": "M46I/L are relatively non-polymorphic PI-selected mutations. In combination with other PI-resistance mutations, they are associated with reduced susceptibility to each of the PIs except DRV."
                }],
                "text": "M46MI",
                "shortText": "M46MI"
              }, {
                "consensus": "G",
                "position": 48,
                "AAs": "V",
                "triplet": "GTG",
                "insertedNAs": "",
                "isInsertion": false,
                "isDeletion": false,
                "isIndel": false,
                "isAmbiguous": false,
                "isApobecMutation": false,
                "isApobecDRM": false,
                "hasStop": false,
                "isUnusual": false,
                "types": ["Major"],
                "primaryType": "Major",
                "comments": [{
                  "triggeredAAs": "V",
                  "type": "Major",
                  "text": "G48V is a non-polymorphic mutation selected by SQV and, less often, by IDV and LPV. It confers high-level resistance to SQV, intermediate resistance to ATV, and low-level resistance to NFV, IDV and LPV."
                }],
                "text": "G48V",
                "shortText": "G48V"
              }, {
                "consensus": "I",
                "position": 54,
                "AAs": "T",
                "triplet": "ACC",
                "insertedNAs": "",
                "isInsertion": false,
                "isDeletion": false,
                "isIndel": false,
                "isAmbiguous": false,
                "isApobecMutation": false,
                "isApobecDRM": false,
                "hasStop": false,
                "isUnusual": false,
                "types": ["Major"],
                "primaryType": "Major",
                "comments": [{
                  "triggeredAAs": "T",
                  "type": "Major",
                  "text": "I54A/T/S are non-polymorphic PI-selected mutations that occur almost exclusively in viruses with multiple PI-resistance mutations. I54A/T/S are associated with reduced susceptibility to each of the PIs except DRV."
                }],
                "text": "I54T",
                "shortText": "I54T"
              }, {
                "consensus": "L",
                "position": 63,
                "AAs": "P",
                "triplet": "CCT",
                "insertedNAs": "",
                "isInsertion": false,
                "isDeletion": false,
                "isIndel": false,
                "isAmbiguous": false,
                "isApobecMutation": false,
                "isApobecDRM": false,
                "hasStop": false,
                "isUnusual": false,
                "types": ["Other"],
                "primaryType": "Other",
                "comments": [],
                "text": "L63P",
                "shortText": "L63P"
              }, {
                "consensus": "I",
                "position": 64,
                "AAs": "V",
                "triplet": "GTA",
                "insertedNAs": "",
                "isInsertion": false,
                "isDeletion": false,
                "isIndel": false,
                "isAmbiguous": false,
                "isApobecMutation": false,
                "isApobecDRM": false,
                "hasStop": false,
                "isUnusual": false,
                "types": ["Other"],
                "primaryType": "Other",
                "comments": [],
                "text": "I64V",
                "shortText": "I64V"
              }, {
                "consensus": "V",
                "position": 82,
                "AAs": "A",
                "triplet": "GCC",
                "insertedNAs": "",
                "isInsertion": false,
                "isDeletion": false,
                "isIndel": false,
                "isAmbiguous": false,
                "isApobecMutation": false,
                "isApobecDRM": false,
                "hasStop": false,
                "isUnusual": false,
                "types": ["Major"],
                "primaryType": "Major",
                "comments": [{
                  "triggeredAAs": "A",
                  "type": "Major",
                  "text": "V82A is a non-polymorphic mutation selected primarily by IDV and LPV. It reduces susceptibility to these PIs and contributes cross-resistance to each of the remaining PIs except DRV and TPV."
                }],
                "text": "V82A",
                "shortText": "V82A"
              }],
              "APOBEC": [],
              "APOBEC_DRM": [{"text": "M46I"}],
              "DRM": [{"text": "K43T"}, {"text": "M46MI"}, {"text": "G48V"}, {"text": "I54T"}, {"text": "V82A"}],
              "SDRM": [{"text": "M46I"}, {"text": "G48V"}, {"text": "I54T"}, {"text": "V82A"}],
              "unusualMutations": [],
              "treatmentSelectedMutations": [],
              "frameShifts": []
            }, {
              "gene": {
                "name": "RT",
                "consensus": "PISPIETVPVKLKPGMDGPKVKQWPLTEEKIKALVEICTEMEKEGKISKIGPENPYNTPVFAIKKKDSTKWRKLVDFRELNKRTQDFWEVQLGIPHPAGLKKKKSVTVLDVGDAYFSVPLDKDFRKYTAFTIPSINNETPGIRYQYNVLPQGWKGSPAIFQSSMTKILEPFRKQNPDIVIYQYMDDLYVGSDLEIGQHRTKIEELRQHLLRWGFTTPDKKHQKEPPFLWMGYELHPDKWTVQPIVLPEKDSWTVNDIQKLVGKLNWASQIYAGIKVKQLCKLLRGTKALTEVIPLTEEAELELAENREILKEPVHGVYYDPSKDLIAEIQKQGQGQWTYQIYQEPFKNLKTGKYARMRGAHTNDVKQLTEAVQKIATESIVIWGKTPKFKLPIQKETWEAWWTEYWQATWIPEWEFVNTPPLVKLWYQLEKEPIVGAETFYVDGAANRETKLGKAGYVTDRGRQKVVSLTDTTNQKTELQAIHLALQDSGLEVNIVTDSQYALGIIQAQPDKSESELVSQIIEQLIKKEKVYLAWVPAHKGIGGNEQVDKLVSAGIRKVL",
                "length": 560,
                "drugClasses": [{
                  "name": "NRTI",
                  "fullName": "Nucleoside Reverse Transcriptase Inhibitor",
                  "drugs": [{"name": "ABC", "displayAbbr": "ABC", "fullName": "abacavir"}, {
                    "name": "AZT",
                    "displayAbbr": "AZT",
                    "fullName": "zidovudine"
                  }, {"name": "D4T", "displayAbbr": "D4T", "fullName": "stavudine"}, {
                    "name": "DDI",
                    "displayAbbr": "DDI",
                    "fullName": "didanosine"
                  }, {"name": "FTC", "displayAbbr": "FTC", "fullName": "emtricitabine"}, {
                    "name": "LMV",
                    "displayAbbr": "3TC",
                    "fullName": "lamivudine"
                  }, {"name": "TDF", "displayAbbr": "TDF", "fullName": "tenofovir"}]
                }, {
                  "name": "NNRTI",
                  "fullName": "Non-nucleoside Reverse Transcriptase Inhibitor",
                  "drugs": [{"name": "EFV", "displayAbbr": "EFV", "fullName": "efavirenz"}, {
                    "name": "ETR",
                    "displayAbbr": "ETR",
                    "fullName": "etravirine"
                  }, {"name": "NVP", "displayAbbr": "NVP", "fullName": "nevirapine"}, {
                    "name": "RPV",
                    "displayAbbr": "RPV",
                    "fullName": "rilpivirine"
                  }]
                }],
                "mutationTypes": ["NRTI", "NNRTI", "Other"]
              },
              "firstAA": 1,
              "lastAA": 240,
              "firstNA": 298,
              "lastNA": 1017,
              "matchPcnt": 90.83333587646484,
              "prettyPairwise": {
                "positionLine": [" 1 ", " 2 ", " 3 ", " 4 ", " 5 ", " 6 ", " 7 ", " 8 ", " 9 ", "10 ", "11 ", "12 ", "13 ", "14 ", "15 ", "16 ", "17 ", "18 ", "19 ", "20 ", "21 ", "22 ", "23 ", "24 ", "25 ", "26 ", "27 ", "28 ", "29 ", "30 ", "31 ", "32 ", "33 ", "34 ", "35 ", "36 ", "37 ", "38 ", "39 ", "40 ", "41 ", "42 ", "43 ", "44 ", "45 ", "46 ", "47 ", "48 ", "49 ", "50 ", "51 ", "52 ", "53 ", "54 ", "55 ", "56 ", "57 ", "58 ", "59 ", "60 ", "61 ", "62 ", "63 ", "64 ", "65 ", "66 ", "67 ", "68 ", "69 ", "70 ", "71 ", "72 ", "73 ", "74 ", "75 ", "76 ", "77 ", "78 ", "79 ", "80 ", "81 ", "82 ", "83 ", "84 ", "85 ", "86 ", "87 ", "88 ", "89 ", "90 ", "91 ", "92 ", "93 ", "94 ", "95 ", "96 ", "97 ", "98 ", "99 ", "100", "101", "102", "103", "104", "105", "106", "107", "108", "109", "110", "111", "112", "113", "114", "115", "116", "117", "118", "119", "120", "121", "122", "123", "124", "125", "126", "127", "128", "129", "130", "131", "132", "133", "134", "135", "136", "137", "138", "139", "140", "141", "142", "143", "144", "145", "146", "147", "148", "149", "150", "151", "152", "153", "154", "155", "156", "157", "158", "159", "160", "161", "162", "163", "164", "165", "166", "167", "168", "169", "170", "171", "172", "173", "174", "175", "176", "177", "178", "179", "180", "181", "182", "183", "184", "185", "186", "187", "188", "189", "190", "191", "192", "193", "194", "195", "196", "197", "198", "199", "200", "201", "202", "203", "204", "205", "206", "207", "208", "209", "210", "211", "212", "213", "214", "215", "216", "217", "218", "219", "220", "221", "222", "223", "224", "225", "226", "227", "228", "229", "230", "231", "232", "233", "234", "235", "236", "237", "238", "239", "240"],
                "refAALine": [" P ", " I ", " S ", " P ", " I ", " E ", " T ", " V ", " P ", " V ", " K ", " L ", " K ", " P ", " G ", " M ", " D ", " G ", " P ", " K ", " V ", " K ", " Q ", " W ", " P ", " L ", " T ", " E ", " E ", " K ", " I ", " K ", " A ", " L ", " V ", " E ", " I ", " C ", " T ", " E ", " M ", " E ", " K ", " E ", " G ", " K ", " I ", " S ", " K ", " I ", " G ", " P ", " E ", " N ", " P ", " Y ", " N ", " T ", " P ", " V ", " F ", " A ", " I ", " K ", " K ", " K ", " D ", " S ", " T ", " K ", " W ", " R ", " K ", " L ", " V ", " D ", " F ", " R ", " E ", " L ", " N ", " K ", " R ", " T ", " Q ", " D ", " F ", " W ", " E ", " V ", " Q ", " L ", " G ", " I ", " P ", " H ", " P ", " A ", " G ", " L ", " K ", " K ", " K ", " K ", " S ", " V ", " T ", " V ", " L ", " D ", " V ", " G ", " D ", " A ", " Y ", " F ", " S ", " V ", " P ", " L ", " D ", " K ", " D ", " F ", " R ", " K ", " Y ", " T ", " A ", " F ", " T ", " I ", " P ", " S ", " I ", " N ", " N ", " E ", " T ", " P ", " G ", " I ", " R ", " Y ", " Q ", " Y ", " N ", " V ", " L ", " P ", " Q ", " G ", " W ", " K ", " G ", " S ", " P ", " A ", " I ", " F ", " Q ", " S ", " S ", " M ", " T ", " K ", " I ", " L ", " E ", " P ", " F ", " R ", " K ", " Q ", " N ", " P ", " D ", " I ", " V ", " I ", " Y ", " Q ", " Y ", " M ", " D ", " D ", " L ", " Y ", " V ", " G ", " S ", " D ", " L ", " E ", " I ", " G ", " Q ", " H ", " R ", " T ", " K ", " I ", " E ", " E ", " L ", " R ", " Q ", " H ", " L ", " L ", " R ", " W ", " G ", " F ", " T ", " T ", " P ", " D ", " K ", " K ", " H ", " Q ", " K ", " E ", " P ", " P ", " F ", " L ", " W ", " M ", " G ", " Y ", " E ", " L ", " H ", " P ", " D ", " K ", " W ", " T "],
                "alignedNAsLine": ["CCC", "ATT", "AGT", "CCT", "ATT", "GAC", "ACT", "GTA", "CCA", "GTA", "AAA", "TTA", "AAG", "CCA", "GGA", "ATG", "GAT", "GGC", "CCA", "AAA", "GTT", "AAA", "CAA", "TGG", "CCA", "TTG", "ACA", "GAA", "GAA", "AAA", "ATA", "AAA", "GCA", "TTA", "GTA", "GAA", "ATT", "TGT", "GCA", "GAA", "TTG", "GAA", "SAG", "GAC", "GGG", "AAA", "ATT", "TCA", "AAA", "ATT", "GGG", "CCT", "GAA", "AAT", "CCA", "TAC", "AAT", "ACT", "CCA", "GTA", "TTT", "GCC", "ATA", "AAG", "AAA", "AAG", "AAC", "AGY", "GAT", "AAA", "TGG", "AGA", "AAA", "TTA", "GTA", "GAT", "TTC", "AGA", "GAA", "CTT", "AAT", "AAG", "AGA", "ACT", "CAA", "GAC", "TTC", "TGG", "GAA", "GTT", "CAA", "TTA", "GGA", "ATA", "CCA", "CAT", "CCC", "GGA", "GGG", "TTA", "AAA", "AAG", "AAC", "AAA", "TCA", "GTA", "ACA", "GTA", "CTG", "GAT", "GTG", "GGT", "GAT", "GCA", "TAT", "TTT", "TCA", "RTT", "CCC", "TTA", "GAT", "GAA", "GAC", "TTC", "AGG", "AAG", "TAT", "ACT", "GCA", "TTT", "ACC", "ATA", "CCT", "AGT", "ATA", "AAC", "AAT", "GAG", "ACA", "CCA", "GGG", "ACT", "AGA", "TAT", "CAG", "TAC", "AAT", "GTG", "CTT", "CCA", "CAG", "GGA", "TGG", "AAA", "GGA", "TCA", "CCA", "GCA", "ATA", "TTC", "CAA", "AGT", "AGC", "ATG", "ACA", "AGA", "ATC", "TTA", "GAA", "CCT", "TTT", "AGA", "AAA", "CAG", "AAT", "CCA", "GAC", "ATA", "GTT", "ATC", "TGT", "CAA", "TAY", "GTG", "GAT", "GAT", "TTG", "TAT", "GTA", "GGA", "TCT", "GAC", "TTA", "GAA", "ATA", "GAG", "MAG", "CAT", "AGA", "ACA", "AAA", "GTA", "GAG", "GAA", "CTG", "AGA", "CAA", "CAT", "TTG", "TGG", "AAG", "TGG", "GGN", "TTT", "TAC", "ACA", "CCA", "GAC", "AAM", "AAA", "CAT", "CAG", "AAA", "GAA", "CCT", "CCA", "TTC", "CTT", "TGG", "ATG", "GGT", "TAT", "GAA", "CTC", "CAT", "CCT", "GAT", "AAA", "TGG", "ACA"],
                "mutationLine": [" - ", " - ", " - ", " - ", " - ", " D ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " A ", " - ", " L ", " - ", "EQ ", " D ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " N ", " - ", " D ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " G ", " - ", " - ", " - ", " - ", " N ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", "VI ", " - ", " - ", " - ", " E ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " T ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " R ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " C ", " - ", " - ", " V ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " E ", "QK ", " - ", " - ", " - ", " - ", " V ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " W ", " K ", " - ", " - ", " - ", " Y ", " - ", " - ", " - ", "KN ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - "]
              },
              "mutations": [{
                "consensus": "E",
                "position": 6,
                "AAs": "D",
                "triplet": "GAC",
                "insertedNAs": "",
                "isInsertion": false,
                "isDeletion": false,
                "isIndel": false,
                "isAmbiguous": false,
                "isApobecMutation": false,
                "isApobecDRM": false,
                "hasStop": false,
                "isUnusual": false,
                "types": ["Other"],
                "primaryType": "Other",
                "comments": [],
                "text": "E6D",
                "shortText": "E6D"
              }, {
                "consensus": "T",
                "position": 39,
                "AAs": "A",
                "triplet": "GCA",
                "insertedNAs": "",
                "isInsertion": false,
                "isDeletion": false,
                "isIndel": false,
                "isAmbiguous": false,
                "isApobecMutation": false,
                "isApobecDRM": false,
                "hasStop": false,
                "isUnusual": false,
                "types": ["Other"],
                "primaryType": "Other",
                "comments": [],
                "text": "T39A",
                "shortText": "T39A"
              }, {
                "consensus": "M",
                "position": 41,
                "AAs": "L",
                "triplet": "TTG",
                "insertedNAs": "",
                "isInsertion": false,
                "isDeletion": false,
                "isIndel": false,
                "isAmbiguous": false,
                "isApobecMutation": false,
                "isApobecDRM": false,
                "hasStop": false,
                "isUnusual": false,
                "types": ["NRTI"],
                "primaryType": "NRTI",
                "comments": [{
                  "triggeredAAs": "L",
                  "type": "NRTI",
                  "text": "M41L is a TAM that usually occurs with T215Y. In combination, M41L plus T215Y confer intermediate / high-level resistance to AZT and d4T and contribute to reduced ddI, ABC and TDF susceptibility."
                }],
                "text": "M41L",
                "shortText": "M41L"
              }, {
                "consensus": "K",
                "position": 43,
                "AAs": "EQ",
                "triplet": "SAG",
                "insertedNAs": "",
                "isInsertion": false,
                "isDeletion": false,
                "isIndel": false,
                "isAmbiguous": false,
                "isApobecMutation": false,
                "isApobecDRM": false,
                "hasStop": false,
                "isUnusual": false,
                "types": ["Other"],
                "primaryType": "Other",
                "comments": [],
                "text": "K43EQ",
                "shortText": "K43EQ"
              }, {
                "consensus": "E",
                "position": 44,
                "AAs": "D",
                "triplet": "GAC",
                "insertedNAs": "",
                "isInsertion": false,
                "isDeletion": false,
                "isIndel": false,
                "isAmbiguous": false,
                "isApobecMutation": false,
                "isApobecDRM": false,
                "hasStop": false,
                "isUnusual": false,
                "types": ["NRTI"],
                "primaryType": "NRTI",
                "comments": [{
                  "triggeredAAs": "D",
                  "type": "NRTI",
                  "text": "E44D is a relatively non-polymorphic accessory mutation and E44A is a nonpolymorphic accessory mutation. Each usually occurs with multiple TAMs."
                }],
                "text": "E44D",
                "shortText": "E44D"
              }, {
                "consensus": "D",
                "position": 67,
                "AAs": "N",
                "triplet": "AAC",
                "insertedNAs": "",
                "isInsertion": false,
                "isDeletion": false,
                "isIndel": false,
                "isAmbiguous": false,
                "isApobecMutation": false,
                "isApobecDRM": true,
                "hasStop": false,
                "isUnusual": false,
                "types": ["NRTI"],
                "primaryType": "NRTI",
                "comments": [{
                  "triggeredAAs": "N",
                  "type": "NRTI",
                  "text": "D67N is a non-polymorphic TAM associated with low-level resistance to AZT and d4T. When present with other TAMs, it contributes reduced susceptibility to ABC, ddI, and TDF."
                }],
                "text": "D67N",
                "shortText": "D67N"
              }, {
                "consensus": "T",
                "position": 69,
                "AAs": "D",
                "triplet": "GAT",
                "insertedNAs": "",
                "isInsertion": false,
                "isDeletion": false,
                "isIndel": false,
                "isAmbiguous": false,
                "isApobecMutation": false,
                "isApobecDRM": false,
                "hasStop": false,
                "isUnusual": false,
                "types": ["NRTI"],
                "primaryType": "NRTI",
                "comments": [{
                  "triggeredAAs": "D",
                  "type": "NRTI",
                  "text": "T69D is a non-polymorphic mutation that reduces susceptibility to ddI and possibly d4T."
                }],
                "text": "T69D",
                "shortText": "T69D"
              }, {
                "consensus": "A",
                "position": 98,
                "AAs": "G",
                "triplet": "GGA",
                "insertedNAs": "",
                "isInsertion": false,
                "isDeletion": false,
                "isIndel": false,
                "isAmbiguous": false,
                "isApobecMutation": false,
                "isApobecDRM": false,
                "hasStop": false,
                "isUnusual": false,
                "types": ["NNRTI"],
                "primaryType": "NNRTI",
                "comments": [{
                  "triggeredAAs": "G",
                  "type": "NNRTI",
                  "text": "A98G is a non-polymorphic accessory mutation associated with low-level reduced susceptibility to each of the NNRTIs."
                }],
                "text": "A98G",
                "shortText": "A98G"
              }, {
                "consensus": "K",
                "position": 103,
                "AAs": "N",
                "triplet": "AAC",
                "insertedNAs": "",
                "isInsertion": false,
                "isDeletion": false,
                "isIndel": false,
                "isAmbiguous": false,
                "isApobecMutation": false,
                "isApobecDRM": false,
                "hasStop": false,
                "isUnusual": false,
                "types": ["NNRTI"],
                "primaryType": "NNRTI",
                "comments": [{
                  "triggeredAAs": "N",
                  "type": "NNRTI",
                  "text": "K103N is a non-polymorphic mutation that causes high-level resistance to NVP and EFV."
                }],
                "text": "K103N",
                "shortText": "K103N"
              }, {
                "consensus": "V",
                "position": 118,
                "AAs": "IV",
                "triplet": "RTT",
                "insertedNAs": "",
                "isInsertion": false,
                "isDeletion": false,
                "isIndel": false,
                "isAmbiguous": false,
                "isApobecMutation": false,
                "isApobecDRM": false,
                "hasStop": false,
                "isUnusual": false,
                "types": ["Other"],
                "primaryType": "Other",
                "comments": [{
                  "triggeredAAs": "I",
                  "type": "Other",
                  "text": "V118I is a polymorphic accessory NRTI-resistance mutation that often occurs in combination with multiple TAMs."
                }],
                "text": "V118VI",
                "shortText": "V118VI"
              }, {
                "consensus": "K",
                "position": 122,
                "AAs": "E",
                "triplet": "GAA",
                "insertedNAs": "",
                "isInsertion": false,
                "isDeletion": false,
                "isIndel": false,
                "isAmbiguous": false,
                "isApobecMutation": false,
                "isApobecDRM": false,
                "hasStop": false,
                "isUnusual": false,
                "types": ["Other"],
                "primaryType": "Other",
                "comments": [],
                "text": "K122E",
                "shortText": "K122E"
              }, {
                "consensus": "I",
                "position": 142,
                "AAs": "T",
                "triplet": "ACT",
                "insertedNAs": "",
                "isInsertion": false,
                "isDeletion": false,
                "isIndel": false,
                "isAmbiguous": false,
                "isApobecMutation": false,
                "isApobecDRM": false,
                "hasStop": false,
                "isUnusual": false,
                "types": ["Other"],
                "primaryType": "Other",
                "comments": [],
                "text": "I142T",
                "shortText": "I142T"
              }, {
                "consensus": "K",
                "position": 166,
                "AAs": "R",
                "triplet": "AGA",
                "insertedNAs": "",
                "isInsertion": false,
                "isDeletion": false,
                "isIndel": false,
                "isAmbiguous": false,
                "isApobecMutation": false,
                "isApobecDRM": false,
                "hasStop": false,
                "isUnusual": false,
                "types": ["Other"],
                "primaryType": "Other",
                "comments": [],
                "text": "K166R",
                "shortText": "K166R"
              }, {
                "consensus": "Y",
                "position": 181,
                "AAs": "C",
                "triplet": "TGT",
                "insertedNAs": "",
                "isInsertion": false,
                "isDeletion": false,
                "isIndel": false,
                "isAmbiguous": false,
                "isApobecMutation": false,
                "isApobecDRM": false,
                "hasStop": false,
                "isUnusual": false,
                "types": ["NNRTI"],
                "primaryType": "NNRTI",
                "comments": [{
                  "triggeredAAs": "C",
                  "type": "NNRTI",
                  "text": "Y181C is a non-polymorphic mutation selected in patients receiving each of the NNRTIs. It causes high-level reduction in NVP susceptibility, intermediate-level reduction in RPV and ETR susceptibility, and low-level reduction in EFV susceptibility. Y181C has a high weight in the Tibotec ETR genotypic susceptibility score."
                }],
                "text": "Y181C",
                "shortText": "Y181C"
              }, {
                "consensus": "M",
                "position": 184,
                "AAs": "V",
                "triplet": "GTG",
                "insertedNAs": "",
                "isInsertion": false,
                "isDeletion": false,
                "isIndel": false,
                "isAmbiguous": false,
                "isApobecMutation": false,
                "isApobecDRM": false,
                "hasStop": false,
                "isUnusual": false,
                "types": ["NRTI"],
                "primaryType": "NRTI",
                "comments": [{
                  "triggeredAAs": "V",
                  "type": "NRTI",
                  "text": "M184V/I cause high-level in vitro resistance to 3TC and FTC and low-level resistance to ddI and ABC. However, M184V/I are not contraindications to continued treatment with 3TC or FTC because they increase susceptibility to AZT, TDF and d4T and are associated with clinically significant reductions in HIV-1 replication."
                }],
                "text": "M184V",
                "shortText": "M184V"
              }, {
                "consensus": "G",
                "position": 196,
                "AAs": "E",
                "triplet": "GAG",
                "insertedNAs": "",
                "isInsertion": false,
                "isDeletion": false,
                "isIndel": false,
                "isAmbiguous": false,
                "isApobecMutation": false,
                "isApobecDRM": false,
                "hasStop": false,
                "isUnusual": false,
                "types": ["Other"],
                "primaryType": "Other",
                "comments": [],
                "text": "G196E",
                "shortText": "G196E"
              }, {
                "consensus": "Q",
                "position": 197,
                "AAs": "KQ",
                "triplet": "MAG",
                "insertedNAs": "",
                "isInsertion": false,
                "isDeletion": false,
                "isIndel": false,
                "isAmbiguous": false,
                "isApobecMutation": false,
                "isApobecDRM": false,
                "hasStop": false,
                "isUnusual": false,
                "types": ["Other"],
                "primaryType": "Other",
                "comments": [],
                "text": "Q197QK",
                "shortText": "Q197QK"
              }, {
                "consensus": "I",
                "position": 202,
                "AAs": "V",
                "triplet": "GTA",
                "insertedNAs": "",
                "isInsertion": false,
                "isDeletion": false,
                "isIndel": false,
                "isAmbiguous": false,
                "isApobecMutation": false,
                "isApobecDRM": false,
                "hasStop": false,
                "isUnusual": false,
                "types": ["Other"],
                "primaryType": "Other",
                "comments": [],
                "text": "I202V",
                "shortText": "I202V"
              }, {
                "consensus": "L",
                "position": 210,
                "AAs": "W",
                "triplet": "TGG",
                "insertedNAs": "",
                "isInsertion": false,
                "isDeletion": false,
                "isIndel": false,
                "isAmbiguous": false,
                "isApobecMutation": false,
                "isApobecDRM": false,
                "hasStop": false,
                "isUnusual": false,
                "types": ["NRTI"],
                "primaryType": "NRTI",
                "comments": [{
                  "triggeredAAs": "W",
                  "type": "NRTI",
                  "text": "L210W is a TAM that usually occurs in combination with M41L and T215Y. The combination of M41, L210W and T215Y causes high-level resistance to AZT and d4T and intermediate to high-level resistance to ddI, ABC and TDF."
                }],
                "text": "L210W",
                "shortText": "L210W"
              }, {
                "consensus": "R",
                "position": 211,
                "AAs": "K",
                "triplet": "AAG",
                "insertedNAs": "",
                "isInsertion": false,
                "isDeletion": false,
                "isIndel": false,
                "isAmbiguous": false,
                "isApobecMutation": false,
                "isApobecDRM": false,
                "hasStop": false,
                "isUnusual": false,
                "types": ["Other"],
                "primaryType": "Other",
                "comments": [],
                "text": "R211K",
                "shortText": "R211K"
              }, {
                "consensus": "T",
                "position": 215,
                "AAs": "Y",
                "triplet": "TAC",
                "insertedNAs": "",
                "isInsertion": false,
                "isDeletion": false,
                "isIndel": false,
                "isAmbiguous": false,
                "isApobecMutation": false,
                "isApobecDRM": false,
                "hasStop": false,
                "isUnusual": false,
                "types": ["NRTI"],
                "primaryType": "NRTI",
                "comments": [{
                  "triggeredAAs": "Y",
                  "type": "NRTI",
                  "text": "T215Y is a TAM that causes intermediate/high-level resistance to AZT and d4T, low-level resistance to ddI, and potentially low-level resistance to ABC and TDF."
                }],
                "text": "T215Y",
                "shortText": "T215Y"
              }, {
                "consensus": "K",
                "position": 219,
                "AAs": "KN",
                "triplet": "AAM",
                "insertedNAs": "",
                "isInsertion": false,
                "isDeletion": false,
                "isIndel": false,
                "isAmbiguous": false,
                "isApobecMutation": false,
                "isApobecDRM": false,
                "hasStop": false,
                "isUnusual": false,
                "types": ["NRTI"],
                "primaryType": "NRTI",
                "comments": [{
                  "triggeredAAs": "N",
                  "type": "NRTI",
                  "text": "K219N/R are accessory TAMS that usually occur in combination with multiple other TAMs."
                }],
                "text": "K219KN",
                "shortText": "K219KN"
              }],
              "APOBEC": [],
              "APOBEC_DRM": [{"text": "D67N"}],
              "DRM": [{"text": "M41L"}, {"text": "E44D"}, {"text": "D67N"}, {"text": "T69D"}, {"text": "A98G"}, {"text": "K103N"}, {"text": "Y181C"}, {"text": "M184V"}, {"text": "L210W"}, {"text": "T215Y"}, {"text": "K219KN"}],
              "SDRM": [{"text": "M41L"}, {"text": "D67N"}, {"text": "T69D"}, {"text": "K103N"}, {"text": "Y181C"}, {"text": "M184V"}, {"text": "L210W"}, {"text": "T215Y"}, {"text": "K219N"}],
              "unusualMutations": [],
              "treatmentSelectedMutations": [],
              "frameShifts": []
            }],
            "firstTenCloseSubtypes": [{
              "displayWithoutDistance": "B",
              "distancePcnt": "2.75%",
              "referenceAccession": "D86069"
            }, {
              "displayWithoutDistance": "B",
              "distancePcnt": "2.85%",
              "referenceAccession": "AF256204"
            }, {
              "displayWithoutDistance": "B",
              "distancePcnt": "2.95%",
              "referenceAccession": "K03455"
            }, {
              "displayWithoutDistance": "B",
              "distancePcnt": "3.15%",
              "referenceAccession": "AF042100"
            }, {
              "displayWithoutDistance": "B",
              "distancePcnt": "3.34%",
              "referenceAccession": "EU839600"
            }, {
              "displayWithoutDistance": "B",
              "distancePcnt": "3.44%",
              "referenceAccession": "U43096"
            }, {
              "displayWithoutDistance": "B",
              "distancePcnt": "3.44%",
              "referenceAccession": "DQ358805"
            }, {
              "displayWithoutDistance": "B",
              "distancePcnt": "3.54%",
              "referenceAccession": "U63632"
            }, {
              "displayWithoutDistance": "B",
              "distancePcnt": "3.54%",
              "referenceAccession": "AF156820"
            }, {"displayWithoutDistance": "B", "distancePcnt": "3.54%", "referenceAccession": "EF694037"}],
            "bestMatchingSubtype": {"display": "B (2.75%)"},
            "mixturePcnt": 0.983284169124877,
            "mutations": [{"position": 10, "AAs": "I", "shortText": "L10I"}, {
              "position": 20,
              "AAs": "KR",
              "shortText": "K20KR"
            }, {"position": 35, "AAs": "D", "shortText": "E35D"}, {
              "position": 36,
              "AAs": "I",
              "shortText": "M36I"
            }, {"position": 43, "AAs": "T", "shortText": "K43T"}, {
              "position": 46,
              "AAs": "IM",
              "shortText": "M46MI"
            }, {"position": 48, "AAs": "V", "shortText": "G48V"}, {
              "position": 54,
              "AAs": "T",
              "shortText": "I54T"
            }, {"position": 63, "AAs": "P", "shortText": "L63P"}, {
              "position": 64,
              "AAs": "V",
              "shortText": "I64V"
            }, {"position": 82, "AAs": "A", "shortText": "V82A"}, {
              "position": 6,
              "AAs": "D",
              "shortText": "E6D"
            }, {"position": 39, "AAs": "A", "shortText": "T39A"}, {
              "position": 41,
              "AAs": "L",
              "shortText": "M41L"
            }, {"position": 43, "AAs": "EQ", "shortText": "K43EQ"}, {
              "position": 44,
              "AAs": "D",
              "shortText": "E44D"
            }, {"position": 67, "AAs": "N", "shortText": "D67N"}, {
              "position": 69,
              "AAs": "D",
              "shortText": "T69D"
            }, {"position": 98, "AAs": "G", "shortText": "A98G"}, {
              "position": 103,
              "AAs": "N",
              "shortText": "K103N"
            }, {"position": 118, "AAs": "IV", "shortText": "V118VI"}, {
              "position": 122,
              "AAs": "E",
              "shortText": "K122E"
            }, {"position": 142, "AAs": "T", "shortText": "I142T"}, {
              "position": 166,
              "AAs": "R",
              "shortText": "K166R"
            }, {"position": 181, "AAs": "C", "shortText": "Y181C"}, {
              "position": 184,
              "AAs": "V",
              "shortText": "M184V"
            }, {"position": 196, "AAs": "E", "shortText": "G196E"}, {
              "position": 197,
              "AAs": "KQ",
              "shortText": "Q197QK"
            }, {"position": 202, "AAs": "V", "shortText": "I202V"}, {
              "position": 210,
              "AAs": "W",
              "shortText": "L210W"
            }, {"position": 211, "AAs": "K", "shortText": "R211K"}, {
              "position": 215,
              "AAs": "Y",
              "shortText": "T215Y"
            }, {"position": 219, "AAs": "KN", "shortText": "K219KN"}],
            "frameShifts": [],
            "drugResistance": [{
              "gene": {
                "name": "PR",
                "consensus": "PQITLWQRPLVTIKIGGQLKEALLDTGADDTVLEEMNLPGRWKPKMIGGIGGFIKVRQYDQILIEICGHKAIGTVLVGPTPVNIIGRNLLTQIGCTLNF",
                "length": 99,
                "drugClasses": [{"name": "PI"}],
                "mutationTypes": ["Major", "Accessory", "Other"]
              },
              "drugScores": [{
                "drugClass": {
                  "name": "PI",
                  "fullName": "Protease Inhibitor",
                  "drugs": [{"name": "ATV", "displayAbbr": "ATV/r", "fullName": "atazanavir/r"}, {
                    "name": "DRV",
                    "displayAbbr": "DRV/r",
                    "fullName": "darunavir/r"
                  }, {"name": "FPV", "displayAbbr": "FPV/r", "fullName": "fosamprenavir/r"}, {
                    "name": "IDV",
                    "displayAbbr": "IDV/r",
                    "fullName": "indinavir/r"
                  }, {"name": "LPV", "displayAbbr": "LPV/r", "fullName": "lopinavir/r"}, {
                    "name": "NFV",
                    "displayAbbr": "NFV",
                    "fullName": "nelfinavir"
                  }, {"name": "SQV", "displayAbbr": "SQV/r", "fullName": "saquinavir/r"}, {
                    "name": "TPV",
                    "displayAbbr": "TPV/r",
                    "fullName": "tipranavir/r"
                  }]
                },
                "drug": {"displayAbbr": "ATV/r"},
                "SIR": "R",
                "score": 90,
                "level": 5,
                "text": "High-Level Resistance",
                "partialScores": [{"mutations": [{"text": "M46I"}], "score": 10}, {
                  "mutations": [{"text": "G48V"}],
                  "score": 30
                }, {"mutations": [{"text": "I54T"}], "score": 15}, {
                  "mutations": [{"text": "V82A"}],
                  "score": 15
                }, {
                  "mutations": [{"text": "M46I"}, {"text": "V82A"}],
                  "score": 10
                }, {"mutations": [{"text": "I54T"}, {"text": "V82A"}], "score": 10}]
              }, {
                "drugClass": {
                  "name": "PI",
                  "fullName": "Protease Inhibitor",
                  "drugs": [{"name": "ATV", "displayAbbr": "ATV/r", "fullName": "atazanavir/r"}, {
                    "name": "DRV",
                    "displayAbbr": "DRV/r",
                    "fullName": "darunavir/r"
                  }, {"name": "FPV", "displayAbbr": "FPV/r", "fullName": "fosamprenavir/r"}, {
                    "name": "IDV",
                    "displayAbbr": "IDV/r",
                    "fullName": "indinavir/r"
                  }, {"name": "LPV", "displayAbbr": "LPV/r", "fullName": "lopinavir/r"}, {
                    "name": "NFV",
                    "displayAbbr": "NFV",
                    "fullName": "nelfinavir"
                  }, {"name": "SQV", "displayAbbr": "SQV/r", "fullName": "saquinavir/r"}, {
                    "name": "TPV",
                    "displayAbbr": "TPV/r",
                    "fullName": "tipranavir/r"
                  }]
                },
                "drug": {"displayAbbr": "DRV/r"},
                "SIR": "S",
                "score": 0,
                "level": 1,
                "text": "Susceptible",
                "partialScores": []
              }, {
                "drugClass": {
                  "name": "PI",
                  "fullName": "Protease Inhibitor",
                  "drugs": [{"name": "ATV", "displayAbbr": "ATV/r", "fullName": "atazanavir/r"}, {
                    "name": "DRV",
                    "displayAbbr": "DRV/r",
                    "fullName": "darunavir/r"
                  }, {"name": "FPV", "displayAbbr": "FPV/r", "fullName": "fosamprenavir/r"}, {
                    "name": "IDV",
                    "displayAbbr": "IDV/r",
                    "fullName": "indinavir/r"
                  }, {"name": "LPV", "displayAbbr": "LPV/r", "fullName": "lopinavir/r"}, {
                    "name": "NFV",
                    "displayAbbr": "NFV",
                    "fullName": "nelfinavir"
                  }, {"name": "SQV", "displayAbbr": "SQV/r", "fullName": "saquinavir/r"}, {
                    "name": "TPV",
                    "displayAbbr": "TPV/r",
                    "fullName": "tipranavir/r"
                  }]
                },
                "drug": {"displayAbbr": "FPV/r"},
                "SIR": "I",
                "score": 55,
                "level": 4,
                "text": "Intermediate Resistance",
                "partialScores": [{"mutations": [{"text": "M46I"}], "score": 10}, {
                  "mutations": [{"text": "I54T"}],
                  "score": 10
                }, {"mutations": [{"text": "V82A"}], "score": 15}, {
                  "mutations": [{"text": "M46I"}, {"text": "V82A"}],
                  "score": 10
                }, {"mutations": [{"text": "I54T"}, {"text": "V82A"}], "score": 10}]
              }, {
                "drugClass": {
                  "name": "PI",
                  "fullName": "Protease Inhibitor",
                  "drugs": [{"name": "ATV", "displayAbbr": "ATV/r", "fullName": "atazanavir/r"}, {
                    "name": "DRV",
                    "displayAbbr": "DRV/r",
                    "fullName": "darunavir/r"
                  }, {"name": "FPV", "displayAbbr": "FPV/r", "fullName": "fosamprenavir/r"}, {
                    "name": "IDV",
                    "displayAbbr": "IDV/r",
                    "fullName": "indinavir/r"
                  }, {"name": "LPV", "displayAbbr": "LPV/r", "fullName": "lopinavir/r"}, {
                    "name": "NFV",
                    "displayAbbr": "NFV",
                    "fullName": "nelfinavir"
                  }, {"name": "SQV", "displayAbbr": "SQV/r", "fullName": "saquinavir/r"}, {
                    "name": "TPV",
                    "displayAbbr": "TPV/r",
                    "fullName": "tipranavir/r"
                  }]
                },
                "drug": {"displayAbbr": "IDV/r"},
                "SIR": "R",
                "score": 85,
                "level": 5,
                "text": "High-Level Resistance",
                "partialScores": [{"mutations": [{"text": "M46I"}], "score": 10}, {
                  "mutations": [{"text": "G48V"}],
                  "score": 10
                }, {"mutations": [{"text": "I54T"}], "score": 15}, {
                  "mutations": [{"text": "V82A"}],
                  "score": 30
                }, {
                  "mutations": [{"text": "M46I"}, {"text": "V82A"}],
                  "score": 10
                }, {"mutations": [{"text": "I54T"}, {"text": "V82A"}], "score": 10}]
              }, {
                "drugClass": {
                  "name": "PI",
                  "fullName": "Protease Inhibitor",
                  "drugs": [{"name": "ATV", "displayAbbr": "ATV/r", "fullName": "atazanavir/r"}, {
                    "name": "DRV",
                    "displayAbbr": "DRV/r",
                    "fullName": "darunavir/r"
                  }, {"name": "FPV", "displayAbbr": "FPV/r", "fullName": "fosamprenavir/r"}, {
                    "name": "IDV",
                    "displayAbbr": "IDV/r",
                    "fullName": "indinavir/r"
                  }, {"name": "LPV", "displayAbbr": "LPV/r", "fullName": "lopinavir/r"}, {
                    "name": "NFV",
                    "displayAbbr": "NFV",
                    "fullName": "nelfinavir"
                  }, {"name": "SQV", "displayAbbr": "SQV/r", "fullName": "saquinavir/r"}, {
                    "name": "TPV",
                    "displayAbbr": "TPV/r",
                    "fullName": "tipranavir/r"
                  }]
                },
                "drug": {"displayAbbr": "LPV/r"},
                "SIR": "R",
                "score": 85,
                "level": 5,
                "text": "High-Level Resistance",
                "partialScores": [{"mutations": [{"text": "M46I"}], "score": 10}, {
                  "mutations": [{"text": "G48V"}],
                  "score": 10
                }, {"mutations": [{"text": "I54T"}], "score": 15}, {
                  "mutations": [{"text": "V82A"}],
                  "score": 30
                }, {
                  "mutations": [{"text": "M46I"}, {"text": "V82A"}],
                  "score": 10
                }, {"mutations": [{"text": "I54T"}, {"text": "V82A"}], "score": 10}]
              }, {
                "drugClass": {
                  "name": "PI",
                  "fullName": "Protease Inhibitor",
                  "drugs": [{"name": "ATV", "displayAbbr": "ATV/r", "fullName": "atazanavir/r"}, {
                    "name": "DRV",
                    "displayAbbr": "DRV/r",
                    "fullName": "darunavir/r"
                  }, {"name": "FPV", "displayAbbr": "FPV/r", "fullName": "fosamprenavir/r"}, {
                    "name": "IDV",
                    "displayAbbr": "IDV/r",
                    "fullName": "indinavir/r"
                  }, {"name": "LPV", "displayAbbr": "LPV/r", "fullName": "lopinavir/r"}, {
                    "name": "NFV",
                    "displayAbbr": "NFV",
                    "fullName": "nelfinavir"
                  }, {"name": "SQV", "displayAbbr": "SQV/r", "fullName": "saquinavir/r"}, {
                    "name": "TPV",
                    "displayAbbr": "TPV/r",
                    "fullName": "tipranavir/r"
                  }]
                },
                "drug": {"displayAbbr": "NFV"},
                "SIR": "R",
                "score": 140,
                "level": 5,
                "text": "High-Level Resistance",
                "partialScores": [{"mutations": [{"text": "K43T"}], "score": 10}, {
                  "mutations": [{"text": "M46I"}],
                  "score": 30
                }, {"mutations": [{"text": "G48V"}], "score": 30}, {
                  "mutations": [{"text": "I54T"}],
                  "score": 20
                }, {"mutations": [{"text": "V82A"}], "score": 30}, {
                  "mutations": [{"text": "M46I"}, {"text": "V82A"}],
                  "score": 10
                }, {"mutations": [{"text": "I54T"}, {"text": "V82A"}], "score": 10}]
              }, {
                "drugClass": {
                  "name": "PI",
                  "fullName": "Protease Inhibitor",
                  "drugs": [{"name": "ATV", "displayAbbr": "ATV/r", "fullName": "atazanavir/r"}, {
                    "name": "DRV",
                    "displayAbbr": "DRV/r",
                    "fullName": "darunavir/r"
                  }, {"name": "FPV", "displayAbbr": "FPV/r", "fullName": "fosamprenavir/r"}, {
                    "name": "IDV",
                    "displayAbbr": "IDV/r",
                    "fullName": "indinavir/r"
                  }, {"name": "LPV", "displayAbbr": "LPV/r", "fullName": "lopinavir/r"}, {
                    "name": "NFV",
                    "displayAbbr": "NFV",
                    "fullName": "nelfinavir"
                  }, {"name": "SQV", "displayAbbr": "SQV/r", "fullName": "saquinavir/r"}, {
                    "name": "TPV",
                    "displayAbbr": "TPV/r",
                    "fullName": "tipranavir/r"
                  }]
                },
                "drug": {"displayAbbr": "SQV/r"},
                "SIR": "R",
                "score": 120,
                "level": 5,
                "text": "High-Level Resistance",
                "partialScores": [{"mutations": [{"text": "M46I"}], "score": 10}, {
                  "mutations": [{"text": "G48V"}],
                  "score": 60
                }, {"mutations": [{"text": "I54T"}], "score": 15}, {
                  "mutations": [{"text": "V82A"}],
                  "score": 15
                }, {
                  "mutations": [{"text": "M46I"}, {"text": "V82A"}],
                  "score": 10
                }, {"mutations": [{"text": "I54T"}, {"text": "V82A"}], "score": 10}]
              }, {
                "drugClass": {
                  "name": "PI",
                  "fullName": "Protease Inhibitor",
                  "drugs": [{"name": "ATV", "displayAbbr": "ATV/r", "fullName": "atazanavir/r"}, {
                    "name": "DRV",
                    "displayAbbr": "DRV/r",
                    "fullName": "darunavir/r"
                  }, {"name": "FPV", "displayAbbr": "FPV/r", "fullName": "fosamprenavir/r"}, {
                    "name": "IDV",
                    "displayAbbr": "IDV/r",
                    "fullName": "indinavir/r"
                  }, {"name": "LPV", "displayAbbr": "LPV/r", "fullName": "lopinavir/r"}, {
                    "name": "NFV",
                    "displayAbbr": "NFV",
                    "fullName": "nelfinavir"
                  }, {"name": "SQV", "displayAbbr": "SQV/r", "fullName": "saquinavir/r"}, {
                    "name": "TPV",
                    "displayAbbr": "TPV/r",
                    "fullName": "tipranavir/r"
                  }]
                },
                "drug": {"displayAbbr": "TPV/r"},
                "SIR": "I",
                "score": 35,
                "level": 4,
                "text": "Intermediate Resistance",
                "partialScores": [{"mutations": [{"text": "K43T"}], "score": 10}, {
                  "mutations": [{"text": "M46I"}],
                  "score": 5
                }, {"mutations": [{"text": "I54T"}], "score": 20}]
              }],
              "mutationsByTypes": [{
                "mutationType": "Major",
                "mutations": [{
                  "consensus": "M",
                  "position": 46,
                  "AAs": "IM",
                  "triplet": "ATK",
                  "insertedNAs": "",
                  "isInsertion": false,
                  "isDeletion": false,
                  "isIndel": false,
                  "isAmbiguous": false,
                  "isApobecMutation": false,
                  "isApobecDRM": true,
                  "hasStop": false,
                  "isUnusual": false,
                  "text": "M46MI",
                  "shortText": "M46MI"
                }, {
                  "consensus": "G",
                  "position": 48,
                  "AAs": "V",
                  "triplet": "GTG",
                  "insertedNAs": "",
                  "isInsertion": false,
                  "isDeletion": false,
                  "isIndel": false,
                  "isAmbiguous": false,
                  "isApobecMutation": false,
                  "isApobecDRM": false,
                  "hasStop": false,
                  "isUnusual": false,
                  "text": "G48V",
                  "shortText": "G48V"
                }, {
                  "consensus": "I",
                  "position": 54,
                  "AAs": "T",
                  "triplet": "ACC",
                  "insertedNAs": "",
                  "isInsertion": false,
                  "isDeletion": false,
                  "isIndel": false,
                  "isAmbiguous": false,
                  "isApobecMutation": false,
                  "isApobecDRM": false,
                  "hasStop": false,
                  "isUnusual": false,
                  "text": "I54T",
                  "shortText": "I54T"
                }, {
                  "consensus": "V",
                  "position": 82,
                  "AAs": "A",
                  "triplet": "GCC",
                  "insertedNAs": "",
                  "isInsertion": false,
                  "isDeletion": false,
                  "isIndel": false,
                  "isAmbiguous": false,
                  "isApobecMutation": false,
                  "isApobecDRM": false,
                  "hasStop": false,
                  "isUnusual": false,
                  "text": "V82A",
                  "shortText": "V82A"
                }]
              }, {
                "mutationType": "Accessory",
                "mutations": [{
                  "consensus": "K",
                  "position": 43,
                  "AAs": "T",
                  "triplet": "ACA",
                  "insertedNAs": "",
                  "isInsertion": false,
                  "isDeletion": false,
                  "isIndel": false,
                  "isAmbiguous": false,
                  "isApobecMutation": false,
                  "isApobecDRM": false,
                  "hasStop": false,
                  "isUnusual": false,
                  "text": "K43T",
                  "shortText": "K43T"
                }]
              }, {
                "mutationType": "Other",
                "mutations": [{
                  "consensus": "L",
                  "position": 10,
                  "AAs": "I",
                  "triplet": "ATC",
                  "insertedNAs": "",
                  "isInsertion": false,
                  "isDeletion": false,
                  "isIndel": false,
                  "isAmbiguous": false,
                  "isApobecMutation": false,
                  "isApobecDRM": false,
                  "hasStop": false,
                  "isUnusual": false,
                  "text": "L10I",
                  "shortText": "L10I"
                }, {
                  "consensus": "K",
                  "position": 20,
                  "AAs": "KR",
                  "triplet": "ARG",
                  "insertedNAs": "",
                  "isInsertion": false,
                  "isDeletion": false,
                  "isIndel": false,
                  "isAmbiguous": false,
                  "isApobecMutation": false,
                  "isApobecDRM": false,
                  "hasStop": false,
                  "isUnusual": false,
                  "text": "K20KR",
                  "shortText": "K20KR"
                }, {
                  "consensus": "E",
                  "position": 35,
                  "AAs": "D",
                  "triplet": "GAT",
                  "insertedNAs": "",
                  "isInsertion": false,
                  "isDeletion": false,
                  "isIndel": false,
                  "isAmbiguous": false,
                  "isApobecMutation": false,
                  "isApobecDRM": false,
                  "hasStop": false,
                  "isUnusual": false,
                  "text": "E35D",
                  "shortText": "E35D"
                }, {
                  "consensus": "M",
                  "position": 36,
                  "AAs": "I",
                  "triplet": "ATA",
                  "insertedNAs": "",
                  "isInsertion": false,
                  "isDeletion": false,
                  "isIndel": false,
                  "isAmbiguous": false,
                  "isApobecMutation": false,
                  "isApobecDRM": false,
                  "hasStop": false,
                  "isUnusual": false,
                  "text": "M36I",
                  "shortText": "M36I"
                }, {
                  "consensus": "L",
                  "position": 63,
                  "AAs": "P",
                  "triplet": "CCT",
                  "insertedNAs": "",
                  "isInsertion": false,
                  "isDeletion": false,
                  "isIndel": false,
                  "isAmbiguous": false,
                  "isApobecMutation": false,
                  "isApobecDRM": false,
                  "hasStop": false,
                  "isUnusual": false,
                  "text": "L63P",
                  "shortText": "L63P"
                }, {
                  "consensus": "I",
                  "position": 64,
                  "AAs": "V",
                  "triplet": "GTA",
                  "insertedNAs": "",
                  "isInsertion": false,
                  "isDeletion": false,
                  "isIndel": false,
                  "isAmbiguous": false,
                  "isApobecMutation": false,
                  "isApobecDRM": false,
                  "hasStop": false,
                  "isUnusual": false,
                  "text": "I64V",
                  "shortText": "I64V"
                }]
              }],
              "commentsByTypes": [{
                "commentType": "Major",
                "comments": [{
                  "type": "Major",
                  "text": "M46I/L are relatively non-polymorphic PI-selected mutations. In combination with other PI-resistance mutations, they are associated with reduced susceptibility to each of the PIs except DRV.",
                  "highlightText": ["M46I"]
                }, {
                  "type": "Major",
                  "text": "G48V is a non-polymorphic mutation selected by SQV and, less often, by IDV and LPV. It confers high-level resistance to SQV, intermediate resistance to ATV, and low-level resistance to NFV, IDV and LPV.",
                  "highlightText": ["G48V"]
                }, {
                  "type": "Major",
                  "text": "I54A/T/S are non-polymorphic PI-selected mutations that occur almost exclusively in viruses with multiple PI-resistance mutations. I54A/T/S are associated with reduced susceptibility to each of the PIs except DRV.",
                  "highlightText": ["I54T"]
                }, {
                  "type": "Major",
                  "text": "V82A is a non-polymorphic mutation selected primarily by IDV and LPV. It reduces susceptibility to these PIs and contributes cross-resistance to each of the remaining PIs except DRV and TPV.",
                  "highlightText": ["V82A"]
                }]
              }, {
                "commentType": "Accessory",
                "comments": [{
                  "type": "Accessory",
                  "text": "K43T is a non-polymorphic PI-selected accessory mutation. K43T is included in the Boehringer-Ingelheim TPV genotypic susceptibility score.",
                  "highlightText": ["K43T"]
                }]
              }, {
                "commentType": "Other",
                "comments": [{
                  "type": "Other",
                  "text": "L10I/V are polymorphic, PI-selected accessory mutations that increase the replication of viruses with other PI-resistance mutations.",
                  "highlightText": ["L10I"]
                }, {
                  "type": "Other",
                  "text": "K20R is a highly polymorphic PI-selected accessory mutation.",
                  "highlightText": ["K20R"]
                }]
              }]
            }, {
              "gene": {
                "name": "RT",
                "consensus": "PISPIETVPVKLKPGMDGPKVKQWPLTEEKIKALVEICTEMEKEGKISKIGPENPYNTPVFAIKKKDSTKWRKLVDFRELNKRTQDFWEVQLGIPHPAGLKKKKSVTVLDVGDAYFSVPLDKDFRKYTAFTIPSINNETPGIRYQYNVLPQGWKGSPAIFQSSMTKILEPFRKQNPDIVIYQYMDDLYVGSDLEIGQHRTKIEELRQHLLRWGFTTPDKKHQKEPPFLWMGYELHPDKWTVQPIVLPEKDSWTVNDIQKLVGKLNWASQIYAGIKVKQLCKLLRGTKALTEVIPLTEEAELELAENREILKEPVHGVYYDPSKDLIAEIQKQGQGQWTYQIYQEPFKNLKTGKYARMRGAHTNDVKQLTEAVQKIATESIVIWGKTPKFKLPIQKETWEAWWTEYWQATWIPEWEFVNTPPLVKLWYQLEKEPIVGAETFYVDGAANRETKLGKAGYVTDRGRQKVVSLTDTTNQKTELQAIHLALQDSGLEVNIVTDSQYALGIIQAQPDKSESELVSQIIEQLIKKEKVYLAWVPAHKGIGGNEQVDKLVSAGIRKVL",
                "length": 560,
                "drugClasses": [{"name": "NRTI"}, {"name": "NNRTI"}],
                "mutationTypes": ["NRTI", "NNRTI", "Other"]
              },
              "drugScores": [{
                "drugClass": {
                  "name": "NRTI",
                  "fullName": "Nucleoside Reverse Transcriptase Inhibitor",
                  "drugs": [{"name": "ABC", "displayAbbr": "ABC", "fullName": "abacavir"}, {
                    "name": "AZT",
                    "displayAbbr": "AZT",
                    "fullName": "zidovudine"
                  }, {"name": "D4T", "displayAbbr": "D4T", "fullName": "stavudine"}, {
                    "name": "DDI",
                    "displayAbbr": "DDI",
                    "fullName": "didanosine"
                  }, {"name": "FTC", "displayAbbr": "FTC", "fullName": "emtricitabine"}, {
                    "name": "LMV",
                    "displayAbbr": "3TC",
                    "fullName": "lamivudine"
                  }, {"name": "TDF", "displayAbbr": "TDF", "fullName": "tenofovir"}]
                },
                "drug": {"displayAbbr": "ABC"},
                "SIR": "R",
                "score": 100,
                "level": 5,
                "text": "High-Level Resistance",
                "partialScores": [{"mutations": [{"text": "M41L"}], "score": 5}, {
                  "mutations": [{"text": "D67N"}],
                  "score": 5
                }, {"mutations": [{"text": "M184V"}], "score": 15}, {
                  "mutations": [{"text": "L210W"}],
                  "score": 5
                }, {"mutations": [{"text": "T215Y"}], "score": 10}, {
                  "mutations": [{"text": "K219N"}],
                  "score": 5
                }, {
                  "mutations": [{"text": "M41L"}, {"text": "E44D"}, {"text": "L210W"}, {"text": "T215Y"}],
                  "score": 5
                }, {
                  "mutations": [{"text": "M41L"}, {"text": "D67N"}, {"text": "T215Y"}],
                  "score": 5
                }, {
                  "mutations": [{"text": "M41L"}, {"text": "L210W"}],
                  "score": 10
                }, {
                  "mutations": [{"text": "M41L"}, {"text": "L210W"}, {"text": "T215Y"}],
                  "score": 5
                }, {
                  "mutations": [{"text": "M41L"}, {"text": "T215Y"}],
                  "score": 15
                }, {
                  "mutations": [{"text": "D67N"}, {"text": "T215Y"}, {"text": "K219N"}],
                  "score": 5
                }, {"mutations": [{"text": "L210W"}, {"text": "T215Y"}], "score": 10}]
              }, {
                "drugClass": {
                  "name": "NRTI",
                  "fullName": "Nucleoside Reverse Transcriptase Inhibitor",
                  "drugs": [{"name": "ABC", "displayAbbr": "ABC", "fullName": "abacavir"}, {
                    "name": "AZT",
                    "displayAbbr": "AZT",
                    "fullName": "zidovudine"
                  }, {"name": "D4T", "displayAbbr": "D4T", "fullName": "stavudine"}, {
                    "name": "DDI",
                    "displayAbbr": "DDI",
                    "fullName": "didanosine"
                  }, {"name": "FTC", "displayAbbr": "FTC", "fullName": "emtricitabine"}, {
                    "name": "LMV",
                    "displayAbbr": "3TC",
                    "fullName": "lamivudine"
                  }, {"name": "TDF", "displayAbbr": "TDF", "fullName": "tenofovir"}]
                },
                "drug": {"displayAbbr": "AZT"},
                "SIR": "R",
                "score": 130,
                "level": 5,
                "text": "High-Level Resistance",
                "partialScores": [{"mutations": [{"text": "M41L"}], "score": 15}, {
                  "mutations": [{"text": "D67N"}],
                  "score": 15
                }, {"mutations": [{"text": "M184V"}], "score": -10}, {
                  "mutations": [{"text": "L210W"}],
                  "score": 15
                }, {"mutations": [{"text": "T215Y"}], "score": 40}, {
                  "mutations": [{"text": "K219N"}],
                  "score": 10
                }, {
                  "mutations": [{"text": "M41L"}, {"text": "E44D"}, {"text": "L210W"}, {"text": "T215Y"}],
                  "score": 5
                }, {
                  "mutations": [{"text": "M41L"}, {"text": "D67N"}, {"text": "T215Y"}],
                  "score": 5
                }, {
                  "mutations": [{"text": "M41L"}, {"text": "L210W"}],
                  "score": 10
                }, {
                  "mutations": [{"text": "M41L"}, {"text": "T215Y"}],
                  "score": 10
                }, {
                  "mutations": [{"text": "D67N"}, {"text": "T215Y"}, {"text": "K219N"}],
                  "score": 5
                }, {"mutations": [{"text": "L210W"}, {"text": "T215Y"}], "score": 10}]
              }, {
                "drugClass": {
                  "name": "NRTI",
                  "fullName": "Nucleoside Reverse Transcriptase Inhibitor",
                  "drugs": [{"name": "ABC", "displayAbbr": "ABC", "fullName": "abacavir"}, {
                    "name": "AZT",
                    "displayAbbr": "AZT",
                    "fullName": "zidovudine"
                  }, {"name": "D4T", "displayAbbr": "D4T", "fullName": "stavudine"}, {
                    "name": "DDI",
                    "displayAbbr": "DDI",
                    "fullName": "didanosine"
                  }, {"name": "FTC", "displayAbbr": "FTC", "fullName": "emtricitabine"}, {
                    "name": "LMV",
                    "displayAbbr": "3TC",
                    "fullName": "lamivudine"
                  }, {"name": "TDF", "displayAbbr": "TDF", "fullName": "tenofovir"}]
                },
                "drug": {"displayAbbr": "D4T"},
                "SIR": "R",
                "score": 140,
                "level": 5,
                "text": "High-Level Resistance",
                "partialScores": [{"mutations": [{"text": "M41L"}], "score": 15}, {
                  "mutations": [{"text": "D67N"}],
                  "score": 15
                }, {"mutations": [{"text": "T69D"}], "score": 10}, {
                  "mutations": [{"text": "M184V"}],
                  "score": -10
                }, {"mutations": [{"text": "L210W"}], "score": 15}, {
                  "mutations": [{"text": "T215Y"}],
                  "score": 40
                }, {
                  "mutations": [{"text": "K219N"}],
                  "score": 10
                }, {
                  "mutations": [{"text": "M41L"}, {"text": "E44D"}, {"text": "L210W"}, {"text": "T215Y"}],
                  "score": 5
                }, {
                  "mutations": [{"text": "M41L"}, {"text": "D67N"}, {"text": "T215Y"}],
                  "score": 5
                }, {
                  "mutations": [{"text": "M41L"}, {"text": "L210W"}],
                  "score": 10
                }, {
                  "mutations": [{"text": "M41L"}, {"text": "T215Y"}],
                  "score": 10
                }, {
                  "mutations": [{"text": "D67N"}, {"text": "T215Y"}, {"text": "K219N"}],
                  "score": 5
                }, {"mutations": [{"text": "L210W"}, {"text": "T215Y"}], "score": 10}]
              }, {
                "drugClass": {
                  "name": "NRTI",
                  "fullName": "Nucleoside Reverse Transcriptase Inhibitor",
                  "drugs": [{"name": "ABC", "displayAbbr": "ABC", "fullName": "abacavir"}, {
                    "name": "AZT",
                    "displayAbbr": "AZT",
                    "fullName": "zidovudine"
                  }, {"name": "D4T", "displayAbbr": "D4T", "fullName": "stavudine"}, {
                    "name": "DDI",
                    "displayAbbr": "DDI",
                    "fullName": "didanosine"
                  }, {"name": "FTC", "displayAbbr": "FTC", "fullName": "emtricitabine"}, {
                    "name": "LMV",
                    "displayAbbr": "3TC",
                    "fullName": "lamivudine"
                  }, {"name": "TDF", "displayAbbr": "TDF", "fullName": "tenofovir"}]
                },
                "drug": {"displayAbbr": "DDI"},
                "SIR": "R",
                "score": 130,
                "level": 5,
                "text": "High-Level Resistance",
                "partialScores": [{"mutations": [{"text": "M41L"}], "score": 10}, {
                  "mutations": [{"text": "D67N"}],
                  "score": 5
                }, {"mutations": [{"text": "T69D"}], "score": 30}, {
                  "mutations": [{"text": "M184V"}],
                  "score": 10
                }, {"mutations": [{"text": "L210W"}], "score": 10}, {
                  "mutations": [{"text": "T215Y"}],
                  "score": 15
                }, {
                  "mutations": [{"text": "K219N"}],
                  "score": 5
                }, {
                  "mutations": [{"text": "M41L"}, {"text": "E44D"}, {"text": "L210W"}, {"text": "T215Y"}],
                  "score": 5
                }, {
                  "mutations": [{"text": "M41L"}, {"text": "D67N"}, {"text": "T215Y"}],
                  "score": 5
                }, {
                  "mutations": [{"text": "M41L"}, {"text": "L210W"}],
                  "score": 10
                }, {
                  "mutations": [{"text": "M41L"}, {"text": "T215Y"}],
                  "score": 10
                }, {
                  "mutations": [{"text": "D67N"}, {"text": "T215Y"}, {"text": "K219N"}],
                  "score": 5
                }, {"mutations": [{"text": "L210W"}, {"text": "T215Y"}], "score": 10}]
              }, {
                "drugClass": {
                  "name": "NRTI",
                  "fullName": "Nucleoside Reverse Transcriptase Inhibitor",
                  "drugs": [{"name": "ABC", "displayAbbr": "ABC", "fullName": "abacavir"}, {
                    "name": "AZT",
                    "displayAbbr": "AZT",
                    "fullName": "zidovudine"
                  }, {"name": "D4T", "displayAbbr": "D4T", "fullName": "stavudine"}, {
                    "name": "DDI",
                    "displayAbbr": "DDI",
                    "fullName": "didanosine"
                  }, {"name": "FTC", "displayAbbr": "FTC", "fullName": "emtricitabine"}, {
                    "name": "LMV",
                    "displayAbbr": "3TC",
                    "fullName": "lamivudine"
                  }, {"name": "TDF", "displayAbbr": "TDF", "fullName": "tenofovir"}]
                },
                "drug": {"displayAbbr": "FTC"},
                "SIR": "R",
                "score": 80,
                "level": 5,
                "text": "High-Level Resistance",
                "partialScores": [{
                  "mutations": [{"text": "M184V"}],
                  "score": 60
                }, {
                  "mutations": [{"text": "M41L"}, {"text": "D67N"}, {"text": "T215Y"}],
                  "score": 5
                }, {
                  "mutations": [{"text": "M41L"}, {"text": "L210W"}, {"text": "T215Y"}],
                  "score": 5
                }, {
                  "mutations": [{"text": "M41L"}, {"text": "T215Y"}],
                  "score": 5
                }, {"mutations": [{"text": "L210W"}, {"text": "T215Y"}], "score": 5}]
              }, {
                "drugClass": {
                  "name": "NRTI",
                  "fullName": "Nucleoside Reverse Transcriptase Inhibitor",
                  "drugs": [{"name": "ABC", "displayAbbr": "ABC", "fullName": "abacavir"}, {
                    "name": "AZT",
                    "displayAbbr": "AZT",
                    "fullName": "zidovudine"
                  }, {"name": "D4T", "displayAbbr": "D4T", "fullName": "stavudine"}, {
                    "name": "DDI",
                    "displayAbbr": "DDI",
                    "fullName": "didanosine"
                  }, {"name": "FTC", "displayAbbr": "FTC", "fullName": "emtricitabine"}, {
                    "name": "LMV",
                    "displayAbbr": "3TC",
                    "fullName": "lamivudine"
                  }, {"name": "TDF", "displayAbbr": "TDF", "fullName": "tenofovir"}]
                },
                "drug": {"displayAbbr": "3TC"},
                "SIR": "R",
                "score": 80,
                "level": 5,
                "text": "High-Level Resistance",
                "partialScores": [{
                  "mutations": [{"text": "M184V"}],
                  "score": 60
                }, {
                  "mutations": [{"text": "M41L"}, {"text": "D67N"}, {"text": "T215Y"}],
                  "score": 5
                }, {
                  "mutations": [{"text": "M41L"}, {"text": "L210W"}, {"text": "T215Y"}],
                  "score": 5
                }, {
                  "mutations": [{"text": "M41L"}, {"text": "T215Y"}],
                  "score": 5
                }, {"mutations": [{"text": "L210W"}, {"text": "T215Y"}], "score": 5}]
              }, {
                "drugClass": {
                  "name": "NRTI",
                  "fullName": "Nucleoside Reverse Transcriptase Inhibitor",
                  "drugs": [{"name": "ABC", "displayAbbr": "ABC", "fullName": "abacavir"}, {
                    "name": "AZT",
                    "displayAbbr": "AZT",
                    "fullName": "zidovudine"
                  }, {"name": "D4T", "displayAbbr": "D4T", "fullName": "stavudine"}, {
                    "name": "DDI",
                    "displayAbbr": "DDI",
                    "fullName": "didanosine"
                  }, {"name": "FTC", "displayAbbr": "FTC", "fullName": "emtricitabine"}, {
                    "name": "LMV",
                    "displayAbbr": "3TC",
                    "fullName": "lamivudine"
                  }, {"name": "TDF", "displayAbbr": "TDF", "fullName": "tenofovir"}]
                },
                "drug": {"displayAbbr": "TDF"},
                "SIR": "R",
                "score": 70,
                "level": 5,
                "text": "High-Level Resistance",
                "partialScores": [{"mutations": [{"text": "M41L"}], "score": 5}, {
                  "mutations": [{"text": "D67N"}],
                  "score": 5
                }, {"mutations": [{"text": "M184V"}], "score": -10}, {
                  "mutations": [{"text": "L210W"}],
                  "score": 5
                }, {"mutations": [{"text": "T215Y"}], "score": 10}, {
                  "mutations": [{"text": "K219N"}],
                  "score": 5
                }, {
                  "mutations": [{"text": "M41L"}, {"text": "E44D"}, {"text": "L210W"}, {"text": "T215Y"}],
                  "score": 5
                }, {
                  "mutations": [{"text": "M41L"}, {"text": "D67N"}, {"text": "T215Y"}],
                  "score": 5
                }, {
                  "mutations": [{"text": "M41L"}, {"text": "L210W"}],
                  "score": 10
                }, {
                  "mutations": [{"text": "M41L"}, {"text": "L210W"}, {"text": "T215Y"}],
                  "score": 5
                }, {
                  "mutations": [{"text": "M41L"}, {"text": "T215Y"}],
                  "score": 10
                }, {
                  "mutations": [{"text": "D67N"}, {"text": "T215Y"}, {"text": "K219N"}],
                  "score": 5
                }, {"mutations": [{"text": "L210W"}, {"text": "T215Y"}], "score": 10}]
              }, {
                "drugClass": {
                  "name": "NNRTI",
                  "fullName": "Non-nucleoside Reverse Transcriptase Inhibitor",
                  "drugs": [{"name": "EFV", "displayAbbr": "EFV", "fullName": "efavirenz"}, {
                    "name": "ETR",
                    "displayAbbr": "ETR",
                    "fullName": "etravirine"
                  }, {"name": "NVP", "displayAbbr": "NVP", "fullName": "nevirapine"}, {
                    "name": "RPV",
                    "displayAbbr": "RPV",
                    "fullName": "rilpivirine"
                  }]
                },
                "drug": {"displayAbbr": "EFV"},
                "SIR": "R",
                "score": 110,
                "level": 5,
                "text": "High-Level Resistance",
                "partialScores": [{"mutations": [{"text": "A98G"}], "score": 15}, {
                  "mutations": [{"text": "K103N"}],
                  "score": 60
                }, {"mutations": [{"text": "Y181C"}], "score": 30}, {
                  "mutations": [{"text": "A98G"}, {"text": "Y181C"}],
                  "score": 5
                }]
              }, {
                "drugClass": {
                  "name": "NNRTI",
                  "fullName": "Non-nucleoside Reverse Transcriptase Inhibitor",
                  "drugs": [{"name": "EFV", "displayAbbr": "EFV", "fullName": "efavirenz"}, {
                    "name": "ETR",
                    "displayAbbr": "ETR",
                    "fullName": "etravirine"
                  }, {"name": "NVP", "displayAbbr": "NVP", "fullName": "nevirapine"}, {
                    "name": "RPV",
                    "displayAbbr": "RPV",
                    "fullName": "rilpivirine"
                  }]
                },
                "drug": {"displayAbbr": "ETR"},
                "SIR": "I",
                "score": 45,
                "level": 4,
                "text": "Intermediate Resistance",
                "partialScores": [{"mutations": [{"text": "A98G"}], "score": 10}, {
                  "mutations": [{"text": "Y181C"}],
                  "score": 30
                }, {"mutations": [{"text": "A98G"}, {"text": "Y181C"}], "score": 5}]
              }, {
                "drugClass": {
                  "name": "NNRTI",
                  "fullName": "Non-nucleoside Reverse Transcriptase Inhibitor",
                  "drugs": [{"name": "EFV", "displayAbbr": "EFV", "fullName": "efavirenz"}, {
                    "name": "ETR",
                    "displayAbbr": "ETR",
                    "fullName": "etravirine"
                  }, {"name": "NVP", "displayAbbr": "NVP", "fullName": "nevirapine"}, {
                    "name": "RPV",
                    "displayAbbr": "RPV",
                    "fullName": "rilpivirine"
                  }]
                },
                "drug": {"displayAbbr": "NVP"},
                "SIR": "R",
                "score": 155,
                "level": 5,
                "text": "High-Level Resistance",
                "partialScores": [{"mutations": [{"text": "A98G"}], "score": 30}, {
                  "mutations": [{"text": "K103N"}],
                  "score": 60
                }, {"mutations": [{"text": "Y181C"}], "score": 60}, {
                  "mutations": [{"text": "A98G"}, {"text": "Y181C"}],
                  "score": 5
                }]
              }, {
                "drugClass": {
                  "name": "NNRTI",
                  "fullName": "Non-nucleoside Reverse Transcriptase Inhibitor",
                  "drugs": [{"name": "EFV", "displayAbbr": "EFV", "fullName": "efavirenz"}, {
                    "name": "ETR",
                    "displayAbbr": "ETR",
                    "fullName": "etravirine"
                  }, {"name": "NVP", "displayAbbr": "NVP", "fullName": "nevirapine"}, {
                    "name": "RPV",
                    "displayAbbr": "RPV",
                    "fullName": "rilpivirine"
                  }]
                },
                "drug": {"displayAbbr": "RPV"},
                "SIR": "R",
                "score": 65,
                "level": 5,
                "text": "High-Level Resistance",
                "partialScores": [{"mutations": [{"text": "A98G"}], "score": 15}, {
                  "mutations": [{"text": "Y181C"}],
                  "score": 45
                }, {"mutations": [{"text": "A98G"}, {"text": "Y181C"}], "score": 5}]
              }],
              "mutationsByTypes": [{
                "mutationType": "NRTI",
                "mutations": [{
                  "consensus": "M",
                  "position": 41,
                  "AAs": "L",
                  "triplet": "TTG",
                  "insertedNAs": "",
                  "isInsertion": false,
                  "isDeletion": false,
                  "isIndel": false,
                  "isAmbiguous": false,
                  "isApobecMutation": false,
                  "isApobecDRM": false,
                  "hasStop": false,
                  "isUnusual": false,
                  "text": "M41L",
                  "shortText": "M41L"
                }, {
                  "consensus": "E",
                  "position": 44,
                  "AAs": "D",
                  "triplet": "GAC",
                  "insertedNAs": "",
                  "isInsertion": false,
                  "isDeletion": false,
                  "isIndel": false,
                  "isAmbiguous": false,
                  "isApobecMutation": false,
                  "isApobecDRM": false,
                  "hasStop": false,
                  "isUnusual": false,
                  "text": "E44D",
                  "shortText": "E44D"
                }, {
                  "consensus": "D",
                  "position": 67,
                  "AAs": "N",
                  "triplet": "AAC",
                  "insertedNAs": "",
                  "isInsertion": false,
                  "isDeletion": false,
                  "isIndel": false,
                  "isAmbiguous": false,
                  "isApobecMutation": false,
                  "isApobecDRM": true,
                  "hasStop": false,
                  "isUnusual": false,
                  "text": "D67N",
                  "shortText": "D67N"
                }, {
                  "consensus": "T",
                  "position": 69,
                  "AAs": "D",
                  "triplet": "GAT",
                  "insertedNAs": "",
                  "isInsertion": false,
                  "isDeletion": false,
                  "isIndel": false,
                  "isAmbiguous": false,
                  "isApobecMutation": false,
                  "isApobecDRM": false,
                  "hasStop": false,
                  "isUnusual": false,
                  "text": "T69D",
                  "shortText": "T69D"
                }, {
                  "consensus": "M",
                  "position": 184,
                  "AAs": "V",
                  "triplet": "GTG",
                  "insertedNAs": "",
                  "isInsertion": false,
                  "isDeletion": false,
                  "isIndel": false,
                  "isAmbiguous": false,
                  "isApobecMutation": false,
                  "isApobecDRM": false,
                  "hasStop": false,
                  "isUnusual": false,
                  "text": "M184V",
                  "shortText": "M184V"
                }, {
                  "consensus": "L",
                  "position": 210,
                  "AAs": "W",
                  "triplet": "TGG",
                  "insertedNAs": "",
                  "isInsertion": false,
                  "isDeletion": false,
                  "isIndel": false,
                  "isAmbiguous": false,
                  "isApobecMutation": false,
                  "isApobecDRM": false,
                  "hasStop": false,
                  "isUnusual": false,
                  "text": "L210W",
                  "shortText": "L210W"
                }, {
                  "consensus": "T",
                  "position": 215,
                  "AAs": "Y",
                  "triplet": "TAC",
                  "insertedNAs": "",
                  "isInsertion": false,
                  "isDeletion": false,
                  "isIndel": false,
                  "isAmbiguous": false,
                  "isApobecMutation": false,
                  "isApobecDRM": false,
                  "hasStop": false,
                  "isUnusual": false,
                  "text": "T215Y",
                  "shortText": "T215Y"
                }, {
                  "consensus": "K",
                  "position": 219,
                  "AAs": "KN",
                  "triplet": "AAM",
                  "insertedNAs": "",
                  "isInsertion": false,
                  "isDeletion": false,
                  "isIndel": false,
                  "isAmbiguous": false,
                  "isApobecMutation": false,
                  "isApobecDRM": false,
                  "hasStop": false,
                  "isUnusual": false,
                  "text": "K219KN",
                  "shortText": "K219KN"
                }]
              }, {
                "mutationType": "NNRTI",
                "mutations": [{
                  "consensus": "A",
                  "position": 98,
                  "AAs": "G",
                  "triplet": "GGA",
                  "insertedNAs": "",
                  "isInsertion": false,
                  "isDeletion": false,
                  "isIndel": false,
                  "isAmbiguous": false,
                  "isApobecMutation": false,
                  "isApobecDRM": false,
                  "hasStop": false,
                  "isUnusual": false,
                  "text": "A98G",
                  "shortText": "A98G"
                }, {
                  "consensus": "K",
                  "position": 103,
                  "AAs": "N",
                  "triplet": "AAC",
                  "insertedNAs": "",
                  "isInsertion": false,
                  "isDeletion": false,
                  "isIndel": false,
                  "isAmbiguous": false,
                  "isApobecMutation": false,
                  "isApobecDRM": false,
                  "hasStop": false,
                  "isUnusual": false,
                  "text": "K103N",
                  "shortText": "K103N"
                }, {
                  "consensus": "Y",
                  "position": 181,
                  "AAs": "C",
                  "triplet": "TGT",
                  "insertedNAs": "",
                  "isInsertion": false,
                  "isDeletion": false,
                  "isIndel": false,
                  "isAmbiguous": false,
                  "isApobecMutation": false,
                  "isApobecDRM": false,
                  "hasStop": false,
                  "isUnusual": false,
                  "text": "Y181C",
                  "shortText": "Y181C"
                }]
              }, {
                "mutationType": "Other",
                "mutations": [{
                  "consensus": "E",
                  "position": 6,
                  "AAs": "D",
                  "triplet": "GAC",
                  "insertedNAs": "",
                  "isInsertion": false,
                  "isDeletion": false,
                  "isIndel": false,
                  "isAmbiguous": false,
                  "isApobecMutation": false,
                  "isApobecDRM": false,
                  "hasStop": false,
                  "isUnusual": false,
                  "text": "E6D",
                  "shortText": "E6D"
                }, {
                  "consensus": "T",
                  "position": 39,
                  "AAs": "A",
                  "triplet": "GCA",
                  "insertedNAs": "",
                  "isInsertion": false,
                  "isDeletion": false,
                  "isIndel": false,
                  "isAmbiguous": false,
                  "isApobecMutation": false,
                  "isApobecDRM": false,
                  "hasStop": false,
                  "isUnusual": false,
                  "text": "T39A",
                  "shortText": "T39A"
                }, {
                  "consensus": "K",
                  "position": 43,
                  "AAs": "EQ",
                  "triplet": "SAG",
                  "insertedNAs": "",
                  "isInsertion": false,
                  "isDeletion": false,
                  "isIndel": false,
                  "isAmbiguous": false,
                  "isApobecMutation": false,
                  "isApobecDRM": false,
                  "hasStop": false,
                  "isUnusual": false,
                  "text": "K43EQ",
                  "shortText": "K43EQ"
                }, {
                  "consensus": "V",
                  "position": 118,
                  "AAs": "IV",
                  "triplet": "RTT",
                  "insertedNAs": "",
                  "isInsertion": false,
                  "isDeletion": false,
                  "isIndel": false,
                  "isAmbiguous": false,
                  "isApobecMutation": false,
                  "isApobecDRM": false,
                  "hasStop": false,
                  "isUnusual": false,
                  "text": "V118VI",
                  "shortText": "V118VI"
                }, {
                  "consensus": "K",
                  "position": 122,
                  "AAs": "E",
                  "triplet": "GAA",
                  "insertedNAs": "",
                  "isInsertion": false,
                  "isDeletion": false,
                  "isIndel": false,
                  "isAmbiguous": false,
                  "isApobecMutation": false,
                  "isApobecDRM": false,
                  "hasStop": false,
                  "isUnusual": false,
                  "text": "K122E",
                  "shortText": "K122E"
                }, {
                  "consensus": "I",
                  "position": 142,
                  "AAs": "T",
                  "triplet": "ACT",
                  "insertedNAs": "",
                  "isInsertion": false,
                  "isDeletion": false,
                  "isIndel": false,
                  "isAmbiguous": false,
                  "isApobecMutation": false,
                  "isApobecDRM": false,
                  "hasStop": false,
                  "isUnusual": false,
                  "text": "I142T",
                  "shortText": "I142T"
                }, {
                  "consensus": "K",
                  "position": 166,
                  "AAs": "R",
                  "triplet": "AGA",
                  "insertedNAs": "",
                  "isInsertion": false,
                  "isDeletion": false,
                  "isIndel": false,
                  "isAmbiguous": false,
                  "isApobecMutation": false,
                  "isApobecDRM": false,
                  "hasStop": false,
                  "isUnusual": false,
                  "text": "K166R",
                  "shortText": "K166R"
                }, {
                  "consensus": "G",
                  "position": 196,
                  "AAs": "E",
                  "triplet": "GAG",
                  "insertedNAs": "",
                  "isInsertion": false,
                  "isDeletion": false,
                  "isIndel": false,
                  "isAmbiguous": false,
                  "isApobecMutation": false,
                  "isApobecDRM": false,
                  "hasStop": false,
                  "isUnusual": false,
                  "text": "G196E",
                  "shortText": "G196E"
                }, {
                  "consensus": "Q",
                  "position": 197,
                  "AAs": "KQ",
                  "triplet": "MAG",
                  "insertedNAs": "",
                  "isInsertion": false,
                  "isDeletion": false,
                  "isIndel": false,
                  "isAmbiguous": false,
                  "isApobecMutation": false,
                  "isApobecDRM": false,
                  "hasStop": false,
                  "isUnusual": false,
                  "text": "Q197QK",
                  "shortText": "Q197QK"
                }, {
                  "consensus": "I",
                  "position": 202,
                  "AAs": "V",
                  "triplet": "GTA",
                  "insertedNAs": "",
                  "isInsertion": false,
                  "isDeletion": false,
                  "isIndel": false,
                  "isAmbiguous": false,
                  "isApobecMutation": false,
                  "isApobecDRM": false,
                  "hasStop": false,
                  "isUnusual": false,
                  "text": "I202V",
                  "shortText": "I202V"
                }, {
                  "consensus": "R",
                  "position": 211,
                  "AAs": "K",
                  "triplet": "AAG",
                  "insertedNAs": "",
                  "isInsertion": false,
                  "isDeletion": false,
                  "isIndel": false,
                  "isAmbiguous": false,
                  "isApobecMutation": false,
                  "isApobecDRM": false,
                  "hasStop": false,
                  "isUnusual": false,
                  "text": "R211K",
                  "shortText": "R211K"
                }]
              }],
              "commentsByTypes": [{
                "commentType": "NRTI",
                "comments": [{
                  "type": "NRTI",
                  "text": "M184V/I cause high-level in vitro resistance to 3TC and FTC and low-level resistance to ddI and ABC. However, M184V/I are not contraindications to continued treatment with 3TC or FTC because they increase susceptibility to AZT, TDF and d4T and are associated with clinically significant reductions in HIV-1 replication.",
                  "highlightText": ["M184V"]
                }, {
                  "type": "NRTI",
                  "text": "L210W is a TAM that usually occurs in combination with M41L and T215Y. The combination of M41, L210W and T215Y causes high-level resistance to AZT and d4T and intermediate to high-level resistance to ddI, ABC and TDF.",
                  "highlightText": ["L210W"]
                }, {
                  "type": "NRTI",
                  "text": "T215Y is a TAM that causes intermediate/high-level resistance to AZT and d4T, low-level resistance to ddI, and potentially low-level resistance to ABC and TDF.",
                  "highlightText": ["T215Y"]
                }, {
                  "type": "NRTI",
                  "text": "K219N/R are accessory TAMS that usually occur in combination with multiple other TAMs.",
                  "highlightText": ["K219N"]
                }, {
                  "type": "NRTI",
                  "text": "M41L is a TAM that usually occurs with T215Y. In combination, M41L plus T215Y confer intermediate / high-level resistance to AZT and d4T and contribute to reduced ddI, ABC and TDF susceptibility.",
                  "highlightText": ["M41L"]
                }, {
                  "type": "NRTI",
                  "text": "E44D is a relatively non-polymorphic accessory mutation and E44A is a nonpolymorphic accessory mutation. Each usually occurs with multiple TAMs.",
                  "highlightText": ["E44D"]
                }, {
                  "type": "NRTI",
                  "text": "D67N is a non-polymorphic TAM associated with low-level resistance to AZT and d4T. When present with other TAMs, it contributes reduced susceptibility to ABC, ddI, and TDF.",
                  "highlightText": ["D67N"]
                }, {
                  "type": "NRTI",
                  "text": "T69D is a non-polymorphic mutation that reduces susceptibility to ddI and possibly d4T.",
                  "highlightText": ["T69D"]
                }]
              }, {
                "commentType": "NNRTI",
                "comments": [{
                  "type": "NNRTI",
                  "text": "K103N is a non-polymorphic mutation that causes high-level resistance to NVP and EFV.",
                  "highlightText": ["K103N"]
                }, {
                  "type": "NNRTI",
                  "text": "Y181C is a non-polymorphic mutation selected in patients receiving each of the NNRTIs. It causes high-level reduction in NVP susceptibility, intermediate-level reduction in RPV and ETR susceptibility, and low-level reduction in EFV susceptibility. Y181C has a high weight in the Tibotec ETR genotypic susceptibility score.",
                  "highlightText": ["Y181C"]
                }, {
                  "type": "NNRTI",
                  "text": "A98G is a non-polymorphic accessory mutation associated with low-level reduced susceptibility to each of the NNRTIs.",
                  "highlightText": ["A98G"]
                }]
              }, {
                "commentType": "Other",
                "comments": [{
                  "type": "Other",
                  "text": "V118I is a polymorphic accessory NRTI-resistance mutation that often occurs in combination with multiple TAMs.",
                  "highlightText": ["V118I"]
                }]
              }]
            }]
          }, {
            "inputSequence": {
              "header": "AY030413",
              "sequence": "CCTCAAATCACTCTTTGGCAACGACCCATCGTCACAATAAGGATAGGAGGGCAACTAAAGGAAGCTCTATTAGATACAGGAGCAGATGATACAGTATTAGAAGAAATGAATTTGCCAGGAAAATGGAAACCAAAAATGATAGGGGGAATTGGAGGTTTTGTCAAAGTAAGACAGTATGAGCAGATACCCGTAGAAATCTGCGGACATAAAGTTATAGGTACAGTATTAGTAGGACCTACACCTGCCAACATAATTGGAAGAAATCTGATGACTCAGCTTGGTTGTACTTTAAATTTTCCCATTAGTCCTATTGAAACTGTACCAGTAAAATTAAAGCCAGGAATGGATGGCCCAAAAGTTAAACAATGGCCATTGACAGAGGAAAAAATAAATGCATTAGTAGAAATTTGTGCAGAAATGGAAAAGGAAGGGAAAATTTCWAAAATTGGGCCTGAAAATCCATACAATACTCCAGTATTTGCYATAAAGAAAAAGAACAGTACTAGATGGAGAAAATTAGTAGATTTCAGAGAACTTAATAAGAGAACTCAAGACTTCTGGGAAGTTCAATTAGGAATACCACATCCCKCAGGGTTAAAAAAGAAAAAATCAGTAACAGTACTGGATGTGGGTGATGCATACTTTTCAGTTCCCTTATATGAAGACTTTAGAAAGTATACTGCATTTACCATACCTAGTAAAAACAATGAGACACCAGGGATTAGATACCAGTATAATGTGCTTCCACAGGGATGGAAAGGATCACCAGCAATATTCCAAAGTAGCATGACAAAAATCTTAGAGCCTTTTAGACAACAAAATCCAGACCTAGTTATCTATCAATACATGGATGATTTGTATGTAGGATCTGACTTAGAAATAGGGCAGCATAGAACAAAAATAGAGGAACTGAGACAACATCTGTTGAGGTGGGGATTTTTCACACCAGATCAAAAACATCAGAARGAACCYCCATTCCTTTGGATGGGTTATGAACTCCATCCTGATAAATGGACAGTACAGCCTATACAGCTGCCAGAA",
              "MD5": "405c326b37f472a36db3d4eeedc75d10",
              "SHA512": "ba3a8d98679ce607d6cf957245f20215141d6c23dbd761f6f916a17afc5027d3c0e2f0d11b8770fb0697ceed0008e367ce316281b0a3b969ad8bcf8e710b9773"
            },
            "validationResults": [],
            "absoluteFirstNA": 2253,
            "alignedGeneSequences": [{
              "gene": {
                "name": "PR",
                "consensus": "PQITLWQRPLVTIKIGGQLKEALLDTGADDTVLEEMNLPGRWKPKMIGGIGGFIKVRQYDQILIEICGHKAIGTVLVGPTPVNIIGRNLLTQIGCTLNF",
                "length": 99,
                "drugClasses": [{
                  "name": "PI",
                  "fullName": "Protease Inhibitor",
                  "drugs": [{"name": "ATV", "displayAbbr": "ATV/r", "fullName": "atazanavir/r"}, {
                    "name": "DRV",
                    "displayAbbr": "DRV/r",
                    "fullName": "darunavir/r"
                  }, {"name": "FPV", "displayAbbr": "FPV/r", "fullName": "fosamprenavir/r"}, {
                    "name": "IDV",
                    "displayAbbr": "IDV/r",
                    "fullName": "indinavir/r"
                  }, {"name": "LPV", "displayAbbr": "LPV/r", "fullName": "lopinavir/r"}, {
                    "name": "NFV",
                    "displayAbbr": "NFV",
                    "fullName": "nelfinavir"
                  }, {"name": "SQV", "displayAbbr": "SQV/r", "fullName": "saquinavir/r"}, {
                    "name": "TPV",
                    "displayAbbr": "TPV/r",
                    "fullName": "tipranavir/r"
                  }]
                }],
                "mutationTypes": ["Major", "Accessory", "Other"]
              },
              "firstAA": 1,
              "lastAA": 99,
              "firstNA": 1,
              "lastNA": 297,
              "matchPcnt": 88.88888549804688,
              "prettyPairwise": {
                "positionLine": [" 1 ", " 2 ", " 3 ", " 4 ", " 5 ", " 6 ", " 7 ", " 8 ", " 9 ", "10 ", "11 ", "12 ", "13 ", "14 ", "15 ", "16 ", "17 ", "18 ", "19 ", "20 ", "21 ", "22 ", "23 ", "24 ", "25 ", "26 ", "27 ", "28 ", "29 ", "30 ", "31 ", "32 ", "33 ", "34 ", "35 ", "36 ", "37 ", "38 ", "39 ", "40 ", "41 ", "42 ", "43 ", "44 ", "45 ", "46 ", "47 ", "48 ", "49 ", "50 ", "51 ", "52 ", "53 ", "54 ", "55 ", "56 ", "57 ", "58 ", "59 ", "60 ", "61 ", "62 ", "63 ", "64 ", "65 ", "66 ", "67 ", "68 ", "69 ", "70 ", "71 ", "72 ", "73 ", "74 ", "75 ", "76 ", "77 ", "78 ", "79 ", "80 ", "81 ", "82 ", "83 ", "84 ", "85 ", "86 ", "87 ", "88 ", "89 ", "90 ", "91 ", "92 ", "93 ", "94 ", "95 ", "96 ", "97 ", "98 ", "99 "],
                "refAALine": [" P ", " Q ", " I ", " T ", " L ", " W ", " Q ", " R ", " P ", " L ", " V ", " T ", " I ", " K ", " I ", " G ", " G ", " Q ", " L ", " K ", " E ", " A ", " L ", " L ", " D ", " T ", " G ", " A ", " D ", " D ", " T ", " V ", " L ", " E ", " E ", " M ", " N ", " L ", " P ", " G ", " R ", " W ", " K ", " P ", " K ", " M ", " I ", " G ", " G ", " I ", " G ", " G ", " F ", " I ", " K ", " V ", " R ", " Q ", " Y ", " D ", " Q ", " I ", " L ", " I ", " E ", " I ", " C ", " G ", " H ", " K ", " A ", " I ", " G ", " T ", " V ", " L ", " V ", " G ", " P ", " T ", " P ", " V ", " N ", " I ", " I ", " G ", " R ", " N ", " L ", " L ", " T ", " Q ", " I ", " G ", " C ", " T ", " L ", " N ", " F "],
                "alignedNAsLine": ["CCT", "CAA", "ATC", "ACT", "CTT", "TGG", "CAA", "CGA", "CCC", "ATC", "GTC", "ACA", "ATA", "AGG", "ATA", "GGA", "GGG", "CAA", "CTA", "AAG", "GAA", "GCT", "CTA", "TTA", "GAT", "ACA", "GGA", "GCA", "GAT", "GAT", "ACA", "GTA", "TTA", "GAA", "GAA", "ATG", "AAT", "TTG", "CCA", "GGA", "AAA", "TGG", "AAA", "CCA", "AAA", "ATG", "ATA", "GGG", "GGA", "ATT", "GGA", "GGT", "TTT", "GTC", "AAA", "GTA", "AGA", "CAG", "TAT", "GAG", "CAG", "ATA", "CCC", "GTA", "GAA", "ATC", "TGC", "GGA", "CAT", "AAA", "GTT", "ATA", "GGT", "ACA", "GTA", "TTA", "GTA", "GGA", "CCT", "ACA", "CCT", "GCC", "AAC", "ATA", "ATT", "GGA", "AGA", "AAT", "CTG", "ATG", "ACT", "CAG", "CTT", "GGT", "TGT", "ACT", "TTA", "AAT", "TTT"],
                "mutationLine": [" - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " I ", " - ", " - ", " - ", " R ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " K ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " V ", " - ", " - ", " - ", " - ", " - ", " E ", " - ", " - ", " P ", " V ", " - ", " - ", " - ", " - ", " - ", " - ", " V ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " A ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " M ", " - ", " - ", " L ", " - ", " - ", " - ", " - ", " - ", " - "]
              },
              "mutations": [{
                "consensus": "L",
                "position": 10,
                "AAs": "I",
                "triplet": "ATC",
                "insertedNAs": "",
                "isInsertion": false,
                "isDeletion": false,
                "isIndel": false,
                "isAmbiguous": false,
                "isApobecMutation": false,
                "isApobecDRM": false,
                "hasStop": false,
                "isUnusual": false,
                "types": ["Other"],
                "primaryType": "Other",
                "comments": [{
                  "triggeredAAs": "I",
                  "type": "Other",
                  "text": "L10I/V are polymorphic, PI-selected accessory mutations that increase the replication of viruses with other PI-resistance mutations."
                }],
                "text": "L10I",
                "shortText": "L10I"
              }, {
                "consensus": "K",
                "position": 14,
                "AAs": "R",
                "triplet": "AGG",
                "insertedNAs": "",
                "isInsertion": false,
                "isDeletion": false,
                "isIndel": false,
                "isAmbiguous": false,
                "isApobecMutation": false,
                "isApobecDRM": false,
                "hasStop": false,
                "isUnusual": false,
                "types": ["Other"],
                "primaryType": "Other",
                "comments": [],
                "text": "K14R",
                "shortText": "K14R"
              }, {
                "consensus": "R",
                "position": 41,
                "AAs": "K",
                "triplet": "AAA",
                "insertedNAs": "",
                "isInsertion": false,
                "isDeletion": false,
                "isIndel": false,
                "isAmbiguous": false,
                "isApobecMutation": false,
                "isApobecDRM": false,
                "hasStop": false,
                "isUnusual": false,
                "types": ["Other"],
                "primaryType": "Other",
                "comments": [],
                "text": "R41K",
                "shortText": "R41K"
              }, {
                "consensus": "I",
                "position": 54,
                "AAs": "V",
                "triplet": "GTC",
                "insertedNAs": "",
                "isInsertion": false,
                "isDeletion": false,
                "isIndel": false,
                "isAmbiguous": false,
                "isApobecMutation": false,
                "isApobecDRM": false,
                "hasStop": false,
                "isUnusual": false,
                "types": ["Major"],
                "primaryType": "Major",
                "comments": [{
                  "triggeredAAs": "V",
                  "type": "Major",
                  "text": "I54V is a non-polymorphic PI-selected mutation that contributes reduced susceptibility to each of the PIs except DRV."
                }],
                "text": "I54V",
                "shortText": "I54V"
              }, {
                "consensus": "D",
                "position": 60,
                "AAs": "E",
                "triplet": "GAG",
                "insertedNAs": "",
                "isInsertion": false,
                "isDeletion": false,
                "isIndel": false,
                "isAmbiguous": false,
                "isApobecMutation": false,
                "isApobecDRM": false,
                "hasStop": false,
                "isUnusual": false,
                "types": ["Other"],
                "primaryType": "Other",
                "comments": [],
                "text": "D60E",
                "shortText": "D60E"
              }, {
                "consensus": "L",
                "position": 63,
                "AAs": "P",
                "triplet": "CCC",
                "insertedNAs": "",
                "isInsertion": false,
                "isDeletion": false,
                "isIndel": false,
                "isAmbiguous": false,
                "isApobecMutation": false,
                "isApobecDRM": false,
                "hasStop": false,
                "isUnusual": false,
                "types": ["Other"],
                "primaryType": "Other",
                "comments": [],
                "text": "L63P",
                "shortText": "L63P"
              }, {
                "consensus": "I",
                "position": 64,
                "AAs": "V",
                "triplet": "GTA",
                "insertedNAs": "",
                "isInsertion": false,
                "isDeletion": false,
                "isIndel": false,
                "isAmbiguous": false,
                "isApobecMutation": false,
                "isApobecDRM": false,
                "hasStop": false,
                "isUnusual": false,
                "types": ["Other"],
                "primaryType": "Other",
                "comments": [],
                "text": "I64V",
                "shortText": "I64V"
              }, {
                "consensus": "A",
                "position": 71,
                "AAs": "V",
                "triplet": "GTT",
                "insertedNAs": "",
                "isInsertion": false,
                "isDeletion": false,
                "isIndel": false,
                "isAmbiguous": false,
                "isApobecMutation": false,
                "isApobecDRM": false,
                "hasStop": false,
                "isUnusual": false,
                "types": ["Other"],
                "primaryType": "Other",
                "comments": [{
                  "triggeredAAs": "V",
                  "type": "Other",
                  "text": "A71V/T are polymorphic, PI-selected accessory mutations that increase the replication of viruses with other PI-resistance mutations."
                }],
                "text": "A71V",
                "shortText": "A71V"
              }, {
                "consensus": "V",
                "position": 82,
                "AAs": "A",
                "triplet": "GCC",
                "insertedNAs": "",
                "isInsertion": false,
                "isDeletion": false,
                "isIndel": false,
                "isAmbiguous": false,
                "isApobecMutation": false,
                "isApobecDRM": false,
                "hasStop": false,
                "isUnusual": false,
                "types": ["Major"],
                "primaryType": "Major",
                "comments": [{
                  "triggeredAAs": "A",
                  "type": "Major",
                  "text": "V82A is a non-polymorphic mutation selected primarily by IDV and LPV. It reduces susceptibility to these PIs and contributes cross-resistance to each of the remaining PIs except DRV and TPV."
                }],
                "text": "V82A",
                "shortText": "V82A"
              }, {
                "consensus": "L",
                "position": 90,
                "AAs": "M",
                "triplet": "ATG",
                "insertedNAs": "",
                "isInsertion": false,
                "isDeletion": false,
                "isIndel": false,
                "isAmbiguous": false,
                "isApobecMutation": false,
                "isApobecDRM": false,
                "hasStop": false,
                "isUnusual": false,
                "types": ["Major"],
                "primaryType": "Major",
                "comments": [{
                  "triggeredAAs": "M",
                  "type": "Major",
                  "text": "L90M is a non-polymorphic PI-selected mutation that reduces susceptibility to each of the PIs except TPV and DRV."
                }],
                "text": "L90M",
                "shortText": "L90M"
              }, {
                "consensus": "I",
                "position": 93,
                "AAs": "L",
                "triplet": "CTT",
                "insertedNAs": "",
                "isInsertion": false,
                "isDeletion": false,
                "isIndel": false,
                "isAmbiguous": false,
                "isApobecMutation": false,
                "isApobecDRM": false,
                "hasStop": false,
                "isUnusual": false,
                "types": ["Other"],
                "primaryType": "Other",
                "comments": [],
                "text": "I93L",
                "shortText": "I93L"
              }],
              "APOBEC": [],
              "APOBEC_DRM": [],
              "DRM": [{"text": "I54V"}, {"text": "V82A"}, {"text": "L90M"}],
              "SDRM": [{"text": "I54V"}, {"text": "V82A"}, {"text": "L90M"}],
              "unusualMutations": [],
              "treatmentSelectedMutations": [],
              "frameShifts": []
            }, {
              "gene": {
                "name": "RT",
                "consensus": "PISPIETVPVKLKPGMDGPKVKQWPLTEEKIKALVEICTEMEKEGKISKIGPENPYNTPVFAIKKKDSTKWRKLVDFRELNKRTQDFWEVQLGIPHPAGLKKKKSVTVLDVGDAYFSVPLDKDFRKYTAFTIPSINNETPGIRYQYNVLPQGWKGSPAIFQSSMTKILEPFRKQNPDIVIYQYMDDLYVGSDLEIGQHRTKIEELRQHLLRWGFTTPDKKHQKEPPFLWMGYELHPDKWTVQPIVLPEKDSWTVNDIQKLVGKLNWASQIYAGIKVKQLCKLLRGTKALTEVIPLTEEAELELAENREILKEPVHGVYYDPSKDLIAEIQKQGQGQWTYQIYQEPFKNLKTGKYARMRGAHTNDVKQLTEAVQKIATESIVIWGKTPKFKLPIQKETWEAWWTEYWQATWIPEWEFVNTPPLVKLWYQLEKEPIVGAETFYVDGAANRETKLGKAGYVTDRGRQKVVSLTDTTNQKTELQAIHLALQDSGLEVNIVTDSQYALGIIQAQPDKSESELVSQIIEQLIKKEKVYLAWVPAHKGIGGNEQVDKLVSAGIRKVL",
                "length": 560,
                "drugClasses": [{
                  "name": "NRTI",
                  "fullName": "Nucleoside Reverse Transcriptase Inhibitor",
                  "drugs": [{"name": "ABC", "displayAbbr": "ABC", "fullName": "abacavir"}, {
                    "name": "AZT",
                    "displayAbbr": "AZT",
                    "fullName": "zidovudine"
                  }, {"name": "D4T", "displayAbbr": "D4T", "fullName": "stavudine"}, {
                    "name": "DDI",
                    "displayAbbr": "DDI",
                    "fullName": "didanosine"
                  }, {"name": "FTC", "displayAbbr": "FTC", "fullName": "emtricitabine"}, {
                    "name": "LMV",
                    "displayAbbr": "3TC",
                    "fullName": "lamivudine"
                  }, {"name": "TDF", "displayAbbr": "TDF", "fullName": "tenofovir"}]
                }, {
                  "name": "NNRTI",
                  "fullName": "Non-nucleoside Reverse Transcriptase Inhibitor",
                  "drugs": [{"name": "EFV", "displayAbbr": "EFV", "fullName": "efavirenz"}, {
                    "name": "ETR",
                    "displayAbbr": "ETR",
                    "fullName": "etravirine"
                  }, {"name": "NVP", "displayAbbr": "NVP", "fullName": "nevirapine"}, {
                    "name": "RPV",
                    "displayAbbr": "RPV",
                    "fullName": "rilpivirine"
                  }]
                }],
                "mutationTypes": ["NRTI", "NNRTI", "Other"]
              },
              "firstAA": 1,
              "lastAA": 248,
              "firstNA": 298,
              "lastNA": 1041,
              "matchPcnt": 94.75806427001953,
              "prettyPairwise": {
                "positionLine": [" 1 ", " 2 ", " 3 ", " 4 ", " 5 ", " 6 ", " 7 ", " 8 ", " 9 ", "10 ", "11 ", "12 ", "13 ", "14 ", "15 ", "16 ", "17 ", "18 ", "19 ", "20 ", "21 ", "22 ", "23 ", "24 ", "25 ", "26 ", "27 ", "28 ", "29 ", "30 ", "31 ", "32 ", "33 ", "34 ", "35 ", "36 ", "37 ", "38 ", "39 ", "40 ", "41 ", "42 ", "43 ", "44 ", "45 ", "46 ", "47 ", "48 ", "49 ", "50 ", "51 ", "52 ", "53 ", "54 ", "55 ", "56 ", "57 ", "58 ", "59 ", "60 ", "61 ", "62 ", "63 ", "64 ", "65 ", "66 ", "67 ", "68 ", "69 ", "70 ", "71 ", "72 ", "73 ", "74 ", "75 ", "76 ", "77 ", "78 ", "79 ", "80 ", "81 ", "82 ", "83 ", "84 ", "85 ", "86 ", "87 ", "88 ", "89 ", "90 ", "91 ", "92 ", "93 ", "94 ", "95 ", "96 ", "97 ", "98 ", "99 ", "100", "101", "102", "103", "104", "105", "106", "107", "108", "109", "110", "111", "112", "113", "114", "115", "116", "117", "118", "119", "120", "121", "122", "123", "124", "125", "126", "127", "128", "129", "130", "131", "132", "133", "134", "135", "136", "137", "138", "139", "140", "141", "142", "143", "144", "145", "146", "147", "148", "149", "150", "151", "152", "153", "154", "155", "156", "157", "158", "159", "160", "161", "162", "163", "164", "165", "166", "167", "168", "169", "170", "171", "172", "173", "174", "175", "176", "177", "178", "179", "180", "181", "182", "183", "184", "185", "186", "187", "188", "189", "190", "191", "192", "193", "194", "195", "196", "197", "198", "199", "200", "201", "202", "203", "204", "205", "206", "207", "208", "209", "210", "211", "212", "213", "214", "215", "216", "217", "218", "219", "220", "221", "222", "223", "224", "225", "226", "227", "228", "229", "230", "231", "232", "233", "234", "235", "236", "237", "238", "239", "240", "241", "242", "243", "244", "245", "246", "247", "248"],
                "refAALine": [" P ", " I ", " S ", " P ", " I ", " E ", " T ", " V ", " P ", " V ", " K ", " L ", " K ", " P ", " G ", " M ", " D ", " G ", " P ", " K ", " V ", " K ", " Q ", " W ", " P ", " L ", " T ", " E ", " E ", " K ", " I ", " K ", " A ", " L ", " V ", " E ", " I ", " C ", " T ", " E ", " M ", " E ", " K ", " E ", " G ", " K ", " I ", " S ", " K ", " I ", " G ", " P ", " E ", " N ", " P ", " Y ", " N ", " T ", " P ", " V ", " F ", " A ", " I ", " K ", " K ", " K ", " D ", " S ", " T ", " K ", " W ", " R ", " K ", " L ", " V ", " D ", " F ", " R ", " E ", " L ", " N ", " K ", " R ", " T ", " Q ", " D ", " F ", " W ", " E ", " V ", " Q ", " L ", " G ", " I ", " P ", " H ", " P ", " A ", " G ", " L ", " K ", " K ", " K ", " K ", " S ", " V ", " T ", " V ", " L ", " D ", " V ", " G ", " D ", " A ", " Y ", " F ", " S ", " V ", " P ", " L ", " D ", " K ", " D ", " F ", " R ", " K ", " Y ", " T ", " A ", " F ", " T ", " I ", " P ", " S ", " I ", " N ", " N ", " E ", " T ", " P ", " G ", " I ", " R ", " Y ", " Q ", " Y ", " N ", " V ", " L ", " P ", " Q ", " G ", " W ", " K ", " G ", " S ", " P ", " A ", " I ", " F ", " Q ", " S ", " S ", " M ", " T ", " K ", " I ", " L ", " E ", " P ", " F ", " R ", " K ", " Q ", " N ", " P ", " D ", " I ", " V ", " I ", " Y ", " Q ", " Y ", " M ", " D ", " D ", " L ", " Y ", " V ", " G ", " S ", " D ", " L ", " E ", " I ", " G ", " Q ", " H ", " R ", " T ", " K ", " I ", " E ", " E ", " L ", " R ", " Q ", " H ", " L ", " L ", " R ", " W ", " G ", " F ", " T ", " T ", " P ", " D ", " K ", " K ", " H ", " Q ", " K ", " E ", " P ", " P ", " F ", " L ", " W ", " M ", " G ", " Y ", " E ", " L ", " H ", " P ", " D ", " K ", " W ", " T ", " V ", " Q ", " P ", " I ", " V ", " L ", " P ", " E "],
                "alignedNAsLine": ["CCC", "ATT", "AGT", "CCT", "ATT", "GAA", "ACT", "GTA", "CCA", "GTA", "AAA", "TTA", "AAG", "CCA", "GGA", "ATG", "GAT", "GGC", "CCA", "AAA", "GTT", "AAA", "CAA", "TGG", "CCA", "TTG", "ACA", "GAG", "GAA", "AAA", "ATA", "AAT", "GCA", "TTA", "GTA", "GAA", "ATT", "TGT", "GCA", "GAA", "ATG", "GAA", "AAG", "GAA", "GGG", "AAA", "ATT", "TCW", "AAA", "ATT", "GGG", "CCT", "GAA", "AAT", "CCA", "TAC", "AAT", "ACT", "CCA", "GTA", "TTT", "GCY", "ATA", "AAG", "AAA", "AAG", "AAC", "AGT", "ACT", "AGA", "TGG", "AGA", "AAA", "TTA", "GTA", "GAT", "TTC", "AGA", "GAA", "CTT", "AAT", "AAG", "AGA", "ACT", "CAA", "GAC", "TTC", "TGG", "GAA", "GTT", "CAA", "TTA", "GGA", "ATA", "CCA", "CAT", "CCC", "KCA", "GGG", "TTA", "AAA", "AAG", "AAA", "AAA", "TCA", "GTA", "ACA", "GTA", "CTG", "GAT", "GTG", "GGT", "GAT", "GCA", "TAC", "TTT", "TCA", "GTT", "CCC", "TTA", "TAT", "GAA", "GAC", "TTT", "AGA", "AAG", "TAT", "ACT", "GCA", "TTT", "ACC", "ATA", "CCT", "AGT", "AAA", "AAC", "AAT", "GAG", "ACA", "CCA", "GGG", "ATT", "AGA", "TAC", "CAG", "TAT", "AAT", "GTG", "CTT", "CCA", "CAG", "GGA", "TGG", "AAA", "GGA", "TCA", "CCA", "GCA", "ATA", "TTC", "CAA", "AGT", "AGC", "ATG", "ACA", "AAA", "ATC", "TTA", "GAG", "CCT", "TTT", "AGA", "CAA", "CAA", "AAT", "CCA", "GAC", "CTA", "GTT", "ATC", "TAT", "CAA", "TAC", "ATG", "GAT", "GAT", "TTG", "TAT", "GTA", "GGA", "TCT", "GAC", "TTA", "GAA", "ATA", "GGG", "CAG", "CAT", "AGA", "ACA", "AAA", "ATA", "GAG", "GAA", "CTG", "AGA", "CAA", "CAT", "CTG", "TTG", "AGG", "TGG", "GGA", "TTT", "TTC", "ACA", "CCA", "GAT", "CAA", "AAA", "CAT", "CAG", "AAR", "GAA", "CCY", "CCA", "TTC", "CTT", "TGG", "ATG", "GGT", "TAT", "GAA", "CTC", "CAT", "CCT", "GAT", "AAA", "TGG", "ACA", "GTA", "CAG", "CCT", "ATA", "CAG", "CTG", "CCA", "GAA"],
                "mutationLine": [" - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " N ", " - ", " - ", " - ", " - ", " - ", " - ", " A ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " N ", " - ", " - ", " R ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", "AS ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " Y ", " E ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " K ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " Q ", " - ", " - ", " - ", " - ", " L ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " F ", " - ", " - ", " - ", " Q ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " - ", " Q ", " - ", " - ", " - "]
              },
              "mutations": [{
                "consensus": "K",
                "position": 32,
                "AAs": "N",
                "triplet": "AAT",
                "insertedNAs": "",
                "isInsertion": false,
                "isDeletion": false,
                "isIndel": false,
                "isAmbiguous": false,
                "isApobecMutation": false,
                "isApobecDRM": false,
                "hasStop": false,
                "isUnusual": false,
                "types": ["Other"],
                "primaryType": "Other",
                "comments": [],
                "text": "K32N",
                "shortText": "K32N"
              }, {
                "consensus": "T",
                "position": 39,
                "AAs": "A",
                "triplet": "GCA",
                "insertedNAs": "",
                "isInsertion": false,
                "isDeletion": false,
                "isIndel": false,
                "isAmbiguous": false,
                "isApobecMutation": false,
                "isApobecDRM": false,
                "hasStop": false,
                "isUnusual": false,
                "types": ["Other"],
                "primaryType": "Other",
                "comments": [],
                "text": "T39A",
                "shortText": "T39A"
              }, {
                "consensus": "D",
                "position": 67,
                "AAs": "N",
                "triplet": "AAC",
                "insertedNAs": "",
                "isInsertion": false,
                "isDeletion": false,
                "isIndel": false,
                "isAmbiguous": false,
                "isApobecMutation": false,
                "isApobecDRM": true,
                "hasStop": false,
                "isUnusual": false,
                "types": ["NRTI"],
                "primaryType": "NRTI",
                "comments": [{
                  "triggeredAAs": "N",
                  "type": "NRTI",
                  "text": "D67N is a non-polymorphic TAM associated with low-level resistance to AZT and d4T. When present with other TAMs, it contributes reduced susceptibility to ABC, ddI, and TDF."
                }],
                "text": "D67N",
                "shortText": "D67N"
              }, {
                "consensus": "K",
                "position": 70,
                "AAs": "R",
                "triplet": "AGA",
                "insertedNAs": "",
                "isInsertion": false,
                "isDeletion": false,
                "isIndel": false,
                "isAmbiguous": false,
                "isApobecMutation": false,
                "isApobecDRM": false,
                "hasStop": false,
                "isUnusual": false,
                "types": ["NRTI"],
                "primaryType": "NRTI",
                "comments": [{
                  "triggeredAAs": "R",
                  "type": "NRTI",
                  "text": "K70R causes intermediate resistance to AZT and possibly low-level resistance to D4T, DDI, ABC and TDF."
                }],
                "text": "K70R",
                "shortText": "K70R"
              }, {
                "consensus": "A",
                "position": 98,
                "AAs": "AS",
                "triplet": "KCA",
                "insertedNAs": "",
                "isInsertion": false,
                "isDeletion": false,
                "isIndel": false,
                "isAmbiguous": false,
                "isApobecMutation": false,
                "isApobecDRM": false,
                "hasStop": false,
                "isUnusual": false,
                "types": ["Other"],
                "primaryType": "Other",
                "comments": [],
                "text": "A98AS",
                "shortText": "A98AS"
              }, {
                "consensus": "D",
                "position": 121,
                "AAs": "Y",
                "triplet": "TAT",
                "insertedNAs": "",
                "isInsertion": false,
                "isDeletion": false,
                "isIndel": false,
                "isAmbiguous": false,
                "isApobecMutation": false,
                "isApobecDRM": false,
                "hasStop": false,
                "isUnusual": false,
                "types": ["Other"],
                "primaryType": "Other",
                "comments": [],
                "text": "D121Y",
                "shortText": "D121Y"
              }, {
                "consensus": "K",
                "position": 122,
                "AAs": "E",
                "triplet": "GAA",
                "insertedNAs": "",
                "isInsertion": false,
                "isDeletion": false,
                "isIndel": false,
                "isAmbiguous": false,
                "isApobecMutation": false,
                "isApobecDRM": false,
                "hasStop": false,
                "isUnusual": false,
                "types": ["Other"],
                "primaryType": "Other",
                "comments": [],
                "text": "K122E",
                "shortText": "K122E"
              }, {
                "consensus": "I",
                "position": 135,
                "AAs": "K",
                "triplet": "AAA",
                "insertedNAs": "",
                "isInsertion": false,
                "isDeletion": false,
                "isIndel": false,
                "isAmbiguous": false,
                "isApobecMutation": false,
                "isApobecDRM": false,
                "hasStop": false,
                "isUnusual": false,
                "types": ["Other"],
                "primaryType": "Other",
                "comments": [],
                "text": "I135K",
                "shortText": "I135K"
              }, {
                "consensus": "K",
                "position": 173,
                "AAs": "Q",
                "triplet": "CAA",
                "insertedNAs": "",
                "isInsertion": false,
                "isDeletion": false,
                "isIndel": false,
                "isAmbiguous": false,
                "isApobecMutation": false,
                "isApobecDRM": false,
                "hasStop": false,
                "isUnusual": false,
                "types": ["Other"],
                "primaryType": "Other",
                "comments": [],
                "text": "K173Q",
                "shortText": "K173Q"
              }, {
                "consensus": "I",
                "position": 178,
                "AAs": "L",
                "triplet": "CTA",
                "insertedNAs": "",
                "isInsertion": false,
                "isDeletion": false,
                "isIndel": false,
                "isAmbiguous": false,
                "isApobecMutation": false,
                "isApobecDRM": false,
                "hasStop": false,
                "isUnusual": false,
                "types": ["Other"],
                "primaryType": "Other",
                "comments": [],
                "text": "I178L",
                "shortText": "I178L"
              }, {
                "consensus": "T",
                "position": 215,
                "AAs": "F",
                "triplet": "TTC",
                "insertedNAs": "",
                "isInsertion": false,
                "isDeletion": false,
                "isIndel": false,
                "isAmbiguous": false,
                "isApobecMutation": false,
                "isApobecDRM": false,
                "hasStop": false,
                "isUnusual": false,
                "types": ["NRTI"],
                "primaryType": "NRTI",
                "comments": [{
                  "triggeredAAs": "F",
                  "type": "NRTI",
                  "text": "T215F is a TAM that causes intermediate/high-level resistance to AZT and d4T, low-level resistance to ddI, and potentially low-level resistance to ABC and TDF."
                }],
                "text": "T215F",
                "shortText": "T215F"
              }, {
                "consensus": "K",
                "position": 219,
                "AAs": "Q",
                "triplet": "CAA",
                "insertedNAs": "",
                "isInsertion": false,
                "isDeletion": false,
                "isIndel": false,
                "isAmbiguous": false,
                "isApobecMutation": false,
                "isApobecDRM": false,
                "hasStop": false,
                "isUnusual": false,
                "types": ["NRTI"],
                "primaryType": "NRTI",
                "comments": [{
                  "triggeredAAs": "Q",
                  "type": "NRTI",
                  "text": "K219Q/E are accessory TAMS associated with reduced susceptibility to AZT and possibly d4T."
                }],
                "text": "K219Q",
                "shortText": "K219Q"
              }, {
                "consensus": "V",
                "position": 245,
                "AAs": "Q",
                "triplet": "CAG",
                "insertedNAs": "",
                "isInsertion": false,
                "isDeletion": false,
                "isIndel": false,
                "isAmbiguous": false,
                "isApobecMutation": false,
                "isApobecDRM": false,
                "hasStop": false,
                "isUnusual": false,
                "types": ["Other"],
                "primaryType": "Other",
                "comments": [],
                "text": "V245Q",
                "shortText": "V245Q"
              }],
              "APOBEC": [],
              "APOBEC_DRM": [{"text": "D67N"}],
              "DRM": [{"text": "D67N"}, {"text": "K70R"}, {"text": "T215F"}, {"text": "K219Q"}],
              "SDRM": [{"text": "D67N"}, {"text": "K70R"}, {"text": "T215F"}, {"text": "K219Q"}],
              "unusualMutations": [],
              "treatmentSelectedMutations": [],
              "frameShifts": []
            }],
            "firstTenCloseSubtypes": [{
              "displayWithoutDistance": "B",
              "distancePcnt": "3.17%",
              "referenceAccession": "D86069"
            }, {
              "displayWithoutDistance": "B",
              "distancePcnt": "3.27%",
              "referenceAccession": "M26727"
            }, {
              "displayWithoutDistance": "B",
              "distancePcnt": "3.36%",
              "referenceAccession": "K03455"
            }, {
              "displayWithoutDistance": "B",
              "distancePcnt": "3.46%",
              "referenceAccession": "AF042100"
            }, {
              "displayWithoutDistance": "B",
              "distancePcnt": "3.55%",
              "referenceAccession": "AF256204"
            }, {
              "displayWithoutDistance": "B",
              "distancePcnt": "3.65%",
              "referenceAccession": "U43096"
            }, {
              "displayWithoutDistance": "B",
              "distancePcnt": "3.65%",
              "referenceAccession": "AY779550"
            }, {
              "displayWithoutDistance": "B",
              "distancePcnt": "3.65%",
              "referenceAccession": "EU839600"
            }, {
              "displayWithoutDistance": "B",
              "distancePcnt": "3.84%",
              "referenceAccession": "AY173951"
            }, {"displayWithoutDistance": "B", "distancePcnt": "3.84%", "referenceAccession": "AF156820"}],
            "bestMatchingSubtype": {"display": "B (3.17%)"},
            "mixturePcnt": 0.4803073967339097,
            "mutations": [{"position": 10, "AAs": "I", "shortText": "L10I"}, {
              "position": 14,
              "AAs": "R",
              "shortText": "K14R"
            }, {"position": 41, "AAs": "K", "shortText": "R41K"}, {
              "position": 54,
              "AAs": "V",
              "shortText": "I54V"
            }, {"position": 60, "AAs": "E", "shortText": "D60E"}, {
              "position": 63,
              "AAs": "P",
              "shortText": "L63P"
            }, {"position": 64, "AAs": "V", "shortText": "I64V"}, {
              "position": 71,
              "AAs": "V",
              "shortText": "A71V"
            }, {"position": 82, "AAs": "A", "shortText": "V82A"}, {
              "position": 90,
              "AAs": "M",
              "shortText": "L90M"
            }, {"position": 93, "AAs": "L", "shortText": "I93L"}, {
              "position": 32,
              "AAs": "N",
              "shortText": "K32N"
            }, {"position": 39, "AAs": "A", "shortText": "T39A"}, {
              "position": 67,
              "AAs": "N",
              "shortText": "D67N"
            }, {"position": 70, "AAs": "R", "shortText": "K70R"}, {
              "position": 98,
              "AAs": "AS",
              "shortText": "A98AS"
            }, {"position": 121, "AAs": "Y", "shortText": "D121Y"}, {
              "position": 122,
              "AAs": "E",
              "shortText": "K122E"
            }, {"position": 135, "AAs": "K", "shortText": "I135K"}, {
              "position": 173,
              "AAs": "Q",
              "shortText": "K173Q"
            }, {"position": 178, "AAs": "L", "shortText": "I178L"}, {
              "position": 215,
              "AAs": "F",
              "shortText": "T215F"
            }, {"position": 219, "AAs": "Q", "shortText": "K219Q"}, {
              "position": 245,
              "AAs": "Q",
              "shortText": "V245Q"
            }],
            "frameShifts": [],
            "drugResistance": [{
              "gene": {
                "name": "PR",
                "consensus": "PQITLWQRPLVTIKIGGQLKEALLDTGADDTVLEEMNLPGRWKPKMIGGIGGFIKVRQYDQILIEICGHKAIGTVLVGPTPVNIIGRNLLTQIGCTLNF",
                "length": 99,
                "drugClasses": [{"name": "PI"}],
                "mutationTypes": ["Major", "Accessory", "Other"]
              },
              "drugScores": [{
                "drugClass": {
                  "name": "PI",
                  "fullName": "Protease Inhibitor",
                  "drugs": [{"name": "ATV", "displayAbbr": "ATV/r", "fullName": "atazanavir/r"}, {
                    "name": "DRV",
                    "displayAbbr": "DRV/r",
                    "fullName": "darunavir/r"
                  }, {"name": "FPV", "displayAbbr": "FPV/r", "fullName": "fosamprenavir/r"}, {
                    "name": "IDV",
                    "displayAbbr": "IDV/r",
                    "fullName": "indinavir/r"
                  }, {"name": "LPV", "displayAbbr": "LPV/r", "fullName": "lopinavir/r"}, {
                    "name": "NFV",
                    "displayAbbr": "NFV",
                    "fullName": "nelfinavir"
                  }, {"name": "SQV", "displayAbbr": "SQV/r", "fullName": "saquinavir/r"}, {
                    "name": "TPV",
                    "displayAbbr": "TPV/r",
                    "fullName": "tipranavir/r"
                  }]
                },
                "drug": {"displayAbbr": "ATV/r"},
                "SIR": "R",
                "score": 85,
                "level": 5,
                "text": "High-Level Resistance",
                "partialScores": [{"mutations": [{"text": "I54V"}], "score": 15}, {
                  "mutations": [{"text": "V82A"}],
                  "score": 15
                }, {"mutations": [{"text": "L90M"}], "score": 25}, {
                  "mutations": [{"text": "I54V"}, {"text": "V82A"}],
                  "score": 10
                }, {
                  "mutations": [{"text": "I54V"}, {"text": "L90M"}],
                  "score": 10
                }, {"mutations": [{"text": "V82A"}, {"text": "L90M"}], "score": 10}]
              }, {
                "drugClass": {
                  "name": "PI",
                  "fullName": "Protease Inhibitor",
                  "drugs": [{"name": "ATV", "displayAbbr": "ATV/r", "fullName": "atazanavir/r"}, {
                    "name": "DRV",
                    "displayAbbr": "DRV/r",
                    "fullName": "darunavir/r"
                  }, {"name": "FPV", "displayAbbr": "FPV/r", "fullName": "fosamprenavir/r"}, {
                    "name": "IDV",
                    "displayAbbr": "IDV/r",
                    "fullName": "indinavir/r"
                  }, {"name": "LPV", "displayAbbr": "LPV/r", "fullName": "lopinavir/r"}, {
                    "name": "NFV",
                    "displayAbbr": "NFV",
                    "fullName": "nelfinavir"
                  }, {"name": "SQV", "displayAbbr": "SQV/r", "fullName": "saquinavir/r"}, {
                    "name": "TPV",
                    "displayAbbr": "TPV/r",
                    "fullName": "tipranavir/r"
                  }]
                },
                "drug": {"displayAbbr": "DRV/r"},
                "SIR": "S",
                "score": 0,
                "level": 1,
                "text": "Susceptible",
                "partialScores": []
              }, {
                "drugClass": {
                  "name": "PI",
                  "fullName": "Protease Inhibitor",
                  "drugs": [{"name": "ATV", "displayAbbr": "ATV/r", "fullName": "atazanavir/r"}, {
                    "name": "DRV",
                    "displayAbbr": "DRV/r",
                    "fullName": "darunavir/r"
                  }, {"name": "FPV", "displayAbbr": "FPV/r", "fullName": "fosamprenavir/r"}, {
                    "name": "IDV",
                    "displayAbbr": "IDV/r",
                    "fullName": "indinavir/r"
                  }, {"name": "LPV", "displayAbbr": "LPV/r", "fullName": "lopinavir/r"}, {
                    "name": "NFV",
                    "displayAbbr": "NFV",
                    "fullName": "nelfinavir"
                  }, {"name": "SQV", "displayAbbr": "SQV/r", "fullName": "saquinavir/r"}, {
                    "name": "TPV",
                    "displayAbbr": "TPV/r",
                    "fullName": "tipranavir/r"
                  }]
                },
                "drug": {"displayAbbr": "FPV/r"},
                "SIR": "R",
                "score": 75,
                "level": 5,
                "text": "High-Level Resistance",
                "partialScores": [{"mutations": [{"text": "I54V"}], "score": 10}, {
                  "mutations": [{"text": "V82A"}],
                  "score": 15
                }, {"mutations": [{"text": "L90M"}], "score": 20}, {
                  "mutations": [{"text": "I54V"}, {"text": "V82A"}],
                  "score": 10
                }, {
                  "mutations": [{"text": "I54V"}, {"text": "L90M"}],
                  "score": 10
                }, {"mutations": [{"text": "V82A"}, {"text": "L90M"}], "score": 10}]
              }, {
                "drugClass": {
                  "name": "PI",
                  "fullName": "Protease Inhibitor",
                  "drugs": [{"name": "ATV", "displayAbbr": "ATV/r", "fullName": "atazanavir/r"}, {
                    "name": "DRV",
                    "displayAbbr": "DRV/r",
                    "fullName": "darunavir/r"
                  }, {"name": "FPV", "displayAbbr": "FPV/r", "fullName": "fosamprenavir/r"}, {
                    "name": "IDV",
                    "displayAbbr": "IDV/r",
                    "fullName": "indinavir/r"
                  }, {"name": "LPV", "displayAbbr": "LPV/r", "fullName": "lopinavir/r"}, {
                    "name": "NFV",
                    "displayAbbr": "NFV",
                    "fullName": "nelfinavir"
                  }, {"name": "SQV", "displayAbbr": "SQV/r", "fullName": "saquinavir/r"}, {
                    "name": "TPV",
                    "displayAbbr": "TPV/r",
                    "fullName": "tipranavir/r"
                  }]
                },
                "drug": {"displayAbbr": "IDV/r"},
                "SIR": "R",
                "score": 105,
                "level": 5,
                "text": "High-Level Resistance",
                "partialScores": [{"mutations": [{"text": "I54V"}], "score": 15}, {
                  "mutations": [{"text": "V82A"}],
                  "score": 30
                }, {"mutations": [{"text": "L90M"}], "score": 30}, {
                  "mutations": [{"text": "I54V"}, {"text": "V82A"}],
                  "score": 10
                }, {
                  "mutations": [{"text": "I54V"}, {"text": "L90M"}],
                  "score": 10
                }, {"mutations": [{"text": "V82A"}, {"text": "L90M"}], "score": 10}]
              }, {
                "drugClass": {
                  "name": "PI",
                  "fullName": "Protease Inhibitor",
                  "drugs": [{"name": "ATV", "displayAbbr": "ATV/r", "fullName": "atazanavir/r"}, {
                    "name": "DRV",
                    "displayAbbr": "DRV/r",
                    "fullName": "darunavir/r"
                  }, {"name": "FPV", "displayAbbr": "FPV/r", "fullName": "fosamprenavir/r"}, {
                    "name": "IDV",
                    "displayAbbr": "IDV/r",
                    "fullName": "indinavir/r"
                  }, {"name": "LPV", "displayAbbr": "LPV/r", "fullName": "lopinavir/r"}, {
                    "name": "NFV",
                    "displayAbbr": "NFV",
                    "fullName": "nelfinavir"
                  }, {"name": "SQV", "displayAbbr": "SQV/r", "fullName": "saquinavir/r"}, {
                    "name": "TPV",
                    "displayAbbr": "TPV/r",
                    "fullName": "tipranavir/r"
                  }]
                },
                "drug": {"displayAbbr": "LPV/r"},
                "SIR": "R",
                "score": 80,
                "level": 5,
                "text": "High-Level Resistance",
                "partialScores": [{"mutations": [{"text": "I54V"}], "score": 15}, {
                  "mutations": [{"text": "V82A"}],
                  "score": 30
                }, {"mutations": [{"text": "L90M"}], "score": 15}, {
                  "mutations": [{"text": "I54V"}, {"text": "V82A"}],
                  "score": 10
                }, {
                  "mutations": [{"text": "I54V"}, {"text": "L90M"}],
                  "score": 5
                }, {"mutations": [{"text": "V82A"}, {"text": "L90M"}], "score": 5}]
              }, {
                "drugClass": {
                  "name": "PI",
                  "fullName": "Protease Inhibitor",
                  "drugs": [{"name": "ATV", "displayAbbr": "ATV/r", "fullName": "atazanavir/r"}, {
                    "name": "DRV",
                    "displayAbbr": "DRV/r",
                    "fullName": "darunavir/r"
                  }, {"name": "FPV", "displayAbbr": "FPV/r", "fullName": "fosamprenavir/r"}, {
                    "name": "IDV",
                    "displayAbbr": "IDV/r",
                    "fullName": "indinavir/r"
                  }, {"name": "LPV", "displayAbbr": "LPV/r", "fullName": "lopinavir/r"}, {
                    "name": "NFV",
                    "displayAbbr": "NFV",
                    "fullName": "nelfinavir"
                  }, {"name": "SQV", "displayAbbr": "SQV/r", "fullName": "saquinavir/r"}, {
                    "name": "TPV",
                    "displayAbbr": "TPV/r",
                    "fullName": "tipranavir/r"
                  }]
                },
                "drug": {"displayAbbr": "NFV"},
                "SIR": "R",
                "score": 140,
                "level": 5,
                "text": "High-Level Resistance",
                "partialScores": [{"mutations": [{"text": "I54V"}], "score": 20}, {
                  "mutations": [{"text": "V82A"}],
                  "score": 30
                }, {"mutations": [{"text": "L90M"}], "score": 60}, {
                  "mutations": [{"text": "I54V"}, {"text": "V82A"}],
                  "score": 10
                }, {
                  "mutations": [{"text": "I54V"}, {"text": "L90M"}],
                  "score": 10
                }, {"mutations": [{"text": "V82A"}, {"text": "L90M"}], "score": 10}]
              }, {
                "drugClass": {
                  "name": "PI",
                  "fullName": "Protease Inhibitor",
                  "drugs": [{"name": "ATV", "displayAbbr": "ATV/r", "fullName": "atazanavir/r"}, {
                    "name": "DRV",
                    "displayAbbr": "DRV/r",
                    "fullName": "darunavir/r"
                  }, {"name": "FPV", "displayAbbr": "FPV/r", "fullName": "fosamprenavir/r"}, {
                    "name": "IDV",
                    "displayAbbr": "IDV/r",
                    "fullName": "indinavir/r"
                  }, {"name": "LPV", "displayAbbr": "LPV/r", "fullName": "lopinavir/r"}, {
                    "name": "NFV",
                    "displayAbbr": "NFV",
                    "fullName": "nelfinavir"
                  }, {"name": "SQV", "displayAbbr": "SQV/r", "fullName": "saquinavir/r"}, {
                    "name": "TPV",
                    "displayAbbr": "TPV/r",
                    "fullName": "tipranavir/r"
                  }]
                },
                "drug": {"displayAbbr": "SQV/r"},
                "SIR": "R",
                "score": 105,
                "level": 5,
                "text": "High-Level Resistance",
                "partialScores": [{"mutations": [{"text": "I54V"}], "score": 15}, {
                  "mutations": [{"text": "V82A"}],
                  "score": 15
                }, {"mutations": [{"text": "L90M"}], "score": 45}, {
                  "mutations": [{"text": "I54V"}, {"text": "V82A"}],
                  "score": 10
                }, {
                  "mutations": [{"text": "I54V"}, {"text": "L90M"}],
                  "score": 10
                }, {"mutations": [{"text": "V82A"}, {"text": "L90M"}], "score": 10}]
              }, {
                "drugClass": {
                  "name": "PI",
                  "fullName": "Protease Inhibitor",
                  "drugs": [{"name": "ATV", "displayAbbr": "ATV/r", "fullName": "atazanavir/r"}, {
                    "name": "DRV",
                    "displayAbbr": "DRV/r",
                    "fullName": "darunavir/r"
                  }, {"name": "FPV", "displayAbbr": "FPV/r", "fullName": "fosamprenavir/r"}, {
                    "name": "IDV",
                    "displayAbbr": "IDV/r",
                    "fullName": "indinavir/r"
                  }, {"name": "LPV", "displayAbbr": "LPV/r", "fullName": "lopinavir/r"}, {
                    "name": "NFV",
                    "displayAbbr": "NFV",
                    "fullName": "nelfinavir"
                  }, {"name": "SQV", "displayAbbr": "SQV/r", "fullName": "saquinavir/r"}, {
                    "name": "TPV",
                    "displayAbbr": "TPV/r",
                    "fullName": "tipranavir/r"
                  }]
                },
                "drug": {"displayAbbr": "TPV/r"},
                "SIR": "I",
                "score": 20,
                "level": 3,
                "text": "Low-Level Resistance",
                "partialScores": [{"mutations": [{"text": "I54V"}], "score": 20}]
              }],
              "mutationsByTypes": [{
                "mutationType": "Major",
                "mutations": [{
                  "consensus": "I",
                  "position": 54,
                  "AAs": "V",
                  "triplet": "GTC",
                  "insertedNAs": "",
                  "isInsertion": false,
                  "isDeletion": false,
                  "isIndel": false,
                  "isAmbiguous": false,
                  "isApobecMutation": false,
                  "isApobecDRM": false,
                  "hasStop": false,
                  "isUnusual": false,
                  "text": "I54V",
                  "shortText": "I54V"
                }, {
                  "consensus": "V",
                  "position": 82,
                  "AAs": "A",
                  "triplet": "GCC",
                  "insertedNAs": "",
                  "isInsertion": false,
                  "isDeletion": false,
                  "isIndel": false,
                  "isAmbiguous": false,
                  "isApobecMutation": false,
                  "isApobecDRM": false,
                  "hasStop": false,
                  "isUnusual": false,
                  "text": "V82A",
                  "shortText": "V82A"
                }, {
                  "consensus": "L",
                  "position": 90,
                  "AAs": "M",
                  "triplet": "ATG",
                  "insertedNAs": "",
                  "isInsertion": false,
                  "isDeletion": false,
                  "isIndel": false,
                  "isAmbiguous": false,
                  "isApobecMutation": false,
                  "isApobecDRM": false,
                  "hasStop": false,
                  "isUnusual": false,
                  "text": "L90M",
                  "shortText": "L90M"
                }]
              }, {"mutationType": "Accessory", "mutations": []}, {
                "mutationType": "Other",
                "mutations": [{
                  "consensus": "L",
                  "position": 10,
                  "AAs": "I",
                  "triplet": "ATC",
                  "insertedNAs": "",
                  "isInsertion": false,
                  "isDeletion": false,
                  "isIndel": false,
                  "isAmbiguous": false,
                  "isApobecMutation": false,
                  "isApobecDRM": false,
                  "hasStop": false,
                  "isUnusual": false,
                  "text": "L10I",
                  "shortText": "L10I"
                }, {
                  "consensus": "K",
                  "position": 14,
                  "AAs": "R",
                  "triplet": "AGG",
                  "insertedNAs": "",
                  "isInsertion": false,
                  "isDeletion": false,
                  "isIndel": false,
                  "isAmbiguous": false,
                  "isApobecMutation": false,
                  "isApobecDRM": false,
                  "hasStop": false,
                  "isUnusual": false,
                  "text": "K14R",
                  "shortText": "K14R"
                }, {
                  "consensus": "R",
                  "position": 41,
                  "AAs": "K",
                  "triplet": "AAA",
                  "insertedNAs": "",
                  "isInsertion": false,
                  "isDeletion": false,
                  "isIndel": false,
                  "isAmbiguous": false,
                  "isApobecMutation": false,
                  "isApobecDRM": false,
                  "hasStop": false,
                  "isUnusual": false,
                  "text": "R41K",
                  "shortText": "R41K"
                }, {
                  "consensus": "D",
                  "position": 60,
                  "AAs": "E",
                  "triplet": "GAG",
                  "insertedNAs": "",
                  "isInsertion": false,
                  "isDeletion": false,
                  "isIndel": false,
                  "isAmbiguous": false,
                  "isApobecMutation": false,
                  "isApobecDRM": false,
                  "hasStop": false,
                  "isUnusual": false,
                  "text": "D60E",
                  "shortText": "D60E"
                }, {
                  "consensus": "L",
                  "position": 63,
                  "AAs": "P",
                  "triplet": "CCC",
                  "insertedNAs": "",
                  "isInsertion": false,
                  "isDeletion": false,
                  "isIndel": false,
                  "isAmbiguous": false,
                  "isApobecMutation": false,
                  "isApobecDRM": false,
                  "hasStop": false,
                  "isUnusual": false,
                  "text": "L63P",
                  "shortText": "L63P"
                }, {
                  "consensus": "I",
                  "position": 64,
                  "AAs": "V",
                  "triplet": "GTA",
                  "insertedNAs": "",
                  "isInsertion": false,
                  "isDeletion": false,
                  "isIndel": false,
                  "isAmbiguous": false,
                  "isApobecMutation": false,
                  "isApobecDRM": false,
                  "hasStop": false,
                  "isUnusual": false,
                  "text": "I64V",
                  "shortText": "I64V"
                }, {
                  "consensus": "A",
                  "position": 71,
                  "AAs": "V",
                  "triplet": "GTT",
                  "insertedNAs": "",
                  "isInsertion": false,
                  "isDeletion": false,
                  "isIndel": false,
                  "isAmbiguous": false,
                  "isApobecMutation": false,
                  "isApobecDRM": false,
                  "hasStop": false,
                  "isUnusual": false,
                  "text": "A71V",
                  "shortText": "A71V"
                }, {
                  "consensus": "I",
                  "position": 93,
                  "AAs": "L",
                  "triplet": "CTT",
                  "insertedNAs": "",
                  "isInsertion": false,
                  "isDeletion": false,
                  "isIndel": false,
                  "isAmbiguous": false,
                  "isApobecMutation": false,
                  "isApobecDRM": false,
                  "hasStop": false,
                  "isUnusual": false,
                  "text": "I93L",
                  "shortText": "I93L"
                }]
              }],
              "commentsByTypes": [{
                "commentType": "Major",
                "comments": [{
                  "type": "Major",
                  "text": "I54V is a non-polymorphic PI-selected mutation that contributes reduced susceptibility to each of the PIs except DRV.",
                  "highlightText": ["I54V"]
                }, {
                  "type": "Major",
                  "text": "V82A is a non-polymorphic mutation selected primarily by IDV and LPV. It reduces susceptibility to these PIs and contributes cross-resistance to each of the remaining PIs except DRV and TPV.",
                  "highlightText": ["V82A"]
                }, {
                  "type": "Major",
                  "text": "L90M is a non-polymorphic PI-selected mutation that reduces susceptibility to each of the PIs except TPV and DRV.",
                  "highlightText": ["L90M"]
                }]
              }, {
                "commentType": "Other",
                "comments": [{
                  "type": "Other",
                  "text": "L10I/V are polymorphic, PI-selected accessory mutations that increase the replication of viruses with other PI-resistance mutations.",
                  "highlightText": ["L10I"]
                }, {
                  "type": "Other",
                  "text": "A71V/T are polymorphic, PI-selected accessory mutations that increase the replication of viruses with other PI-resistance mutations.",
                  "highlightText": ["A71V"]
                }]
              }]
            }, {
              "gene": {
                "name": "RT",
                "consensus": "PISPIETVPVKLKPGMDGPKVKQWPLTEEKIKALVEICTEMEKEGKISKIGPENPYNTPVFAIKKKDSTKWRKLVDFRELNKRTQDFWEVQLGIPHPAGLKKKKSVTVLDVGDAYFSVPLDKDFRKYTAFTIPSINNETPGIRYQYNVLPQGWKGSPAIFQSSMTKILEPFRKQNPDIVIYQYMDDLYVGSDLEIGQHRTKIEELRQHLLRWGFTTPDKKHQKEPPFLWMGYELHPDKWTVQPIVLPEKDSWTVNDIQKLVGKLNWASQIYAGIKVKQLCKLLRGTKALTEVIPLTEEAELELAENREILKEPVHGVYYDPSKDLIAEIQKQGQGQWTYQIYQEPFKNLKTGKYARMRGAHTNDVKQLTEAVQKIATESIVIWGKTPKFKLPIQKETWEAWWTEYWQATWIPEWEFVNTPPLVKLWYQLEKEPIVGAETFYVDGAANRETKLGKAGYVTDRGRQKVVSLTDTTNQKTELQAIHLALQDSGLEVNIVTDSQYALGIIQAQPDKSESELVSQIIEQLIKKEKVYLAWVPAHKGIGGNEQVDKLVSAGIRKVL",
                "length": 560,
                "drugClasses": [{"name": "NRTI"}, {"name": "NNRTI"}],
                "mutationTypes": ["NRTI", "NNRTI", "Other"]
              },
              "drugScores": [{
                "drugClass": {
                  "name": "NRTI",
                  "fullName": "Nucleoside Reverse Transcriptase Inhibitor",
                  "drugs": [{"name": "ABC", "displayAbbr": "ABC", "fullName": "abacavir"}, {
                    "name": "AZT",
                    "displayAbbr": "AZT",
                    "fullName": "zidovudine"
                  }, {"name": "D4T", "displayAbbr": "D4T", "fullName": "stavudine"}, {
                    "name": "DDI",
                    "displayAbbr": "DDI",
                    "fullName": "didanosine"
                  }, {"name": "FTC", "displayAbbr": "FTC", "fullName": "emtricitabine"}, {
                    "name": "LMV",
                    "displayAbbr": "3TC",
                    "fullName": "lamivudine"
                  }, {"name": "TDF", "displayAbbr": "TDF", "fullName": "tenofovir"}]
                },
                "drug": {"displayAbbr": "ABC"},
                "SIR": "I",
                "score": 45,
                "level": 4,
                "text": "Intermediate Resistance",
                "partialScores": [{"mutations": [{"text": "D67N"}], "score": 5}, {
                  "mutations": [{"text": "K70R"}],
                  "score": 5
                }, {"mutations": [{"text": "T215F"}], "score": 10}, {
                  "mutations": [{"text": "K219Q"}],
                  "score": 5
                }, {
                  "mutations": [{"text": "D67N"}, {"text": "K70R"}, {"text": "K219Q"}],
                  "score": 10
                }, {
                  "mutations": [{"text": "D67N"}, {"text": "T215F"}, {"text": "K219Q"}],
                  "score": 5
                }, {"mutations": [{"text": "K70R"}, {"text": "T215F"}], "score": 5}]
              }, {
                "drugClass": {
                  "name": "NRTI",
                  "fullName": "Nucleoside Reverse Transcriptase Inhibitor",
                  "drugs": [{"name": "ABC", "displayAbbr": "ABC", "fullName": "abacavir"}, {
                    "name": "AZT",
                    "displayAbbr": "AZT",
                    "fullName": "zidovudine"
                  }, {"name": "D4T", "displayAbbr": "D4T", "fullName": "stavudine"}, {
                    "name": "DDI",
                    "displayAbbr": "DDI",
                    "fullName": "didanosine"
                  }, {"name": "FTC", "displayAbbr": "FTC", "fullName": "emtricitabine"}, {
                    "name": "LMV",
                    "displayAbbr": "3TC",
                    "fullName": "lamivudine"
                  }, {"name": "TDF", "displayAbbr": "TDF", "fullName": "tenofovir"}]
                },
                "drug": {"displayAbbr": "AZT"},
                "SIR": "R",
                "score": 115,
                "level": 5,
                "text": "High-Level Resistance",
                "partialScores": [{"mutations": [{"text": "D67N"}], "score": 15}, {
                  "mutations": [{"text": "K70R"}],
                  "score": 30
                }, {"mutations": [{"text": "T215F"}], "score": 40}, {
                  "mutations": [{"text": "K219Q"}],
                  "score": 10
                }, {
                  "mutations": [{"text": "D67N"}, {"text": "K70R"}, {"text": "K219Q"}],
                  "score": 10
                }, {
                  "mutations": [{"text": "D67N"}, {"text": "T215F"}, {"text": "K219Q"}],
                  "score": 5
                }, {"mutations": [{"text": "K70R"}, {"text": "T215F"}], "score": 5}]
              }, {
                "drugClass": {
                  "name": "NRTI",
                  "fullName": "Nucleoside Reverse Transcriptase Inhibitor",
                  "drugs": [{"name": "ABC", "displayAbbr": "ABC", "fullName": "abacavir"}, {
                    "name": "AZT",
                    "displayAbbr": "AZT",
                    "fullName": "zidovudine"
                  }, {"name": "D4T", "displayAbbr": "D4T", "fullName": "stavudine"}, {
                    "name": "DDI",
                    "displayAbbr": "DDI",
                    "fullName": "didanosine"
                  }, {"name": "FTC", "displayAbbr": "FTC", "fullName": "emtricitabine"}, {
                    "name": "LMV",
                    "displayAbbr": "3TC",
                    "fullName": "lamivudine"
                  }, {"name": "TDF", "displayAbbr": "TDF", "fullName": "tenofovir"}]
                },
                "drug": {"displayAbbr": "D4T"},
                "SIR": "R",
                "score": 100,
                "level": 5,
                "text": "High-Level Resistance",
                "partialScores": [{"mutations": [{"text": "D67N"}], "score": 15}, {
                  "mutations": [{"text": "K70R"}],
                  "score": 15
                }, {"mutations": [{"text": "T215F"}], "score": 40}, {
                  "mutations": [{"text": "K219Q"}],
                  "score": 10
                }, {
                  "mutations": [{"text": "D67N"}, {"text": "K70R"}, {"text": "K219Q"}],
                  "score": 10
                }, {
                  "mutations": [{"text": "D67N"}, {"text": "T215F"}, {"text": "K219Q"}],
                  "score": 5
                }, {"mutations": [{"text": "K70R"}, {"text": "T215F"}], "score": 5}]
              }, {
                "drugClass": {
                  "name": "NRTI",
                  "fullName": "Nucleoside Reverse Transcriptase Inhibitor",
                  "drugs": [{"name": "ABC", "displayAbbr": "ABC", "fullName": "abacavir"}, {
                    "name": "AZT",
                    "displayAbbr": "AZT",
                    "fullName": "zidovudine"
                  }, {"name": "D4T", "displayAbbr": "D4T", "fullName": "stavudine"}, {
                    "name": "DDI",
                    "displayAbbr": "DDI",
                    "fullName": "didanosine"
                  }, {"name": "FTC", "displayAbbr": "FTC", "fullName": "emtricitabine"}, {
                    "name": "LMV",
                    "displayAbbr": "3TC",
                    "fullName": "lamivudine"
                  }, {"name": "TDF", "displayAbbr": "TDF", "fullName": "tenofovir"}]
                },
                "drug": {"displayAbbr": "DDI"},
                "SIR": "I",
                "score": 55,
                "level": 4,
                "text": "Intermediate Resistance",
                "partialScores": [{"mutations": [{"text": "D67N"}], "score": 5}, {
                  "mutations": [{"text": "K70R"}],
                  "score": 10
                }, {"mutations": [{"text": "T215F"}], "score": 15}, {
                  "mutations": [{"text": "K219Q"}],
                  "score": 5
                }, {
                  "mutations": [{"text": "D67N"}, {"text": "K70R"}, {"text": "K219Q"}],
                  "score": 10
                }, {
                  "mutations": [{"text": "D67N"}, {"text": "T215F"}, {"text": "K219Q"}],
                  "score": 5
                }, {"mutations": [{"text": "K70R"}, {"text": "T215F"}], "score": 5}]
              }, {
                "drugClass": {
                  "name": "NRTI",
                  "fullName": "Nucleoside Reverse Transcriptase Inhibitor",
                  "drugs": [{"name": "ABC", "displayAbbr": "ABC", "fullName": "abacavir"}, {
                    "name": "AZT",
                    "displayAbbr": "AZT",
                    "fullName": "zidovudine"
                  }, {"name": "D4T", "displayAbbr": "D4T", "fullName": "stavudine"}, {
                    "name": "DDI",
                    "displayAbbr": "DDI",
                    "fullName": "didanosine"
                  }, {"name": "FTC", "displayAbbr": "FTC", "fullName": "emtricitabine"}, {
                    "name": "LMV",
                    "displayAbbr": "3TC",
                    "fullName": "lamivudine"
                  }, {"name": "TDF", "displayAbbr": "TDF", "fullName": "tenofovir"}]
                },
                "drug": {"displayAbbr": "FTC"},
                "SIR": "S",
                "score": 10,
                "level": 2,
                "text": "Potential Low-Level Resistance",
                "partialScores": [{"mutations": [{"text": "D67N"}, {"text": "K70R"}, {"text": "K219Q"}], "score": 10}]
              }, {
                "drugClass": {
                  "name": "NRTI",
                  "fullName": "Nucleoside Reverse Transcriptase Inhibitor",
                  "drugs": [{"name": "ABC", "displayAbbr": "ABC", "fullName": "abacavir"}, {
                    "name": "AZT",
                    "displayAbbr": "AZT",
                    "fullName": "zidovudine"
                  }, {"name": "D4T", "displayAbbr": "D4T", "fullName": "stavudine"}, {
                    "name": "DDI",
                    "displayAbbr": "DDI",
                    "fullName": "didanosine"
                  }, {"name": "FTC", "displayAbbr": "FTC", "fullName": "emtricitabine"}, {
                    "name": "LMV",
                    "displayAbbr": "3TC",
                    "fullName": "lamivudine"
                  }, {"name": "TDF", "displayAbbr": "TDF", "fullName": "tenofovir"}]
                },
                "drug": {"displayAbbr": "3TC"},
                "SIR": "S",
                "score": 10,
                "level": 2,
                "text": "Potential Low-Level Resistance",
                "partialScores": [{"mutations": [{"text": "D67N"}, {"text": "K70R"}, {"text": "K219Q"}], "score": 10}]
              }, {
                "drugClass": {
                  "name": "NRTI",
                  "fullName": "Nucleoside Reverse Transcriptase Inhibitor",
                  "drugs": [{"name": "ABC", "displayAbbr": "ABC", "fullName": "abacavir"}, {
                    "name": "AZT",
                    "displayAbbr": "AZT",
                    "fullName": "zidovudine"
                  }, {"name": "D4T", "displayAbbr": "D4T", "fullName": "stavudine"}, {
                    "name": "DDI",
                    "displayAbbr": "DDI",
                    "fullName": "didanosine"
                  }, {"name": "FTC", "displayAbbr": "FTC", "fullName": "emtricitabine"}, {
                    "name": "LMV",
                    "displayAbbr": "3TC",
                    "fullName": "lamivudine"
                  }, {"name": "TDF", "displayAbbr": "TDF", "fullName": "tenofovir"}]
                },
                "drug": {"displayAbbr": "TDF"},
                "SIR": "I",
                "score": 45,
                "level": 4,
                "text": "Intermediate Resistance",
                "partialScores": [{"mutations": [{"text": "D67N"}], "score": 5}, {
                  "mutations": [{"text": "K70R"}],
                  "score": 5
                }, {"mutations": [{"text": "T215F"}], "score": 10}, {
                  "mutations": [{"text": "K219Q"}],
                  "score": 5
                }, {
                  "mutations": [{"text": "D67N"}, {"text": "K70R"}, {"text": "K219Q"}],
                  "score": 10
                }, {
                  "mutations": [{"text": "D67N"}, {"text": "T215F"}, {"text": "K219Q"}],
                  "score": 5
                }, {"mutations": [{"text": "K70R"}, {"text": "T215F"}], "score": 5}]
              }, {
                "drugClass": {
                  "name": "NNRTI",
                  "fullName": "Non-nucleoside Reverse Transcriptase Inhibitor",
                  "drugs": [{"name": "EFV", "displayAbbr": "EFV", "fullName": "efavirenz"}, {
                    "name": "ETR",
                    "displayAbbr": "ETR",
                    "fullName": "etravirine"
                  }, {"name": "NVP", "displayAbbr": "NVP", "fullName": "nevirapine"}, {
                    "name": "RPV",
                    "displayAbbr": "RPV",
                    "fullName": "rilpivirine"
                  }]
                },
                "drug": {"displayAbbr": "EFV"},
                "SIR": "S",
                "score": 0,
                "level": 1,
                "text": "Susceptible",
                "partialScores": []
              }, {
                "drugClass": {
                  "name": "NNRTI",
                  "fullName": "Non-nucleoside Reverse Transcriptase Inhibitor",
                  "drugs": [{"name": "EFV", "displayAbbr": "EFV", "fullName": "efavirenz"}, {
                    "name": "ETR",
                    "displayAbbr": "ETR",
                    "fullName": "etravirine"
                  }, {"name": "NVP", "displayAbbr": "NVP", "fullName": "nevirapine"}, {
                    "name": "RPV",
                    "displayAbbr": "RPV",
                    "fullName": "rilpivirine"
                  }]
                },
                "drug": {"displayAbbr": "ETR"},
                "SIR": "S",
                "score": 0,
                "level": 1,
                "text": "Susceptible",
                "partialScores": []
              }, {
                "drugClass": {
                  "name": "NNRTI",
                  "fullName": "Non-nucleoside Reverse Transcriptase Inhibitor",
                  "drugs": [{"name": "EFV", "displayAbbr": "EFV", "fullName": "efavirenz"}, {
                    "name": "ETR",
                    "displayAbbr": "ETR",
                    "fullName": "etravirine"
                  }, {"name": "NVP", "displayAbbr": "NVP", "fullName": "nevirapine"}, {
                    "name": "RPV",
                    "displayAbbr": "RPV",
                    "fullName": "rilpivirine"
                  }]
                },
                "drug": {"displayAbbr": "NVP"},
                "SIR": "S",
                "score": 0,
                "level": 1,
                "text": "Susceptible",
                "partialScores": []
              }, {
                "drugClass": {
                  "name": "NNRTI",
                  "fullName": "Non-nucleoside Reverse Transcriptase Inhibitor",
                  "drugs": [{"name": "EFV", "displayAbbr": "EFV", "fullName": "efavirenz"}, {
                    "name": "ETR",
                    "displayAbbr": "ETR",
                    "fullName": "etravirine"
                  }, {"name": "NVP", "displayAbbr": "NVP", "fullName": "nevirapine"}, {
                    "name": "RPV",
                    "displayAbbr": "RPV",
                    "fullName": "rilpivirine"
                  }]
                },
                "drug": {"displayAbbr": "RPV"},
                "SIR": "S",
                "score": 0,
                "level": 1,
                "text": "Susceptible",
                "partialScores": []
              }],
              "mutationsByTypes": [{
                "mutationType": "NRTI",
                "mutations": [{
                  "consensus": "D",
                  "position": 67,
                  "AAs": "N",
                  "triplet": "AAC",
                  "insertedNAs": "",
                  "isInsertion": false,
                  "isDeletion": false,
                  "isIndel": false,
                  "isAmbiguous": false,
                  "isApobecMutation": false,
                  "isApobecDRM": true,
                  "hasStop": false,
                  "isUnusual": false,
                  "text": "D67N",
                  "shortText": "D67N"
                }, {
                  "consensus": "K",
                  "position": 70,
                  "AAs": "R",
                  "triplet": "AGA",
                  "insertedNAs": "",
                  "isInsertion": false,
                  "isDeletion": false,
                  "isIndel": false,
                  "isAmbiguous": false,
                  "isApobecMutation": false,
                  "isApobecDRM": false,
                  "hasStop": false,
                  "isUnusual": false,
                  "text": "K70R",
                  "shortText": "K70R"
                }, {
                  "consensus": "T",
                  "position": 215,
                  "AAs": "F",
                  "triplet": "TTC",
                  "insertedNAs": "",
                  "isInsertion": false,
                  "isDeletion": false,
                  "isIndel": false,
                  "isAmbiguous": false,
                  "isApobecMutation": false,
                  "isApobecDRM": false,
                  "hasStop": false,
                  "isUnusual": false,
                  "text": "T215F",
                  "shortText": "T215F"
                }, {
                  "consensus": "K",
                  "position": 219,
                  "AAs": "Q",
                  "triplet": "CAA",
                  "insertedNAs": "",
                  "isInsertion": false,
                  "isDeletion": false,
                  "isIndel": false,
                  "isAmbiguous": false,
                  "isApobecMutation": false,
                  "isApobecDRM": false,
                  "hasStop": false,
                  "isUnusual": false,
                  "text": "K219Q",
                  "shortText": "K219Q"
                }]
              }, {"mutationType": "NNRTI", "mutations": []}, {
                "mutationType": "Other",
                "mutations": [{
                  "consensus": "K",
                  "position": 32,
                  "AAs": "N",
                  "triplet": "AAT",
                  "insertedNAs": "",
                  "isInsertion": false,
                  "isDeletion": false,
                  "isIndel": false,
                  "isAmbiguous": false,
                  "isApobecMutation": false,
                  "isApobecDRM": false,
                  "hasStop": false,
                  "isUnusual": false,
                  "text": "K32N",
                  "shortText": "K32N"
                }, {
                  "consensus": "T",
                  "position": 39,
                  "AAs": "A",
                  "triplet": "GCA",
                  "insertedNAs": "",
                  "isInsertion": false,
                  "isDeletion": false,
                  "isIndel": false,
                  "isAmbiguous": false,
                  "isApobecMutation": false,
                  "isApobecDRM": false,
                  "hasStop": false,
                  "isUnusual": false,
                  "text": "T39A",
                  "shortText": "T39A"
                }, {
                  "consensus": "A",
                  "position": 98,
                  "AAs": "AS",
                  "triplet": "KCA",
                  "insertedNAs": "",
                  "isInsertion": false,
                  "isDeletion": false,
                  "isIndel": false,
                  "isAmbiguous": false,
                  "isApobecMutation": false,
                  "isApobecDRM": false,
                  "hasStop": false,
                  "isUnusual": false,
                  "text": "A98AS",
                  "shortText": "A98AS"
                }, {
                  "consensus": "D",
                  "position": 121,
                  "AAs": "Y",
                  "triplet": "TAT",
                  "insertedNAs": "",
                  "isInsertion": false,
                  "isDeletion": false,
                  "isIndel": false,
                  "isAmbiguous": false,
                  "isApobecMutation": false,
                  "isApobecDRM": false,
                  "hasStop": false,
                  "isUnusual": false,
                  "text": "D121Y",
                  "shortText": "D121Y"
                }, {
                  "consensus": "K",
                  "position": 122,
                  "AAs": "E",
                  "triplet": "GAA",
                  "insertedNAs": "",
                  "isInsertion": false,
                  "isDeletion": false,
                  "isIndel": false,
                  "isAmbiguous": false,
                  "isApobecMutation": false,
                  "isApobecDRM": false,
                  "hasStop": false,
                  "isUnusual": false,
                  "text": "K122E",
                  "shortText": "K122E"
                }, {
                  "consensus": "I",
                  "position": 135,
                  "AAs": "K",
                  "triplet": "AAA",
                  "insertedNAs": "",
                  "isInsertion": false,
                  "isDeletion": false,
                  "isIndel": false,
                  "isAmbiguous": false,
                  "isApobecMutation": false,
                  "isApobecDRM": false,
                  "hasStop": false,
                  "isUnusual": false,
                  "text": "I135K",
                  "shortText": "I135K"
                }, {
                  "consensus": "K",
                  "position": 173,
                  "AAs": "Q",
                  "triplet": "CAA",
                  "insertedNAs": "",
                  "isInsertion": false,
                  "isDeletion": false,
                  "isIndel": false,
                  "isAmbiguous": false,
                  "isApobecMutation": false,
                  "isApobecDRM": false,
                  "hasStop": false,
                  "isUnusual": false,
                  "text": "K173Q",
                  "shortText": "K173Q"
                }, {
                  "consensus": "I",
                  "position": 178,
                  "AAs": "L",
                  "triplet": "CTA",
                  "insertedNAs": "",
                  "isInsertion": false,
                  "isDeletion": false,
                  "isIndel": false,
                  "isAmbiguous": false,
                  "isApobecMutation": false,
                  "isApobecDRM": false,
                  "hasStop": false,
                  "isUnusual": false,
                  "text": "I178L",
                  "shortText": "I178L"
                }, {
                  "consensus": "V",
                  "position": 245,
                  "AAs": "Q",
                  "triplet": "CAG",
                  "insertedNAs": "",
                  "isInsertion": false,
                  "isDeletion": false,
                  "isIndel": false,
                  "isAmbiguous": false,
                  "isApobecMutation": false,
                  "isApobecDRM": false,
                  "hasStop": false,
                  "isUnusual": false,
                  "text": "V245Q",
                  "shortText": "V245Q"
                }]
              }],
              "commentsByTypes": [{
                "commentType": "NRTI",
                "comments": [{
                  "type": "NRTI",
                  "text": "T215F is a TAM that causes intermediate/high-level resistance to AZT and d4T, low-level resistance to ddI, and potentially low-level resistance to ABC and TDF.",
                  "highlightText": ["T215F"]
                }, {
                  "type": "NRTI",
                  "text": "K219Q/E are accessory TAMS associated with reduced susceptibility to AZT and possibly d4T.",
                  "highlightText": ["K219Q"]
                }, {
                  "type": "NRTI",
                  "text": "D67N is a non-polymorphic TAM associated with low-level resistance to AZT and d4T. When present with other TAMs, it contributes reduced susceptibility to ABC, ddI, and TDF.",
                  "highlightText": ["D67N"]
                }, {
                  "type": "NRTI",
                  "text": "K70R causes intermediate resistance to AZT and possibly low-level resistance to D4T, DDI, ABC and TDF.",
                  "highlightText": ["K70R"]
                }]
              }]
            }]
          }]
        }
      }
    };

    console.log(this.geneSequenceResponse.data.viewer.sequenceAnalysis[0].alignedGeneSequences);
  }

  ionViewDidLoad() {

    this.keyboard.onKeyboardShow().subscribe(() => {
      this.valueforngif = false
    });

    this.keyboard.onKeyboardHide().subscribe(() => {
      this.valueforngif = false
    });

    //this.sequenceChartData = this.chartData(this.geneSequenceResponse.data.viewer.sequenceAnalysis[0].alignedGeneSequences, 20);

    let options = {
      scales: {
        yAxes: [{
          ticks: {
            beginAtZero: true
          }
        }]
      }

    };

    //return this.getChart(this.sequenceChart.nativeElement, "bar", this.getBarChart(this.sequenceChartData), options);

  }

  openPage(page, extras?: any) {
    this.navCtrl.push(page, extras);
  }

  openPinForm(objectblock) {
    this.getDetails();
  }

  getDetails() {
    this.error = 0;
    if (this.objectblock.username == "" || this.objectblock.username == undefined) {
      this.error = 1;
    }
    else if (!(/^\d{10}$/.test(this.objectblock.username))) {
      this.error = 2;
    }
    else {

      this.stage = 'pin';
    }

  }

  submit() {
    this.error = 0;
    if (this.objectblock.username == "" || this.objectblock.username == undefined) {
      this.error = 1;
    }
    else if (!(/^\d{10}$/.test(this.objectblock.username))) {
      this.error = 2;
    }
    else if (this.objectblock.password == "" || this.objectblock.password == undefined) {
      this.error = 3;
    } else if (!(/^\d{4}$/.test(this.objectblock.password))) {
      this.error = 4;
    }
    else {

      let loading = this.loadingCtrl.create({
        spinner: 'crescent',
        content: 'Logging In...'
      });

      loading.present();

      let response = RemoteServiceProvider.fakeLogin(this.objectblock.username, this.objectblock.password);
      if (response.status === true) {
        this.globalVars.customername = response.user.fname + response.user.lname;
        this.globalVars.backToMainPage();
      }
      loading.dismiss();

    }

  }

  activatepin() {
    this.error = 0;

    if (this.objectblock.IDNumber == "" || this.objectblock.IDNumber == undefined) {
      this.error = 5;
    }
    else {

      let loading = this.loadingCtrl.create({
        spinner: 'crescent',
        content: 'Logging In...'
      });

      loading.present();

      //send login request
      this.remoteService.postRequest(this.objectblock, "signin/activatepin")
        .then(
          data => {

            loading.dismiss();

            this.data = data;

            if (this.data.error === false) {
              this.stage = 'pin';
              this.globalVars.presentAlert("Success", this.data.message);
            }
            else {
              this.globalVars.presentAlert("Failed", this.data.message);

            }
          }
        )
        .catch(error => {
          loading.dismiss();
          this.globalVars.presentAlert("Failed", "Could not connect to AAR system. Check your internet connection.");

        });

    }

  }

  firstchangepin() {

    this.error = 0;

    if (this.objectblock.oldpass === "" || this.objectblock.oldpass == undefined) {
      this.error = 1;
    }
    else if (this.objectblock.newpass === "" || this.objectblock.newpass == undefined) {
      this.error = 2;
    }
    else if (this.objectblock.newpassconfirm === "" || this.objectblock.newpassconfirm == undefined) {
      this.error = 3;
    }
    else if (this.objectblock.newpassconfirm !== this.objectblock.newpass) {
      this.error = 4;
    }
    else {

      let loading = this.loadingCtrl.create({
        spinner: 'crescent',
        content: 'Sending Change Pin request...'
      });

      loading.present();

      //send airtime purchase request
      this.remoteService.postRequest(this.objectblock, "pin/show")
        .then(
          data => {

            loading.dismiss();

            this.data = data;

            if (this.data.error === false) {

              this.globalVars.presentAlert("Change Pin Successful", this.data.message.status);

              //if you have  valid PIN
              this.stage = 'phone';

            }
            else {
              this.globalVars.presentAlert(" Change Pin Failed", this.data.message.status);

            }
          }
        )
        .catch(
          error => {
            loading.dismiss();

            this.globalVars.presentAlert("Error", " Change Pin not successful");
          }
        );
    }

  }

  singlesignin(loginType) {

    let loading = this.loadingCtrl.create({
      spinner: 'crescent',
      content: 'Sending Change Pin request...'
    });

    loading.present();

    //send airtime purchase request
    this.remoteService.postRequest(this.objectblock, "login/" + loginType, true)
      .then(
        data => {

          loading.dismiss();

          this.data = data;

          if (this.data.error === false) {

            this.globalVars.presentAlert("Change Pin Successful", this.data.message.status);

            //if you have  valid PIN
            this.stage = 'phone';

          }
          else {
            this.globalVars.presentAlert(" Change Pin Failed", this.data.message.status);

          }
        }
      )
      .catch(
        error => {
          loading.dismiss();

          this.globalVars.presentAlert("Error", " Change Pin not successful");
        }
      );

  }

  login() {
    this.googlePlus.login({})
      .then(res => {
        console.log(res);
        this.displayName = res.displayName;
        this.email = res.email;
        this.familyName = res.familyName;
        this.givenName = res.givenName;
        this.userId = res.userId;
        this.imageUrl = res.imageUrl;

        this.isLoggedIn = true;
      })
      .catch(err => console.error(err));
  }

  logout() {
    this.googlePlus.logout()
      .then(res => {
        console.log(res);
        this.displayName = "";
        this.email = "";
        this.familyName = "";
        this.givenName = "";
        this.userId = "";
        this.imageUrl = "";

        this.isLoggedIn = false;
      })
      .catch(err => console.error(err));
  }

  openHomePage() {

    this.openPage('MainPage');
  }


  loginBtn(phone) {

    if (phone && phone.length === 10 && phone.startsWith('0')) {
      phone = '+254' + phone.substring(1, 10);
    } else {
      return;
    }

    console.log(phone);

    this.phoneService.verify(phone).then(() => {
      this.openVerifyPage(phone);
    })
      .catch(error => {
        console.log(error.reason);
        this.error = 10;
        this.errorMessage = error.reason;
      });

  }

  openVerifyPage(phone: string) {
    this.stage = 'verify';
  }

  verify(otp: string) {
    console.log('verifying ' + otp);
    console.log('verifying ' + this.objectblock.username);
    let phone = this.objectblock.username.toString();

    if (phone && phone.length === 10 && phone.startsWith('0')) {
      phone = '+254' + phone.substring(1, 10);
    } else {
      return;
    }

    this.phoneService.login(phone, otp).then(() => {
      this.openHomePage();
    })
      .catch((e) => {
        console.log(e);
      });

  }


}
